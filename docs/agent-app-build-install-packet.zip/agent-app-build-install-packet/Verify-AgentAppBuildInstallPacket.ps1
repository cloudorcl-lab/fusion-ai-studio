[CmdletBinding()]
param([Parameter(Mandatory)][string]$PacketRoot)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $PacketRoot -ErrorAction Stop).Path
$manifestPath = Join-Path $root 'PACKET-MANIFEST.json'
if (-not (Test-Path -LiteralPath $manifestPath)) { throw "Packet manifest does not exist: $manifestPath" }

foreach ($required in @('INSTALL.md', 'Install-AgentAppBuildStartup.ps1', 'Verify-AgentAppBuildInstallPacket.ps1', 'agent-app-build-startup')) {
  if (-not (Test-Path -LiteralPath (Join-Path $root $required))) { throw "Missing required packet artifact: $required" }
}

$manifest = Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json
if ($manifest.schemaVersion -ne 1 -or $manifest.packetName -ne 'agent-app-build-install-packet') { throw 'Unsupported packet manifest.' }
if (-not $manifest.payload -or $manifest.payload.Count -eq 0) { throw 'Packet manifest has no payload entries.' }
foreach ($entry in $manifest.payload) {
  if ([string]::IsNullOrWhiteSpace($entry.path) -or [IO.Path]::IsPathRooted($entry.path) -or $entry.path -match '(^|[\\/])\.\.([\\/]|$)') {
    throw "Unsafe packet manifest path: $($entry.path)"
  }
  $path = Join-Path $root $entry.path
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing packet payload file: $($entry.path)" }
  $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actual -ne $entry.sha256) { throw "Packet payload hash mismatch: $($entry.path)" }
}

& (Join-Path $root 'agent-app-build-startup\scripts\Verify-AgentAppBuildStartup.ps1') -PackageRoot (Join-Path $root 'agent-app-build-startup')
Write-Output 'Agent-app build install packet: PASS'
