# Agent-App Build Startup Install Packet

This packet installs the reusable AI Studio agent-app startup package into an
existing target repository. It does not create an AI Studio artifact, change a
remote environment, create a Git worktree, or overwrite the target
repository's root instructions.

## Prerequisites

- PowerShell 7.
- A writable target Git repository that already contains its canonical living
  playbook and local `.agents/skills/aistudio/` route.
- Authority to add a new `agent-app-build-startup` directory to that repository.

## Install

1. Extract `agent-app-build-install-packet.zip` without changing the internal
   `agent-app-build-install-packet` directory name.
2. In the extracted directory, verify the packet before copying it:

   ```powershell
   pwsh -NoProfile -File .\Verify-AgentAppBuildInstallPacket.ps1 -PacketRoot $PWD
   ```

3. Install into the target repository. The installer stops if
   `agent-app-build-startup` already exists; choose a reviewed upgrade path
   instead of overwriting it.

   ```powershell
   pwsh -NoProfile -File .\Install-AgentAppBuildStartup.ps1 `
     -PacketRoot $PWD `
     -DestinationRoot C:\path\to\target-repository
   ```

4. Review the installed `agent-app-build-startup\AGENTS.md` against the
   target repository's root `AGENTS.md`. Copy or merge it at the root only
   with explicit authority; never silently replace repository-specific agent
   instructions.
5. For an actual app build, create a fresh worktree with the installed helper,
   verify the package, materialize the tracking templates, then follow the
   target repository's canonical playbook and local AI Studio skill.

## Integrity and ownership boundary

`PACKET-MANIFEST.json` records SHA-256 hashes for every delivered payload file.
The verifier checks each hash and runs the embedded startup-package verifier.
The target repository's canonical playbook remains the lifecycle owner; this
packet supplies only startup mechanics, tracking shapes, and local checks.
