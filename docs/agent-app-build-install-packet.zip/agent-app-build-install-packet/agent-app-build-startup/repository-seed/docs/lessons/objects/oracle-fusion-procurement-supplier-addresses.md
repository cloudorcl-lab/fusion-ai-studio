# Oracle Fusion Procurement Supplier Addresses object reference

## Identity and scope

| Field | Value |
| --- | --- |
| Product | Oracle Fusion Cloud Procurement |
| Resource object | Supplier Addresses |
| REST collection | `/fscmRestApi/resources/11.13.18.05/suppliers/{SupplierId}/child/addresses` |
| Documentation release | 26C |
| Required parent key | Live-resolved `SupplierId` |
| Stable item key | `SupplierAddressId` |
| Last evidence review | 2026-09-17 |

Sources: [GET supplier addresses](https://docs.oracle.com/en/cloud/saas/procurement/26c/fapra/op-suppliers-supplierid-child-addresses-get.html), [POST supplier address](https://docs.oracle.com/en/cloud/saas/procurement/26c/fapra/op-suppliers-supplierid-child-addresses-post.html), and [Oracle 26C OpenAPI](https://docs.oracle.com/en/cloud/saas/procurement/26c/fapra/openapi.json).

## GET operation

Parent identity follows the [Suppliers GET key contract](oracle-fusion-procurement-suppliers.md#get-operations): a displayed SupplierNumber must resolve to SupplierId before this child path is constructed. Preserve the selected supplier and reject unresolved or ambiguous number references.

The collection operation ID is `getall_suppliers-addresses`. Resolve the parent supplier first and pass its business `SupplierId`; the generated local BO parameter is named `suppliers_Id`. Do not embed a sample parent ID as a default.

| Behavior | Contract |
| --- | --- |
| Parent scope | Every result must belong to the requested supplier |
| Filter | Trusted REST framework v4 rowmatch expression; default selects all child rows |
| Verified filters | Equality by `SupplierAddressId` and equality by `City` |
| Ordering | `SupplierAddressId:asc` |
| Pagination | Independent `limit`, `offset`, `count` and `hasMore` envelope |
| Empty result | Valid empty collection; an API error is not an empty result |

Raw natural language must not become the `q` filter. The caller owns field allowlisting, type checks, literal quoting and escaping.

### Response JSON

```json
{
  "items": [
    {
      "SupplierAddressId": 0,
      "AddressName": "<value>",
      "CountryCode": "<value>",
      "AddressLine1": "<value>",
      "City": "<value>",
      "State": "<value>",
      "PostalCode": "<value>"
    }
  ],
  "count": 1,
  "hasMore": false,
  "limit": 25,
  "offset": 0
}
```

The native item contains additional scalar fields. The shown fields document the structural contract, not a projection or reusable data record.

## First successful BO GET sample

Captured once from `XDX_SUPPLIER_INFORMATION.ListSupplierAddresses` at `2026-09-16T20:15:25.2865354-05:00`. Complete retained JSON (source-only reference: ../../builds/xdx-supplier-information/live-details/ListSupplierAddresses-baseline.json) contains 25 items. The excerpt below preserves the exact first item and original envelope values; 24 remaining items are omitted from this document. Later address GETs do not replace this sample.

```json
{
  "items": [
    {
      "SupplierAddressId": 300000047507644,
      "AddressName": "OD US1",
      "CountryCode": "US",
      "Country": "United States",
      "AddressLine1": "6600 N MILITARY TRL",
      "AddressLine2": null,
      "AddressLine3": null,
      "AddressLine4": null,
      "City": "BOCA RATON",
      "State": "FL",
      "PostalCode": "33496",
      "PostalCodeExtension": "2434",
      "Province": null,
      "County": "PALM BEACH",
      "Building": null,
      "FloorNumber": null,
      "PhoneticAddress": null,
      "LanguageCode": "US",
      "Language": "American English",
      "Addressee": null,
      "GlobalLocationNumber": null,
      "AdditionalAddressAttribute1": null,
      "AdditionalAddressAttribute2": null,
      "AdditionalAddressAttribute3": null,
      "AdditionalAddressAttribute4": null,
      "AdditionalAddressAttribute5": null,
      "FormattedAddress": "6600 N MILITARY TRL,BOCA RATON, FL 33496 PALM BEACH",
      "AddressPurposeOrderingFlag": true,
      "AddressPurposeRemitToFlag": true,
      "AddressPurposeRFQOrBiddingFlag": false,
      "PhoneCountryCode": null,
      "PhoneAreaCode": null,
      "PhoneNumber": null,
      "PhoneExtension": null,
      "FaxCountryCode": null,
      "FaxAreaCode": null,
      "FaxNumber": null,
      "Email": null,
      "InactiveDate": "4712-12-31",
      "Status": "ACTIVE",
      "CreationDate": "2013-11-12T15:49:20.398-06:00",
      "CreatedBy": "CALVIN.ROTH",
      "LastUpdateDate": "2018-12-04T14:14:57.692-06:00",
      "LastUpdatedBy": "CALVIN.ROTH",
      "AddressPartyNumber": "1150"
    }
  ],
  "count": 25,
  "hasMore": false,
  "limit": 25,
  "offset": 0
}
```

## POST operation

The create operation ID is `create_suppliers-addresses`. The 26C OpenAPI request schema has 38 properties and marks `CountryCode` and `Email` as required. The nine-field vendor example uses `Country` and omits both `CountryCode` and `Email`. Resolve this contradiction against current metadata before execution.

### Autogenerated fields

| Field | POST treatment | Evidence and scope |
| --- | --- | --- |
| `SupplierAddressId` | Omit the new address ID and capture the returned value | Omitted in successful POST, 2026-09-17, eqih-dev21 / 11.13.18.05; request and response (source-only reference: ../../builds/xdx-supplier-information/live-post/create-address.json). Initial derivation hypothesis confirmed for this scope. |
| `AddressPartyNumber` | Omit; retain generated response value | Same successful omitted-field request/response; revalidate across changed tenant numbering configuration. |

### Required and unique field constraints

Additional confirmation: the 1497 address POST (source-only reference: ../../builds/xdx-supplier-information/live-post/children-1497-create/address-post.json) again omitted SupplierAddressId and AddressPartyNumber and received both, with persisted GET (source-only reference: ../../builds/xdx-supplier-information/live-post/children-1497-create/address-get.json), on 2026-09-17 in the same tenant/release. This supplements the generated-field evidence without changing the immutable first-success sample.

| Field | Requiredness | Uniqueness scope | Test-data treatment | Evidence |
| --- | --- | --- | --- | --- |
| `AddressName` | Present in the vendor example; requiredness is not established by the reviewed schema's required list | Within the selected supplier parent: `(SupplierId, AddressName)` | Generate a distinctive address name for that supplier; compare with available saved addresses under the same parent | User-confirmed uniqueness, 2026-09-17; no duplicate-name POST tested |
| At least one address-purpose flag | Conditionally required by the tenant: one of `AddressPurposeOrderingFlag`, `AddressPurposeRemitToFlag`, or `AddressPurposeRFQOrBiddingFlag` must be true | Per address | For the streamlined purchasing golden path, send only `AddressPurposeOrderingFlag: true`; omit the other purpose flags | Tenant rejection `POZ-2130428`, 2026-09-23, when all purpose flags were omitted |

Do not impose collection-wide address-name uniqueness across different suppliers. Confirm requiredness, length and normalization from the exact Oracle operation documentation before executing a create; this user confirmation establishes uniqueness scope only. Saved addresses cannot prove current absence if their capture is incomplete or stale.

### Candidate request JSON

```json
{
  "AddressName": "<unique approved test address name>",
  "CountryCode": "<validated code>",
  "AddressLine1": "<approved test address>",
  "City": "<approved city>",
  "State": "<validated subdivision>",
  "PostalCode": "<approved postal code>",
  "Email": "<controlled test destination>",
  "AddressPurposeOrderingFlag": true,
  "AddressPurposeRemitToFlag": false,
  "AddressPurposeRFQOrBiddingFlag": false
}
```

Resolve country and subdivision codes from authorized evidence. Reuse a source physical address only when the user explicitly approves that basis; never copy an operational email destination. Preview the parent supplier and purposes before execution. The authorized 2026-09-17 Lee-based test supplied CountryCode and a non-deliverable Email, succeeded and passed parent-scoped GET verification. This does not resolve whether Email may be omitted. Request fields and evidence are in the POST review (source-only reference: ../../builds/xdx-supplier-information/xdx_supplier_post_review.md).

The 2026-09-24 XDX Supplier Core native DRAFT acceptance omitted SupplierAddressId and AddressPartyNumber, returned300000333814416 and1486638 under supplier300000333814409, and independently verified all eight approved business fields including ordering=true. See native receipt (source-only reference: ../../builds/xdx-supplier-core-20260924/evidence/xdx_p3_native_address.md). This corroborates existing generated-field treatment in eqih-dev21 / 11.13.18.05; it does not broaden requiredness or uniqueness, and the immutable first GET sample is unchanged.

## Evidence and limits

- Core live summary (source-only reference: ../../builds/xdx-supplier-information/live-details/summary.json) records baseline, ID filter, offset paging and empty-result checks.
- Text-filter summary (source-only reference: ../../builds/xdx-supplier-information/live-details/text-filter-summary.json) records a City equality check.
- The verified baseline contained 25 terminal rows for one authorized supplier. That count is evidence for one run, not a universal cardinality.
- Partial text, special-character and case behavior remain unverified.
- Revalidate on API release, OpenAPI, address validation, lookup, parent identity, permission or local BO definition changes.

## Change history

| Date | Evidence | Change |
| --- | --- | --- |
| 2026-09-25 | Supplier Core number404 repair and user-confirmed six-step manual query acceptance | Link parent-number resolution to the Suppliers GET owner; no new child API or write behavior claimed. |
| 2026-09-24 | XDX Supplier Core exact-approved native POST and independent GET | Corroborated existing generated-field treatment and required payload in the tested tenant; retained first GET sample and unresolved uniqueness limits. |
| 2026-09-23 | Live create rejection `POZ-2130428` under supplier 1504 | Established the tenant's conditional purpose requirement. The streamlined golden path now sends only `AddressPurposeOrderingFlag: true`; the rejected POST created no address. |
| 2026-09-17 | Supplier 1497 child POST/GET | Added same-tenant confirmation of generated address ID/party number and all ten submitted fields. |
| 2026-09-17 | Authorized POST request/response and parent-scoped GET under live-post | Confirmed omitted generated IDs for the tested tenant and recorded POST/schema limits; immutable first-success GET sample preserved. |
| 2026-09-17 | User confirmation | Recorded supplier-parent-scoped `AddressName` uniqueness; kept requiredness distinct and GET samples unchanged. |
| 2026-09-17 | First retained `ListSupplierAddresses` BO response | Added immutable first-success GET excerpt and link to complete JSON; later GET evidence does not refresh it. |
| 2026-09-17 | Parent-scoped live GET receipts and Oracle 26C GET/POST documentation | Established Supplier Addresses as the owner for GET filtering/paging, response JSON, create-request JSON and the unresolved `CountryCode`/`Email` vendor-example discrepancy. |
