# Agent-App Build Startup Contract

This package configures a new AI Studio agent-app build. It is not a second
lifecycle owner; the target repository's canonical living playbook remains
authoritative.

## Non-negotiable startup order

1. Create a **new Git worktree** for this app build. Do not build in the base
   checkout or reuse an existing worktree.
2. Run `scripts/Verify-AgentAppBuildStartup.ps1` from this package.
3. Initialize the build records from `templates/` under the new worktree's
   active build directory.
4. Read the active handoff, then the target repository's canonical playbook.
5. Read `.agents/skills/aistudio/SKILL.md` and only the prompt references that
   match the requested artifact.
6. Complete the requirement-slice register and architecture self-review before
   creating an artifact, saving a DRAFT, recording a test, or running a suite.

## Context reset

At 70–75% context usage, stop at a safe checkpoint. Update the active handoff,
checkpoint, and time tracker; record the next smallest action; then start a
fresh agent session. Do not continue into a new material edit, record-now
operation, suite, deployment, or push after this threshold.

## MVP and test boundary

Start with the approved MVP golden-path manifest. A test is allowed only when
it maps to one approved requirement ID, route, terminal owner, and acceptance
criterion. Exploratory scenarios, prompt variants, duplicate paths, broad
edge-case matrices, model sweeps, deferred routes, and tests outside the
manifest require explicit user approval.

ATLAS sync plans are the authoritative next-action source for allowed tests.
Do one current plan action, refresh the plan, and do not invent a test merely
because it looks useful for coverage.

## Architecture self-review

Decompose each requirement into the smallest independently verifiable slice:

```text
requirement -> acceptance -> source/tool -> owner -> route -> terminal output
-> deterministic check -> golden-path test -> evidence receipt
```

Before adding any artifact, route, test, or dependency, complete the
architecture self-review. Each slice has one owner and one terminal output
owner. Deferred work belongs in a named future milestone, not in speculative
artifacts or tangential tests.
