# Build Intake and Learning Register

## Build contract

| Field | Value |
| --- | --- |
| Build ID | `<BUILD-ID>` |
| Worktree | `<ABSOLUTE-WORKTREE-PATH>` |
| Branch | `<BRANCH>` |
| MVP outcome | `<OUTCOME>` |
| Included requirement IDs | `<REQ-IDS>` |
| Deferred milestones | `<MILESTONES>` |
| Remote mutation authority | `<AUTHORIZED / NOT AUTHORIZED>` |
| Test authority | MVP golden paths only unless explicitly expanded |

## Learning register

| Timestamp | Slice | Observation | Evidence | Cost | Reusable lesson | Action |
| --- | --- | --- | --- | --- | --- | --- |
