# Agent-App Build Startup Package

Machine bootstrap package for a new AI Studio agent-app build.

## Why developers use it

Use it to turn an agent-app build from a series of rediscovered decisions into
a controlled, auditable delivery flow. Isolated worktrees protect customer work
from unrelated state, while explicit MVP requirements, golden paths, ATLAS next
actions, and cost evidence reduce tangential testing, rework, and late surprises.

## Structure

```mermaid
flowchart TD
  A[New AI Studio app request] --> B[New Git worktree]
  B --> C[Verify startup package]
  C --> D[AGENTS.md startup contract]
  D --> E[Active handoff and tracking records]
  E --> F[Requirement slice register]
  F --> G[Architecture self-review]
  G --> H[MVP golden-path manifest]
  H --> I[AI Studio skill and ATLAS sync loop]
  I --> J[Focused evidence and delivery receipt]

  D --> K[Context reset at 70-75 percent]
  K --> E

  subgraph Package[agent-app-build-startup]
    L[AGENTS.md]
    M[scripts: worktree, verify, time record]
    N[operations: architecture, testing, reset, AI Studio and ATLAS]
    O[templates: intake, slices, golden paths, checkpoint, delivery]
  end

  C --- M
  D --- L
  E --- O
  G --- N
  H --- N
```

## Install contract

1. Place this package in the target repository.
2. Create a new worktree with `scripts/New-AgentAppBuildWorktree.ps1`.
3. In that worktree, run `scripts/Verify-AgentAppBuildStartup.ps1`.
4. Copy the package `AGENTS.md` to the worktree root only when the user has
   authorized replacing the target repository's root agent instructions; merge
   compatible repository-specific instructions instead of silently overwriting.
5. Materialize the files in `templates/` into the build's active record area
   and replace the target repository's active handoff with the new build's
   handoff template.

## Package boundaries

- Canonical lifecycle policy: target repository playbook.
- AI Studio and ATLAS rules: target repository `.agents/skills/aistudio/`.
- This package: startup isolation, tracking shapes, MVP test guardrails,
  context-reset protocol, and verification of its own required files.
