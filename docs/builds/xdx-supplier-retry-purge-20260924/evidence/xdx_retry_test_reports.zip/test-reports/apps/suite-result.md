# App Test Suite Result

App tests: 1/1 passed, 0 failed, 0 need judge.

Reports:
- Consolidated report: [suite-result.html](test-reports/suite-result.html)
- App suite: passed 1/1, report: [suite-result.html](test-reports/apps/suite-result.html)

HTML Report: test-reports/apps/suite-result.html
Top Level Report: test-reports/suite-result.html

## Action Required

None.

| Status | App | Panel | Test | Widgets | Judge | Report |
| --- | --- | --- | --- | --- | --- | --- |
| passed | XDX_SUPPLIER_LIFECYCLE | xdx_supplier_advisor | init_display_xdx_supplier_advisor | cardWidget (passed) | passed (5/5) | test-reports/apps/xdx_supplier_lifecycle/init_display_xdx_supplier_advisor/result.html |
