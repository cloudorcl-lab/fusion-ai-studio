# AI Studio Test Suite Result

Total: 20
Passed: 20
Failed: 0
Needs Judge: 0

Workflow suites: 1 backing workflow report(s)
App suite: test-reports/apps/xdx_supplier_lifecycle/suite-result.html

## App Suite Summary

App tests: 1/1 passed, 0 failed, 0 need judge.

## Backing Workflow Suite Summaries

1. XDX Supplier Lifecycle Agent
   Status: passed
   Report: [suite-result.html](test-reports/workflows/xdx_supplier_lifecycle_agent/suite-result.html)
   Tests: 19/19 passed, 0 failed, 0 need judge

   Metrics:
   - Token data: observed for 19/19 cases; input 870927; output 69679; total 940606.
   - AI units: 755 total (151 token units, 19/19 cases computed).
   - Latency: total workflow time 413.6s across 19/19 model-backed cases.

   Optimization:
   - Model optimization is available for this workflow. 19 passing tests exercise model-backed nodes.
   - Next action: Run node-level model optimization sweep. To run it, reply: Run the model optimization sweep for this workflow and summarize the best model placement per LLM node.
   - Creates a fresh node-level sweep, runs every candidate profile, judges results, and generates the sweep report.
   - The sweep reports recommendations only. Applying model changes requires a separate approval.
   - For a workflow-wide model comparison instead, reply: Run a workflow-level model optimization sweep.

## Action Required

None.
