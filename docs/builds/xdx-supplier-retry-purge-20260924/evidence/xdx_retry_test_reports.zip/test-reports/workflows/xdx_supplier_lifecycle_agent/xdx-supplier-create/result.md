# Workflow Conversation Test Result: xdx-supplier-create

**Status:** PASSED
**Workflow:** XDX_SUPPLIER_LIFECYCLE_AGENT (DRAFT v86153667)
**Goal:** Record one authorized actual supplier POST after exact approval and duplicate preflight, capture generated keys and independent persisted GET. Never record this conversation again after an accepted or uncertain POST.
**Data Source:** File replay
**Evaluation:** Hybrid
**Steps:** 4

## Conversation Journey

| # | Step | Type | Intent | Interaction | Outcome | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | prepare-required-supplier | chat | Prepare a new supplier draft named XDX Lifecycle Retry 20260923 A. Set business relationship to Spend Authorized and tax organization type to Corporation. | Prepare a new supplier draft named XDX Lifecycle Retry 20260923 A. Set business relationship to Spend Authorized and tax organization type to Corporation. | <oraInfoDisplay key="list"><br>{<br>  "title": "Supplier draft revision 1",<br>  "patternId": "multiRecordWidget",<br>  "description": "Supplier draft details with current revision and validation status",<br>  "properties": {<br>    "subtitle": "Draft updated. Any previous approval is invalid. No supplier has been created.",<br>    "selectMode": "none",<br>    "cols": ["Field", "Value"],<br>    "rows": [<br>      {<br>        "cells": ["Supplier", "XDX Lifecycle Retry 20260923 A"]<br>      },<br>      {<br>        "cells": ["Business Relationship", "Spend Authorized"]<br>      },<br>      {<br>        "cells": ["Tax Organization Type", "Corporation"]<br>      }<br>    ]<br>  }<br>}<br></oraInfoDisplay> | passed |
| 2 | review-required-supplier | chat | Review the exact supplier draft. | Review the exact supplier draft. | <oraInfoDisplay key="list"><br>{<br>  "title": "Supplier draft revision 1",<br>  "patternId": "multiRecordWidget",<br>  "description": "Exact required supplier payload fields for review",<br>  "properties": {<br>    "subtitle": "Review these exact three fields. To approve this draft without creating it, enter: Approve supplier revision 1.",<br>    "selectMode": "none",<br>    "cols": ["Field", "Value"],<br>    "rows": [<br>      {<br>        "cells": ["Supplier", "XDX Lifecycle Retry 20260923 A"]<br>      },<br>      {<br>        "cells": ["BusinessRelationship", "Spend Authorized"]<br>      },<br>      {<br>        "cells": ["TaxOrganizationType", "Corporation"]<br>      }<br>    ]<br>  }<br>}<br></oraInfoDisplay> | passed |
| 3 | approve-required-supplier | chat | Approve supplier revision 1 | Approve supplier revision 1 | <oraInfoDisplay key="list"><br>{<br>  "title": "Supplier draft revision 1",<br>  "patternId": "multiRecordWidget",<br>  "description": "Exact required supplier payload fields and values",<br>  "properties": {<br>    "subtitle": "Supplier draft revision 1 is approved. No supplier has been created. To create this exact approved payload, enter: Create supplier revision 1.",<br>    "cols": ["Field", "Value"],<br>    "rows": [<br>      {<br>        "cells": ["Supplier", "XDX Lifecycle Retry 20260923 A"]<br>      },<br>      {<br>        "cells": ["BusinessRelationship", "Spend Authorized"]<br>      },<br>      {<br>        "cells": ["TaxOrganizationType", "Corporation"]<br>      }<br>    ],<br>    "selectMode": "none"<br>  }<br>}<br></oraInfoDisplay> | passed |
| 4 | create-approved-supplier | chat | Create supplier revision 1 | Create supplier revision 1 | <oraInfoDisplay key="supplier-create-confirmation">{"title":"Supplier creation","patternId":"multiRecordWidget","description":"Supplier creation and independent verification result","properties":{"subtitle":"Supplier created once and independently confirmed. Supplier number: 1505.","selectMode":"none","cols":["Supplier","Supplier number","Business relationship","Tax organization type"],"rows":[{"cells":["XDX Lifecycle Retry 20260923 A","1505","Spend Authorized","Corporation"]}]}}</oraInfoDisplay> | passed |

## Step 1: prepare-required-supplier

**Status:** passed
**Type:** chat
**Intent:** Prepare a new supplier draft named XDX Lifecycle Retry 20260923 A. Set business relationship to Spend Authorized and tax organization type to Corporation.
**Context Step IDs:** None (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Prepare a new supplier draft named XDX Lifecycle Retry 20260923 A. Set business relationship to Spend Authorized and tax organization type to Corporation.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="list">
{
  "title": "Supplier draft revision 1",
  "patternId": "multiRecordWidget",
  "description": "Supplier draft details with current revision and validation status",
  "properties": {
    "subtitle": "Draft updated. Any previous approval is invalid. No supplier has been created.",
    "selectMode": "none",
    "cols": ["Field", "Value"],
    "rows": [
      {
        "cells": ["Supplier", "XDX Lifecycle Retry 20260923 A"]
      },
      {
        "cells": ["Business Relationship", "Spend Authorized"]
      },
      {
        "cells": ["Tax Organization Type", "Corporation"]
      }
    ]
  }
}
</oraInfoDisplay>
~~~

## Step 2: review-required-supplier

**Status:** passed
**Type:** chat
**Intent:** Review the exact supplier draft.
**Context Step IDs:** None (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Review the exact supplier draft.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="list">
{
  "title": "Supplier draft revision 1",
  "patternId": "multiRecordWidget",
  "description": "Exact required supplier payload fields for review",
  "properties": {
    "subtitle": "Review these exact three fields. To approve this draft without creating it, enter: Approve supplier revision 1.",
    "selectMode": "none",
    "cols": ["Field", "Value"],
    "rows": [
      {
        "cells": ["Supplier", "XDX Lifecycle Retry 20260923 A"]
      },
      {
        "cells": ["BusinessRelationship", "Spend Authorized"]
      },
      {
        "cells": ["TaxOrganizationType", "Corporation"]
      }
    ]
  }
}
</oraInfoDisplay>
~~~

## Step 3: approve-required-supplier

**Status:** passed
**Type:** chat
**Intent:** Approve supplier revision 1
**Context Step IDs:** None (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Approve supplier revision 1",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="list">
{
  "title": "Supplier draft revision 1",
  "patternId": "multiRecordWidget",
  "description": "Exact required supplier payload fields and values",
  "properties": {
    "subtitle": "Supplier draft revision 1 is approved. No supplier has been created. To create this exact approved payload, enter: Create supplier revision 1.",
    "cols": ["Field", "Value"],
    "rows": [
      {
        "cells": ["Supplier", "XDX Lifecycle Retry 20260923 A"]
      },
      {
        "cells": ["BusinessRelationship", "Spend Authorized"]
      },
      {
        "cells": ["TaxOrganizationType", "Corporation"]
      }
    ],
    "selectMode": "none"
  }
}
</oraInfoDisplay>
~~~

## Step 4: create-approved-supplier

**Status:** passed
**Type:** chat
**Intent:** Create supplier revision 1
**Context Step IDs:** None (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Create supplier revision 1",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="supplier-create-confirmation">{"title":"Supplier creation","patternId":"multiRecordWidget","description":"Supplier creation and independent verification result","properties":{"subtitle":"Supplier created once and independently confirmed. Supplier number: 1505.","selectMode":"none","cols":["Supplier","Supplier number","Business relationship","Tax organization type"],"rows":[{"cells":["XDX Lifecycle Retry 20260923 A","1505","Spend Authorized","Corporation"]}]}}</oraInfoDisplay>
~~~

## Verification Summary

| Verification | Status | Result |
| --- | --- | --- |
| Node order and counts | PASSED | 5/5 passed |
| Path assertions | PASSED | 996/996 passed |
| Node assertions | PASSED | 8/8 passed |
| Semantic evaluation | PASSED | 1/1 passed |
| Workflow run checks | PASSED | 6/6 passed |
| Output checks | PASSED | 8/8 passed |

## Node Order and Count

### Required Relative Order

Other nodes may execute between the listed nodes.

| Step | Status | Assertion | Required Relative Order | Observed or Failure |
| --- | --- | --- | --- | --- |
| prepare-required-supplier | PASS | Required execution order | XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE |
| review-required-supplier | PASS | Required execution order | XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE |
| approve-required-supplier | PASS | Required execution order | XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE |
| create-approved-supplier | PASS | Required execution order | XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_ROUTE_REQUEST_INTENT -> XDX_PREPARE_SUPPLIER_CREATE -> XDX_VALID_SUPPLIER_CREATE -> XDX_CHECK_SUPPLIER_DUPLICATE -> XDX_DECIDE_SUPPLIER_CREATE -> XDX_CAN_POST_SUPPLIER -> XDX_SAVE_SUPPLIER_ATTEMPT -> XDX_CREATE_SUPPLIER -> XDX_VERIFY_SUPPLIER -> XDX_CONFIRM_SUPPLIER_CREATE -> XDX_SAVE_SUPPLIER_CONFIRMATION -> XDX_SUPPLIER_CREATE_RESULT | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_PREPARE_SUPPLIER_CREATE -> XDX_VALID_SUPPLIER_CREATE -> XDX_CHECK_SUPPLIER_DUPLICATE -> XDX_DECIDE_SUPPLIER_CREATE -> XDX_CAN_POST_SUPPLIER -> XDX_SAVE_SUPPLIER_ATTEMPT -> XDX_CREATE_SUPPLIER -> XDX_VERIFY_SUPPLIER -> XDX_CONFIRM_SUPPLIER_CREATE -> XDX_SAVE_SUPPLIER_CONFIRMATION -> XDX_SUPPLIER_CREATE_RESULT |

### Node Count Checks

| Step | Assertion | Node Code | Expected | Observed | Status |
| --- | --- | --- | --- | --- | --- |
| create-approved-supplier | Supplier POST executes exactly once | XDX_CREATE_SUPPLIER | exactly 1 | 1 | PASS |

## Path Assertions

| Step | Status | Assertion | Requirement | Node Code | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-supplier | PASS | XDX_ROUTE_APP_STAGE executes | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| prepare-required-supplier | PASS | XDX_EXTRACT_SEARCH executes | Must execute | XDX_EXTRACT_SEARCH | Executed |
| prepare-required-supplier | PASS | XDX_ROUTE_REQUEST_INTENT executes | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| prepare-required-supplier | PASS | XDX_REDUCE_SUPPLIER_DRAFT executes | Must execute | XDX_REDUCE_SUPPLIER_DRAFT | Executed |
| prepare-required-supplier | PASS | XDX_SAVE_SUPPLIER_DRAFT executes | Must execute | XDX_SAVE_SUPPLIER_DRAFT | Executed |
| prepare-required-supplier | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| prepare-required-supplier | PASS | XDX_SUPPLIER_DRAFT_RESPONSE executes | Must execute | XDX_SUPPLIER_DRAFT_RESPONSE | Executed |
| prepare-required-supplier | PASS | XDX_INITIAL_DISPLAY inactive | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| prepare-required-supplier | PASS | XDX_PREPARE_SEARCH inactive | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| prepare-required-supplier | PASS | XDX_VALID_SEARCH inactive | Must not execute | XDX_VALID_SEARCH | Not executed |
| prepare-required-supplier | PASS | XDX_REQUEST_SEARCH_NAME inactive | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| prepare-required-supplier | PASS | XDX_FETCH_SUPPLIERS inactive | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| prepare-required-supplier | PASS | XDX_QUERY_RESPONSE inactive | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| prepare-required-supplier | PASS | XDX_ROUTE_READ_RESOURCE inactive | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| prepare-required-supplier | PASS | XDX_RESOLVE_SUPPLIER inactive | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| prepare-required-supplier | PASS | XDX_VALID_PARENT inactive | Must not execute | XDX_VALID_PARENT | Not executed |
| prepare-required-supplier | PASS | XDX_REQUEST_EXACT_PARENT inactive | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| prepare-required-supplier | PASS | XDX_FETCH_ADDRESSES inactive | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| prepare-required-supplier | PASS | XDX_ADDRESS_RESPONSE inactive | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| prepare-required-supplier | PASS | XDX_ROUTE_CHILD_READ inactive | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| prepare-required-supplier | PASS | XDX_FETCH_SITES inactive | Must not execute | XDX_FETCH_SITES | Not executed |
| prepare-required-supplier | PASS | XDX_SITE_RESPONSE inactive | Must not execute | XDX_SITE_RESPONSE | Not executed |
| prepare-required-supplier | PASS | XDX_FETCH_CONTACTS inactive | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| prepare-required-supplier | PASS | XDX_CONTACT_RESPONSE inactive | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| prepare-required-supplier | PASS | XDX_PREPARE_SUPPLIER_CREATE inactive | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| prepare-required-supplier | PASS | XDX_VALID_SUPPLIER_CREATE inactive | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| prepare-required-supplier | PASS | XDX_CHECK_SUPPLIER_DUPLICATE inactive | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| prepare-required-supplier | PASS | XDX_DECIDE_SUPPLIER_CREATE inactive | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| prepare-required-supplier | PASS | XDX_CAN_POST_SUPPLIER inactive | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| prepare-required-supplier | PASS | XDX_SAVE_SUPPLIER_ATTEMPT inactive | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| prepare-required-supplier | PASS | XDX_SAVE_SUPPLIER_RECONCILIATION inactive | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| prepare-required-supplier | PASS | XDX_CREATE_SUPPLIER inactive | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| prepare-required-supplier | PASS | XDX_VERIFY_SUPPLIER inactive | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| prepare-required-supplier | PASS | XDX_CONFIRM_SUPPLIER_CREATE inactive | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| prepare-required-supplier | PASS | XDX_SAVE_SUPPLIER_CONFIRMATION inactive | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| prepare-required-supplier | PASS | XDX_SUPPLIER_CREATE_BLOCKED inactive | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| prepare-required-supplier | PASS | XDX_SUPPLIER_CREATE_DECISION inactive | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| prepare-required-supplier | PASS | XDX_SUPPLIER_CREATE_RESULT inactive | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| prepare-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| prepare-required-supplier | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| prepare-required-supplier | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| prepare-required-supplier | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| prepare-required-supplier | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| prepare-required-supplier | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| prepare-required-supplier | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| prepare-required-supplier | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| prepare-required-supplier | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| prepare-required-supplier | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| prepare-required-supplier | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| prepare-required-supplier | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| prepare-required-supplier | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| prepare-required-supplier | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| prepare-required-supplier | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| prepare-required-supplier | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| prepare-required-supplier | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| prepare-required-supplier | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| prepare-required-supplier | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| prepare-required-supplier | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| prepare-required-supplier | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-supplier | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-supplier | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-supplier | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| prepare-required-supplier | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| prepare-required-supplier | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| prepare-required-supplier | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| review-required-supplier | PASS | XDX_ROUTE_APP_STAGE executes | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| review-required-supplier | PASS | XDX_EXTRACT_SEARCH executes | Must execute | XDX_EXTRACT_SEARCH | Executed |
| review-required-supplier | PASS | XDX_ROUTE_REQUEST_INTENT executes | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| review-required-supplier | PASS | XDX_REDUCE_SUPPLIER_DRAFT executes | Must execute | XDX_REDUCE_SUPPLIER_DRAFT | Executed |
| review-required-supplier | PASS | XDX_SAVE_SUPPLIER_DRAFT executes | Must execute | XDX_SAVE_SUPPLIER_DRAFT | Executed |
| review-required-supplier | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| review-required-supplier | PASS | XDX_SUPPLIER_DRAFT_RESPONSE executes | Must execute | XDX_SUPPLIER_DRAFT_RESPONSE | Executed |
| review-required-supplier | PASS | XDX_INITIAL_DISPLAY inactive | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| review-required-supplier | PASS | XDX_PREPARE_SEARCH inactive | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| review-required-supplier | PASS | XDX_VALID_SEARCH inactive | Must not execute | XDX_VALID_SEARCH | Not executed |
| review-required-supplier | PASS | XDX_REQUEST_SEARCH_NAME inactive | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| review-required-supplier | PASS | XDX_FETCH_SUPPLIERS inactive | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| review-required-supplier | PASS | XDX_QUERY_RESPONSE inactive | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| review-required-supplier | PASS | XDX_ROUTE_READ_RESOURCE inactive | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| review-required-supplier | PASS | XDX_RESOLVE_SUPPLIER inactive | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| review-required-supplier | PASS | XDX_VALID_PARENT inactive | Must not execute | XDX_VALID_PARENT | Not executed |
| review-required-supplier | PASS | XDX_REQUEST_EXACT_PARENT inactive | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| review-required-supplier | PASS | XDX_FETCH_ADDRESSES inactive | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| review-required-supplier | PASS | XDX_ADDRESS_RESPONSE inactive | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| review-required-supplier | PASS | XDX_ROUTE_CHILD_READ inactive | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| review-required-supplier | PASS | XDX_FETCH_SITES inactive | Must not execute | XDX_FETCH_SITES | Not executed |
| review-required-supplier | PASS | XDX_SITE_RESPONSE inactive | Must not execute | XDX_SITE_RESPONSE | Not executed |
| review-required-supplier | PASS | XDX_FETCH_CONTACTS inactive | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| review-required-supplier | PASS | XDX_CONTACT_RESPONSE inactive | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| review-required-supplier | PASS | XDX_PREPARE_SUPPLIER_CREATE inactive | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| review-required-supplier | PASS | XDX_VALID_SUPPLIER_CREATE inactive | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| review-required-supplier | PASS | XDX_CHECK_SUPPLIER_DUPLICATE inactive | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| review-required-supplier | PASS | XDX_DECIDE_SUPPLIER_CREATE inactive | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| review-required-supplier | PASS | XDX_CAN_POST_SUPPLIER inactive | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| review-required-supplier | PASS | XDX_SAVE_SUPPLIER_ATTEMPT inactive | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| review-required-supplier | PASS | XDX_SAVE_SUPPLIER_RECONCILIATION inactive | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| review-required-supplier | PASS | XDX_CREATE_SUPPLIER inactive | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| review-required-supplier | PASS | XDX_VERIFY_SUPPLIER inactive | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| review-required-supplier | PASS | XDX_CONFIRM_SUPPLIER_CREATE inactive | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| review-required-supplier | PASS | XDX_SAVE_SUPPLIER_CONFIRMATION inactive | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| review-required-supplier | PASS | XDX_SUPPLIER_CREATE_BLOCKED inactive | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| review-required-supplier | PASS | XDX_SUPPLIER_CREATE_DECISION inactive | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| review-required-supplier | PASS | XDX_SUPPLIER_CREATE_RESULT inactive | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| review-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| review-required-supplier | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| review-required-supplier | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| review-required-supplier | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| review-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| review-required-supplier | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| review-required-supplier | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| review-required-supplier | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| review-required-supplier | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| review-required-supplier | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| review-required-supplier | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| review-required-supplier | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| review-required-supplier | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| review-required-supplier | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| review-required-supplier | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| review-required-supplier | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| review-required-supplier | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| review-required-supplier | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| review-required-supplier | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| review-required-supplier | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| review-required-supplier | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| review-required-supplier | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| review-required-supplier | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| review-required-supplier | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| review-required-supplier | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| review-required-supplier | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| review-required-supplier | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| review-required-supplier | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| approve-required-supplier | PASS | XDX_ROUTE_APP_STAGE executes | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| approve-required-supplier | PASS | XDX_EXTRACT_SEARCH executes | Must execute | XDX_EXTRACT_SEARCH | Executed |
| approve-required-supplier | PASS | XDX_ROUTE_REQUEST_INTENT executes | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| approve-required-supplier | PASS | XDX_REDUCE_SUPPLIER_DRAFT executes | Must execute | XDX_REDUCE_SUPPLIER_DRAFT | Executed |
| approve-required-supplier | PASS | XDX_SAVE_SUPPLIER_DRAFT executes | Must execute | XDX_SAVE_SUPPLIER_DRAFT | Executed |
| approve-required-supplier | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| approve-required-supplier | PASS | XDX_SUPPLIER_DRAFT_RESPONSE executes | Must execute | XDX_SUPPLIER_DRAFT_RESPONSE | Executed |
| approve-required-supplier | PASS | XDX_INITIAL_DISPLAY inactive | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| approve-required-supplier | PASS | XDX_PREPARE_SEARCH inactive | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| approve-required-supplier | PASS | XDX_VALID_SEARCH inactive | Must not execute | XDX_VALID_SEARCH | Not executed |
| approve-required-supplier | PASS | XDX_REQUEST_SEARCH_NAME inactive | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| approve-required-supplier | PASS | XDX_FETCH_SUPPLIERS inactive | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| approve-required-supplier | PASS | XDX_QUERY_RESPONSE inactive | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| approve-required-supplier | PASS | XDX_ROUTE_READ_RESOURCE inactive | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| approve-required-supplier | PASS | XDX_RESOLVE_SUPPLIER inactive | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| approve-required-supplier | PASS | XDX_VALID_PARENT inactive | Must not execute | XDX_VALID_PARENT | Not executed |
| approve-required-supplier | PASS | XDX_REQUEST_EXACT_PARENT inactive | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| approve-required-supplier | PASS | XDX_FETCH_ADDRESSES inactive | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| approve-required-supplier | PASS | XDX_ADDRESS_RESPONSE inactive | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| approve-required-supplier | PASS | XDX_ROUTE_CHILD_READ inactive | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| approve-required-supplier | PASS | XDX_FETCH_SITES inactive | Must not execute | XDX_FETCH_SITES | Not executed |
| approve-required-supplier | PASS | XDX_SITE_RESPONSE inactive | Must not execute | XDX_SITE_RESPONSE | Not executed |
| approve-required-supplier | PASS | XDX_FETCH_CONTACTS inactive | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| approve-required-supplier | PASS | XDX_CONTACT_RESPONSE inactive | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| approve-required-supplier | PASS | XDX_PREPARE_SUPPLIER_CREATE inactive | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| approve-required-supplier | PASS | XDX_VALID_SUPPLIER_CREATE inactive | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| approve-required-supplier | PASS | XDX_CHECK_SUPPLIER_DUPLICATE inactive | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| approve-required-supplier | PASS | XDX_DECIDE_SUPPLIER_CREATE inactive | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| approve-required-supplier | PASS | XDX_CAN_POST_SUPPLIER inactive | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| approve-required-supplier | PASS | XDX_SAVE_SUPPLIER_ATTEMPT inactive | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| approve-required-supplier | PASS | XDX_SAVE_SUPPLIER_RECONCILIATION inactive | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| approve-required-supplier | PASS | XDX_CREATE_SUPPLIER inactive | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| approve-required-supplier | PASS | XDX_VERIFY_SUPPLIER inactive | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| approve-required-supplier | PASS | XDX_CONFIRM_SUPPLIER_CREATE inactive | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| approve-required-supplier | PASS | XDX_SAVE_SUPPLIER_CONFIRMATION inactive | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| approve-required-supplier | PASS | XDX_SUPPLIER_CREATE_BLOCKED inactive | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| approve-required-supplier | PASS | XDX_SUPPLIER_CREATE_DECISION inactive | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| approve-required-supplier | PASS | XDX_SUPPLIER_CREATE_RESULT inactive | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| approve-required-supplier | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| approve-required-supplier | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| approve-required-supplier | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| approve-required-supplier | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-required-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| approve-required-supplier | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| approve-required-supplier | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| approve-required-supplier | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| approve-required-supplier | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| approve-required-supplier | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| approve-required-supplier | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| approve-required-supplier | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| approve-required-supplier | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| approve-required-supplier | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| approve-required-supplier | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| approve-required-supplier | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| approve-required-supplier | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| approve-required-supplier | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| approve-required-supplier | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| approve-required-supplier | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| approve-required-supplier | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| approve-required-supplier | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| approve-required-supplier | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| approve-required-supplier | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| approve-required-supplier | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| approve-required-supplier | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| approve-required-supplier | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| approve-required-supplier | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| create-approved-supplier | PASS | XDX_ROUTE_APP_STAGE executes | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| create-approved-supplier | PASS | XDX_EXTRACT_SEARCH executes | Must execute | XDX_EXTRACT_SEARCH | Executed |
| create-approved-supplier | PASS | XDX_ROUTE_REQUEST_INTENT executes | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| create-approved-supplier | PASS | XDX_PREPARE_SUPPLIER_CREATE executes | Must execute | XDX_PREPARE_SUPPLIER_CREATE | Executed |
| create-approved-supplier | PASS | XDX_VALID_SUPPLIER_CREATE executes | Must execute | XDX_VALID_SUPPLIER_CREATE | Executed |
| create-approved-supplier | PASS | XDX_CHECK_SUPPLIER_DUPLICATE executes | Must execute | XDX_CHECK_SUPPLIER_DUPLICATE | Executed |
| create-approved-supplier | PASS | XDX_DECIDE_SUPPLIER_CREATE executes | Must execute | XDX_DECIDE_SUPPLIER_CREATE | Executed |
| create-approved-supplier | PASS | XDX_CAN_POST_SUPPLIER executes | Must execute | XDX_CAN_POST_SUPPLIER | Executed |
| create-approved-supplier | PASS | XDX_SAVE_SUPPLIER_ATTEMPT executes | Must execute | XDX_SAVE_SUPPLIER_ATTEMPT | Executed |
| create-approved-supplier | PASS | XDX_CREATE_SUPPLIER executes | Must execute | XDX_CREATE_SUPPLIER | Executed |
| create-approved-supplier | PASS | XDX_VERIFY_SUPPLIER executes | Must execute | XDX_VERIFY_SUPPLIER | Executed |
| create-approved-supplier | PASS | XDX_CONFIRM_SUPPLIER_CREATE executes | Must execute | XDX_CONFIRM_SUPPLIER_CREATE | Executed |
| create-approved-supplier | PASS | XDX_SAVE_SUPPLIER_CONFIRMATION executes | Must execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Executed |
| create-approved-supplier | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| create-approved-supplier | PASS | XDX_SUPPLIER_CREATE_RESULT executes | Must execute | XDX_SUPPLIER_CREATE_RESULT | Executed |
| create-approved-supplier | PASS | XDX_INITIAL_DISPLAY inactive | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| create-approved-supplier | PASS | XDX_PREPARE_SEARCH inactive | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| create-approved-supplier | PASS | XDX_VALID_SEARCH inactive | Must not execute | XDX_VALID_SEARCH | Not executed |
| create-approved-supplier | PASS | XDX_REQUEST_SEARCH_NAME inactive | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| create-approved-supplier | PASS | XDX_FETCH_SUPPLIERS inactive | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| create-approved-supplier | PASS | XDX_QUERY_RESPONSE inactive | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| create-approved-supplier | PASS | XDX_ROUTE_READ_RESOURCE inactive | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| create-approved-supplier | PASS | XDX_RESOLVE_SUPPLIER inactive | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| create-approved-supplier | PASS | XDX_VALID_PARENT inactive | Must not execute | XDX_VALID_PARENT | Not executed |
| create-approved-supplier | PASS | XDX_REQUEST_EXACT_PARENT inactive | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| create-approved-supplier | PASS | XDX_FETCH_ADDRESSES inactive | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| create-approved-supplier | PASS | XDX_ADDRESS_RESPONSE inactive | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| create-approved-supplier | PASS | XDX_ROUTE_CHILD_READ inactive | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| create-approved-supplier | PASS | XDX_FETCH_SITES inactive | Must not execute | XDX_FETCH_SITES | Not executed |
| create-approved-supplier | PASS | XDX_SITE_RESPONSE inactive | Must not execute | XDX_SITE_RESPONSE | Not executed |
| create-approved-supplier | PASS | XDX_FETCH_CONTACTS inactive | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| create-approved-supplier | PASS | XDX_CONTACT_RESPONSE inactive | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| create-approved-supplier | PASS | XDX_REDUCE_SUPPLIER_DRAFT inactive | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| create-approved-supplier | PASS | XDX_SAVE_SUPPLIER_DRAFT inactive | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| create-approved-supplier | PASS | XDX_SUPPLIER_DRAFT_RESPONSE inactive | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| create-approved-supplier | PASS | XDX_SAVE_SUPPLIER_RECONCILIATION inactive | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| create-approved-supplier | PASS | XDX_SUPPLIER_CREATE_BLOCKED inactive | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| create-approved-supplier | PASS | XDX_SUPPLIER_CREATE_DECISION inactive | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| create-approved-supplier | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| create-approved-supplier | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| create-approved-supplier | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| create-approved-supplier | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| create-approved-supplier | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| create-approved-supplier | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| create-approved-supplier | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| create-approved-supplier | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| create-approved-supplier | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| create-approved-supplier | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| create-approved-supplier | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| create-approved-supplier | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| create-approved-supplier | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| create-approved-supplier | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| create-approved-supplier | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| create-approved-supplier | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| create-approved-supplier | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| create-approved-supplier | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| create-approved-supplier | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| create-approved-supplier | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| create-approved-supplier | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| create-approved-supplier | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-supplier | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-supplier | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-supplier | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| create-approved-supplier | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| create-approved-supplier | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| create-approved-supplier | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |

## Node Assertions

| Step | Status | Assertion | Node Code | Occurrence | Asserted Value | Operator | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| prepare-required-supplier | PASS | name-retained | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/payload/Supplier | equals | "XDX Lifecycle Retry 20260923 A" | string (30 characters) |
| prepare-required-supplier | PASS | revision-retained | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/revision | equals | 1 | number |
| review-required-supplier | PASS | name-retained | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/payload/Supplier | equals | "XDX Lifecycle Retry 20260923 A" | string (30 characters) |
| review-required-supplier | PASS | revision-retained | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/revision | equals | 1 | number |
| approve-required-supplier | PASS | name-retained | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/payload/Supplier | equals | "XDX Lifecycle Retry 20260923 A" | string (30 characters) |
| approve-required-supplier | PASS | revision-retained | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/revision | equals | 1 | number |
| approve-required-supplier | PASS | approved-revision | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/approvedRevision | equals | 1 | number |
| create-approved-supplier | PASS | independent-confirmation | XDX_CONFIRM_SUPPLIER_CREATE | last | output/result/confirmed | equals | true | boolean |

## Semantic Evaluation

| Scope | Status | Score | Summary |
| --- | --- | --- | --- |
| Conversation | passed | 5/5 | All four fresh outputs retain XDX Lifecycle Retry 20260923 A, Spend Authorized and Corporation. Review preserves revision1, approval states no supplier created; fixture-mode creation reports1505 matching retained POST and independent complete GET. Current revision/approval/independent-confirmation checks pass. This is replay proof, not a repeated live write. |

### Criterion Results

| Scope | Status | Assertion | Criterion | Notes |
| --- | --- | --- | --- | --- |
| Conversation | PASS | Exact review before write | The first three outputs preserve the named supplier and both classifications, distinguish approval from creation, and request exact revision approval. The final creation report agrees with deterministic POST and independent GET checks. | All four fresh outputs retain XDX Lifecycle Retry 20260923 A, Spend Authorized and Corporation. Review preserves revision1, approval states no supplier created; fixture-mode creation reports1505 matching retained POST and independent complete GET. Current revision/approval/independent-confirmation checks pass. This is replay proof, not a repeated live write. |

## Workflow Run Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-supplier | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| review-required-supplier | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| approve-required-supplier | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| create-approved-supplier | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| Conversation | PASS | conversationStepOrder | conversationStepOrder | prepare-required-supplier -> review-required-supplier -> approve-required-supplier -> create-approved-supplier | Verified |
| Conversation | PASS | conversationIdReuse | conversationIdReuse | Every executed step uses one conversation ID. | Verified |

## Output Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-supplier | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| prepare-required-supplier | PASS | Expected supplier is displayed | contains | XDX Lifecycle Retry 20260923 A | Found "XDX Lifecycle Retry 20260923 A" |
| review-required-supplier | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| review-required-supplier | PASS | Expected supplier is displayed | contains | XDX Lifecycle Retry 20260923 A | Found "XDX Lifecycle Retry 20260923 A" |
| approve-required-supplier | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| approve-required-supplier | PASS | Expected supplier is displayed | contains | XDX Lifecycle Retry 20260923 A | Found "XDX Lifecycle Retry 20260923 A" |
| create-approved-supplier | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| create-approved-supplier | PASS | Independent confirmation shown | contains | Supplier created once and independently confirmed. | Found "Supplier created once and independently confirmed." |

## Runtime Metrics

Workflow time: 27631 ms (sum of node times)
Test run time: 33500 ms (includes CLI overhead)
Token usage: observed from runtime events

Aggregate Token Usage

| Input Tokens | Output Tokens | Total Tokens | Model |
| --- | --- | --- | --- |
| 35258 | 2746 | 38004 | oci-agent/openai.gpt-4.1-mini-2025-04-14 |

| Node | Input Tokens | Output Tokens | Total Tokens | Model | Source |
| --- | --- | --- | --- | --- | --- |
| approve-required-supplier:XDX_EXTRACT_SEARCH | 4698 | 502 | 5200 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| approve-required-supplier:XDX_SUPPLIER_DRAFT_RESPONSE | 5684 | 235 | 5919 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| create-approved-supplier:XDX_EXTRACT_SEARCH | 4923 | 516 | 5439 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| prepare-required-supplier:XDX_EXTRACT_SEARCH | 4262 | 525 | 4787 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| prepare-required-supplier:XDX_SUPPLIER_DRAFT_RESPONSE | 5580 | 223 | 5803 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| review-required-supplier:XDX_EXTRACT_SEARCH | 4477 | 516 | 4993 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| review-required-supplier:XDX_SUPPLIER_DRAFT_RESPONSE | 5634 | 229 | 5863 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |


AI Units: computed
Total Token Units: 7
Total AI Units: 35

| Node | Input | Output | Token Units | AI Units | Model Type | Action Type |
| --- | --- | --- | --- | --- | --- | --- |
| approve-required-supplier:XDX_EXTRACT_SEARCH | 4698 | 502 | 1 | 5 | premium | general |
| approve-required-supplier:XDX_SUPPLIER_DRAFT_RESPONSE | 5684 | 235 | 1 | 5 | premium | general |
| create-approved-supplier:XDX_EXTRACT_SEARCH | 4923 | 516 | 1 | 5 | premium | general |
| prepare-required-supplier:XDX_EXTRACT_SEARCH | 4262 | 525 | 1 | 5 | premium | general |
| prepare-required-supplier:XDX_SUPPLIER_DRAFT_RESPONSE | 5580 | 223 | 1 | 5 | premium | general |
| review-required-supplier:XDX_EXTRACT_SEARCH | 4477 | 516 | 1 | 5 | premium | general |
| review-required-supplier:XDX_SUPPLIER_DRAFT_RESPONSE | 5634 | 229 | 1 | 5 | premium | general |

| Node | Node Time (ms) | LLM Call Time (ms) | Details |
| --- | --- | --- | --- |
| prepare-required-supplier:XDX_EXTRACT_SEARCH | 2521 | 2440 | 1 runtime detail; see JSON report |
| prepare-required-supplier:XDX_SUPPLIER_DRAFT_RESPONSE | 1365 | 1292 | 1 runtime detail; see JSON report |
| review-required-supplier:XDX_EXTRACT_SEARCH | 2444 | 2365 | 1 runtime detail; see JSON report |
| review-required-supplier:XDX_SUPPLIER_DRAFT_RESPONSE | 1648 | 1571 | 1 runtime detail; see JSON report |
| approve-required-supplier:XDX_EXTRACT_SEARCH | 8003 | 7883 | 1 runtime detail; see JSON report |
| approve-required-supplier:XDX_SUPPLIER_DRAFT_RESPONSE | 1390 | 1291 | 1 runtime detail; see JSON report |
| create-approved-supplier:XDX_EXTRACT_SEARCH | 10122 | 10039 | 1 runtime detail; see JSON report |
| create-approved-supplier:XDX_CHECK_SUPPLIER_DUPLICATE | 45 |  | 0 runtime details; see JSON report |
| create-approved-supplier:XDX_CREATE_SUPPLIER | 46 |  | 0 runtime details; see JSON report |
| create-approved-supplier:XDX_VERIFY_SUPPLIER | 47 |  | 0 runtime details; see JSON report |

| Observed Field | Values |
| --- | --- |
| modelName | "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14" |
| inputTokens | 4262; 5580; 4477; 5634; 4698; 5684; 4923 |
| outputTokens | 525; 223; 516; 229; 502; 235; 516 |

## Test Data

| Step | Data Source | Evaluation |
| --- | --- | --- |
| prepare-required-supplier | File replay | Hybrid |
| review-required-supplier | File replay | Hybrid |
| approve-required-supplier | File replay | Hybrid |
| create-approved-supplier | File replay | Hybrid |

## Workflow Run

### Execution Timeline

| Step | Phase Sequence | Node | Event |
| --- | --- | --- | --- |
| prepare-required-supplier | 1 | START | NODE_EXECUTED |
| prepare-required-supplier | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| prepare-required-supplier | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| prepare-required-supplier | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| prepare-required-supplier | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| prepare-required-supplier | 6 | XDX_REDUCE_SUPPLIER_DRAFT | NODE_EXECUTED |
| prepare-required-supplier | 7 | XDX_SAVE_SUPPLIER_DRAFT | NODE_EXECUTED |
| prepare-required-supplier | 8 | XDX_SUPPLIER_DRAFT_RESPONSE | NODE_START |
| review-required-supplier | 1 | START | NODE_EXECUTED |
| review-required-supplier | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| review-required-supplier | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| review-required-supplier | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| review-required-supplier | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| review-required-supplier | 6 | XDX_REDUCE_SUPPLIER_DRAFT | NODE_EXECUTED |
| review-required-supplier | 7 | XDX_SAVE_SUPPLIER_DRAFT | NODE_EXECUTED |
| review-required-supplier | 8 | XDX_SUPPLIER_DRAFT_RESPONSE | NODE_START |
| approve-required-supplier | 1 | START | NODE_EXECUTED |
| approve-required-supplier | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| approve-required-supplier | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| approve-required-supplier | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| approve-required-supplier | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| approve-required-supplier | 6 | XDX_REDUCE_SUPPLIER_DRAFT | NODE_EXECUTED |
| approve-required-supplier | 7 | XDX_SAVE_SUPPLIER_DRAFT | NODE_EXECUTED |
| approve-required-supplier | 8 | XDX_SUPPLIER_DRAFT_RESPONSE | NODE_START |
| create-approved-supplier | 1 | START | NODE_EXECUTED |
| create-approved-supplier | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| create-approved-supplier | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| create-approved-supplier | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| create-approved-supplier | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| create-approved-supplier | 6 | XDX_PREPARE_SUPPLIER_CREATE | NODE_EXECUTED |
| create-approved-supplier | 7 | XDX_VALID_SUPPLIER_CREATE | NODE_EXECUTED |
| create-approved-supplier | 8 | XDX_CHECK_SUPPLIER_DUPLICATE | NODE_START |
| create-approved-supplier | 9 | XDX_DECIDE_SUPPLIER_CREATE | NODE_EXECUTED |
| create-approved-supplier | 10 | XDX_CAN_POST_SUPPLIER | NODE_EXECUTED |
| create-approved-supplier | 11 | XDX_SAVE_SUPPLIER_ATTEMPT | NODE_EXECUTED |
| create-approved-supplier | 12 | XDX_CREATE_SUPPLIER | NODE_START |
| create-approved-supplier | 13 | XDX_VERIFY_SUPPLIER | NODE_START |
| create-approved-supplier | 14 | XDX_CONFIRM_SUPPLIER_CREATE | NODE_EXECUTED |
| create-approved-supplier | 15 | XDX_SAVE_SUPPLIER_CONFIRMATION | NODE_EXECUTED |
| create-approved-supplier | 16 | XDX_SUPPLIER_CREATE_RESULT | NODE_EXECUTED |

### Other Observed Nodes

| Node | Observed |
| --- | --- |
| START | 4 |
| XDX_CAN_POST_SUPPLIER | 1 |
| XDX_CHECK_SUPPLIER_DUPLICATE | 1 |
| XDX_CONFIRM_SUPPLIER_CREATE | 1 |
| XDX_DECIDE_SUPPLIER_CREATE | 1 |
| XDX_EXTRACT_SEARCH | 4 |
| XDX_NORMALIZE_REQUEST | 4 |
| XDX_PREPARE_SUPPLIER_CREATE | 1 |
| XDX_REDUCE_SUPPLIER_DRAFT | 3 |
| XDX_ROUTE_APP_STAGE | 4 |
| XDX_ROUTE_REQUEST_INTENT | 4 |
| XDX_SAVE_SUPPLIER_ATTEMPT | 1 |
| XDX_SAVE_SUPPLIER_CONFIRMATION | 1 |
| XDX_SAVE_SUPPLIER_DRAFT | 3 |
| XDX_SUPPLIER_CREATE_RESULT | 1 |
| XDX_SUPPLIER_DRAFT_RESPONSE | 3 |
| XDX_VALID_SUPPLIER_CREATE | 1 |
| XDX_VERIFY_SUPPLIER | 1 |

## Report Files

- JSON report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-supplier-create\result.json`
- Markdown report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-supplier-create\result.md`
- Test file: `test/workflows/xdx_supplier_lifecycle_agent/xdx-supplier-create.json`
