# Workflow Conversation Test Result: xdx-contact-address-create

**Status:** PASSED
**Workflow:** XDX_SUPPLIER_LIFECYCLE_AGENT (DRAFT v86153667)
**Goal:** Prepare, review and approve the exact supplier/contact/address, then create one association and verify generated key plus submitted address reference.
**Data Source:** File replay
**Evaluation:** Deterministic
**Steps:** 4

## Conversation Journey

| # | Step | Type | Intent | Interaction | Outcome | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | prepare-required-link | chat | Prepare a contact-address association draft for supplier XDX Lifecycle Retry 20260923 A, contact email xdx-contact-retry-20260923-a@example.invalid, and existing supplier address XDX HQ Retry 20260923 A. | Prepare a contact-address association draft for supplier XDX Lifecycle Retry 20260923 A, contact email xdx-contact-retry-20260923-a@example.invalid, and existing supplier address XDX HQ Retry 20260923 A. | <oraInfoDisplay key="contact-address-review">{"patternId":"multiRecordWidget","title":"Contact-address draft revision 1","description":"Contact-address draft saved. No association has been created.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Contact email","xdx-contact-retry-20260923-a@example.invalid"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]}]}}</oraInfoDisplay> | passed |
| 2 | review-link-references | chat | Review the exact contact-address draft. | Review the exact contact-address draft. | <oraInfoDisplay key="contact-address-review">{"patternId":"multiRecordWidget","title":"Contact-address draft revision 1","description":"Review this supplier, contact and existing address. The request contains only the resolved address reference. To approve without writing, enter: Approve contact-address revision 1.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Contact email","xdx-contact-retry-20260923-a@example.invalid"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]}]}}</oraInfoDisplay> | passed |
| 3 | approve-exact-link | chat | Approve contact-address revision 1 | Approve contact-address revision 1 | <oraInfoDisplay key="contact-address-review">{"patternId":"multiRecordWidget","title":"Contact-address draft revision 1","description":"Contact-address revision 1 approved without writing. To create this exact link, enter: Create contact-address revision 1.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Contact email","xdx-contact-retry-20260923-a@example.invalid"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]}]}}</oraInfoDisplay> | passed |
| 4 | create-approved-link | chat | Create contact-address revision 1 | Create contact-address revision 1 | <oraInfoDisplay key="contact-address-review">{"patternId":"multiRecordWidget","title":"Contact-address draft revision 1","description":"Contact-address association created and independently verified.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Contact email","xdx-contact-retry-20260923-a@example.invalid"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]}]}}</oraInfoDisplay> | passed |

## Step 1: prepare-required-link

**Status:** passed
**Type:** chat
**Intent:** Prepare a contact-address association draft for supplier XDX Lifecycle Retry 20260923 A, contact email xdx-contact-retry-20260923-a@example.invalid, and existing supplier address XDX HQ Retry 20260923 A.
**Context Step IDs:** None (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Prepare a contact-address association draft for supplier XDX Lifecycle Retry 20260923 A, contact email xdx-contact-retry-20260923-a@example.invalid, and existing supplier address XDX HQ Retry 20260923 A.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="contact-address-review">{"patternId":"multiRecordWidget","title":"Contact-address draft revision 1","description":"Contact-address draft saved. No association has been created.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Contact email","xdx-contact-retry-20260923-a@example.invalid"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]}]}}</oraInfoDisplay>
~~~

## Step 2: review-link-references

**Status:** passed
**Type:** chat
**Intent:** Review the exact contact-address draft.
**Context Step IDs:** prepare-required-link (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Review the exact contact-address draft.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="contact-address-review">{"patternId":"multiRecordWidget","title":"Contact-address draft revision 1","description":"Review this supplier, contact and existing address. The request contains only the resolved address reference. To approve without writing, enter: Approve contact-address revision 1.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Contact email","xdx-contact-retry-20260923-a@example.invalid"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]}]}}</oraInfoDisplay>
~~~

## Step 3: approve-exact-link

**Status:** passed
**Type:** chat
**Intent:** Approve contact-address revision 1
**Context Step IDs:** prepare-required-link, review-link-references (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Approve contact-address revision 1",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="contact-address-review">{"patternId":"multiRecordWidget","title":"Contact-address draft revision 1","description":"Contact-address revision 1 approved without writing. To create this exact link, enter: Create contact-address revision 1.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Contact email","xdx-contact-retry-20260923-a@example.invalid"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]}]}}</oraInfoDisplay>
~~~

## Step 4: create-approved-link

**Status:** passed
**Type:** chat
**Intent:** Create contact-address revision 1
**Context Step IDs:** prepare-required-link, review-link-references, approve-exact-link (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Create contact-address revision 1",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="contact-address-review">{"patternId":"multiRecordWidget","title":"Contact-address draft revision 1","description":"Contact-address association created and independently verified.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Contact email","xdx-contact-retry-20260923-a@example.invalid"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]}]}}</oraInfoDisplay>
~~~

## Verification Summary

| Verification | Status | Result |
| --- | --- | --- |
| Node order and counts | PASSED | 5/5 passed |
| Path assertions | PASSED | 996/996 passed |
| Node assertions | PASSED | 6/6 passed |
| Workflow run checks | PASSED | 6/6 passed |
| Output checks | PASSED | 10/10 passed |

## Node Order and Count

### Required Relative Order

Other nodes may execute between the listed nodes.

| Step | Status | Assertion | Required Relative Order | Observed or Failure |
| --- | --- | --- | --- | --- |
| prepare-required-link | PASS | Review before write and verification | XDX_REDUCE_LINK_DRAFT -> XDX_LINK_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_LINK_DRAFT -> XDX_SAVE_LINK_DRAFT -> XDX_LINK_NEEDS_REFERENCES -> XDX_LINK_DRAFT_RESPONSE |
| review-link-references | PASS | Review before write and verification | XDX_REDUCE_LINK_DRAFT -> XDX_BIND_LINK_REFERENCES -> XDX_SAVE_LINK_REVIEW -> XDX_LINK_REVIEW_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_LINK_DRAFT -> XDX_SAVE_LINK_DRAFT -> XDX_LINK_NEEDS_REFERENCES -> XDX_RESOLVE_LINK_PARENT -> XDX_BIND_LINK_PARENT -> XDX_VALID_LINK_PARENT -> XDX_RESOLVE_LINK_ADDRESS -> XDX_BIND_LINK_ADDRESS -> XDX_VALID_LINK_ADDRESS -> XDX_RESOLVE_LINK_CONTACT -> XDX_BIND_LINK_REFERENCES -> XDX_VALID_LINK_REFERENCES -> XDX_LINK_IS_REVIEW -> XDX_SAVE_LINK_REVIEW -> XDX_LINK_REVIEW_RESPONSE |
| approve-exact-link | PASS | Review before write and verification | XDX_REDUCE_LINK_DRAFT -> XDX_LINK_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_LINK_DRAFT -> XDX_SAVE_LINK_DRAFT -> XDX_LINK_NEEDS_REFERENCES -> XDX_LINK_DRAFT_RESPONSE |
| create-approved-link | PASS | Review before write and verification | XDX_REDUCE_LINK_DRAFT -> XDX_BIND_LINK_REFERENCES -> XDX_SAVE_LINK_ATTEMPT -> XDX_CREATE_LINK -> XDX_VERIFY_LINK -> XDX_CONFIRM_LINK_CREATE -> XDX_LINK_CREATE_RESULT | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_LINK_DRAFT -> XDX_SAVE_LINK_DRAFT -> XDX_LINK_NEEDS_REFERENCES -> XDX_RESOLVE_LINK_PARENT -> XDX_BIND_LINK_PARENT -> XDX_VALID_LINK_PARENT -> XDX_RESOLVE_LINK_ADDRESS -> XDX_BIND_LINK_ADDRESS -> XDX_VALID_LINK_ADDRESS -> XDX_RESOLVE_LINK_CONTACT -> XDX_BIND_LINK_REFERENCES -> XDX_VALID_LINK_REFERENCES -> XDX_LINK_IS_REVIEW -> XDX_CHECK_LINK_DUPLICATE -> XDX_DECIDE_LINK_CREATE -> XDX_CAN_POST_LINK -> XDX_SAVE_LINK_ATTEMPT -> XDX_CREATE_LINK -> XDX_VERIFY_LINK -> XDX_CONFIRM_LINK_CREATE -> XDX_SAVE_LINK_CONFIRMATION -> XDX_LINK_CREATE_RESULT |

### Node Count Checks

| Step | Assertion | Node Code | Expected | Observed | Status |
| --- | --- | --- | --- | --- | --- |
| create-approved-link | One link POST node | XDX_CREATE_LINK | exactly 1 | 1 | PASS |

## Path Assertions

| Step | Status | Assertion | Requirement | Node Code | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-link | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| prepare-required-link | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| prepare-required-link | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| prepare-required-link | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| prepare-required-link | PASS | Execute XDX_REDUCE_LINK_DRAFT | Must execute | XDX_REDUCE_LINK_DRAFT | Executed |
| prepare-required-link | PASS | Execute XDX_SAVE_LINK_DRAFT | Must execute | XDX_SAVE_LINK_DRAFT | Executed |
| prepare-required-link | PASS | Execute XDX_LINK_NEEDS_REFERENCES | Must execute | XDX_LINK_NEEDS_REFERENCES | Executed |
| prepare-required-link | PASS | Execute XDX_LINK_DRAFT_RESPONSE | Must execute | XDX_LINK_DRAFT_RESPONSE | Executed |
| prepare-required-link | PASS | Skip XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| prepare-required-link | PASS | Skip XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| prepare-required-link | PASS | Skip XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| prepare-required-link | PASS | Skip XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| prepare-required-link | PASS | Skip XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| prepare-required-link | PASS | Skip XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| prepare-required-link | PASS | Skip XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| prepare-required-link | PASS | Skip XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| prepare-required-link | PASS | Skip XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| prepare-required-link | PASS | Skip XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| prepare-required-link | PASS | Skip XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| prepare-required-link | PASS | Skip XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| prepare-required-link | PASS | Skip XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| prepare-required-link | PASS | Skip XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| prepare-required-link | PASS | Skip XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| prepare-required-link | PASS | Skip XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| prepare-required-link | PASS | Skip XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| prepare-required-link | PASS | Skip XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| prepare-required-link | PASS | Skip XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| prepare-required-link | PASS | Skip XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| prepare-required-link | PASS | Skip XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| prepare-required-link | PASS | Skip XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| prepare-required-link | PASS | Skip XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| prepare-required-link | PASS | Skip XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| prepare-required-link | PASS | Skip XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| prepare-required-link | PASS | Skip XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| prepare-required-link | PASS | Skip XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| prepare-required-link | PASS | Skip XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| prepare-required-link | PASS | Skip XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| prepare-required-link | PASS | Skip XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| prepare-required-link | PASS | Skip XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| prepare-required-link | PASS | Skip XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| prepare-required-link | PASS | Skip XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| prepare-required-link | PASS | Skip XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| prepare-required-link | PASS | Skip XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| prepare-required-link | PASS | Skip XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| prepare-required-link | PASS | Skip XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| prepare-required-link | PASS | Skip XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| prepare-required-link | PASS | Skip XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| prepare-required-link | PASS | Skip XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| prepare-required-link | PASS | Skip XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| prepare-required-link | PASS | Skip XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| prepare-required-link | PASS | Skip XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| prepare-required-link | PASS | Skip XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| prepare-required-link | PASS | Skip XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| prepare-required-link | PASS | Skip XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| prepare-required-link | PASS | Skip XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| prepare-required-link | PASS | Skip XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| prepare-required-link | PASS | Skip XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| prepare-required-link | PASS | Skip XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| prepare-required-link | PASS | Skip XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| prepare-required-link | PASS | Skip XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| prepare-required-link | PASS | Skip XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| prepare-required-link | PASS | Skip XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| prepare-required-link | PASS | Skip XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| prepare-required-link | PASS | Skip XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| prepare-required-link | PASS | Skip XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| prepare-required-link | PASS | Skip XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| prepare-required-link | PASS | Skip XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| prepare-required-link | PASS | Skip XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| prepare-required-link | PASS | Skip XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| prepare-required-link | PASS | Skip XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| prepare-required-link | PASS | Skip XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| prepare-required-link | PASS | Skip XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| prepare-required-link | PASS | Skip XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| prepare-required-link | PASS | Skip XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| prepare-required-link | PASS | Skip XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| prepare-required-link | PASS | Skip XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| prepare-required-link | PASS | Skip XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| prepare-required-link | PASS | Skip XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| prepare-required-link | PASS | Skip XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| prepare-required-link | PASS | Skip XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| prepare-required-link | PASS | Skip XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| prepare-required-link | PASS | Skip XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| prepare-required-link | PASS | Skip XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| prepare-required-link | PASS | Skip XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| prepare-required-link | PASS | Skip XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| prepare-required-link | PASS | Skip XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| prepare-required-link | PASS | Skip XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| prepare-required-link | PASS | Skip XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| prepare-required-link | PASS | Skip XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| prepare-required-link | PASS | Skip XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| prepare-required-link | PASS | Skip XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| prepare-required-link | PASS | Skip XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| prepare-required-link | PASS | Skip XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| prepare-required-link | PASS | Skip XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| prepare-required-link | PASS | Skip XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| prepare-required-link | PASS | Skip XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| prepare-required-link | PASS | Skip XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| prepare-required-link | PASS | Skip XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| prepare-required-link | PASS | Skip XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| prepare-required-link | PASS | Skip XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| prepare-required-link | PASS | Skip XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| prepare-required-link | PASS | Skip XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| prepare-required-link | PASS | Skip XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| prepare-required-link | PASS | Skip XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| prepare-required-link | PASS | Skip XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| prepare-required-link | PASS | Skip XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| prepare-required-link | PASS | Skip XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| prepare-required-link | PASS | Skip XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| prepare-required-link | PASS | Skip XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| prepare-required-link | PASS | Skip XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| prepare-required-link | PASS | Skip XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| prepare-required-link | PASS | Skip XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| prepare-required-link | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| prepare-required-link | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| prepare-required-link | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| prepare-required-link | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| prepare-required-link | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| prepare-required-link | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| prepare-required-link | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| prepare-required-link | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| prepare-required-link | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| prepare-required-link | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| prepare-required-link | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| prepare-required-link | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| prepare-required-link | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| prepare-required-link | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| prepare-required-link | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| prepare-required-link | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| prepare-required-link | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-link | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-link | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-link | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| prepare-required-link | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| prepare-required-link | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| prepare-required-link | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| review-link-references | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| review-link-references | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| review-link-references | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| review-link-references | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| review-link-references | PASS | Execute XDX_REDUCE_LINK_DRAFT | Must execute | XDX_REDUCE_LINK_DRAFT | Executed |
| review-link-references | PASS | Execute XDX_SAVE_LINK_DRAFT | Must execute | XDX_SAVE_LINK_DRAFT | Executed |
| review-link-references | PASS | Execute XDX_LINK_NEEDS_REFERENCES | Must execute | XDX_LINK_NEEDS_REFERENCES | Executed |
| review-link-references | PASS | Execute XDX_RESOLVE_LINK_PARENT | Must execute | XDX_RESOLVE_LINK_PARENT | Executed |
| review-link-references | PASS | Execute XDX_BIND_LINK_PARENT | Must execute | XDX_BIND_LINK_PARENT | Executed |
| review-link-references | PASS | Execute XDX_VALID_LINK_PARENT | Must execute | XDX_VALID_LINK_PARENT | Executed |
| review-link-references | PASS | Execute XDX_RESOLVE_LINK_ADDRESS | Must execute | XDX_RESOLVE_LINK_ADDRESS | Executed |
| review-link-references | PASS | Execute XDX_BIND_LINK_ADDRESS | Must execute | XDX_BIND_LINK_ADDRESS | Executed |
| review-link-references | PASS | Execute XDX_VALID_LINK_ADDRESS | Must execute | XDX_VALID_LINK_ADDRESS | Executed |
| review-link-references | PASS | Execute XDX_RESOLVE_LINK_CONTACT | Must execute | XDX_RESOLVE_LINK_CONTACT | Executed |
| review-link-references | PASS | Execute XDX_BIND_LINK_REFERENCES | Must execute | XDX_BIND_LINK_REFERENCES | Executed |
| review-link-references | PASS | Execute XDX_VALID_LINK_REFERENCES | Must execute | XDX_VALID_LINK_REFERENCES | Executed |
| review-link-references | PASS | Execute XDX_LINK_IS_REVIEW | Must execute | XDX_LINK_IS_REVIEW | Executed |
| review-link-references | PASS | Execute XDX_SAVE_LINK_REVIEW | Must execute | XDX_SAVE_LINK_REVIEW | Executed |
| review-link-references | PASS | Execute XDX_LINK_REVIEW_RESPONSE | Must execute | XDX_LINK_REVIEW_RESPONSE | Executed |
| review-link-references | PASS | Skip XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| review-link-references | PASS | Skip XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| review-link-references | PASS | Skip XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| review-link-references | PASS | Skip XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| review-link-references | PASS | Skip XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| review-link-references | PASS | Skip XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| review-link-references | PASS | Skip XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| review-link-references | PASS | Skip XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| review-link-references | PASS | Skip XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| review-link-references | PASS | Skip XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| review-link-references | PASS | Skip XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| review-link-references | PASS | Skip XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| review-link-references | PASS | Skip XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| review-link-references | PASS | Skip XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| review-link-references | PASS | Skip XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| review-link-references | PASS | Skip XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| review-link-references | PASS | Skip XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| review-link-references | PASS | Skip XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| review-link-references | PASS | Skip XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| review-link-references | PASS | Skip XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| review-link-references | PASS | Skip XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| review-link-references | PASS | Skip XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| review-link-references | PASS | Skip XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| review-link-references | PASS | Skip XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| review-link-references | PASS | Skip XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| review-link-references | PASS | Skip XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| review-link-references | PASS | Skip XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| review-link-references | PASS | Skip XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| review-link-references | PASS | Skip XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| review-link-references | PASS | Skip XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| review-link-references | PASS | Skip XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| review-link-references | PASS | Skip XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| review-link-references | PASS | Skip XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| review-link-references | PASS | Skip XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| review-link-references | PASS | Skip XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| review-link-references | PASS | Skip XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| review-link-references | PASS | Skip XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| review-link-references | PASS | Skip XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| review-link-references | PASS | Skip XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| review-link-references | PASS | Skip XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| review-link-references | PASS | Skip XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| review-link-references | PASS | Skip XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| review-link-references | PASS | Skip XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| review-link-references | PASS | Skip XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| review-link-references | PASS | Skip XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| review-link-references | PASS | Skip XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| review-link-references | PASS | Skip XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| review-link-references | PASS | Skip XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| review-link-references | PASS | Skip XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| review-link-references | PASS | Skip XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| review-link-references | PASS | Skip XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| review-link-references | PASS | Skip XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| review-link-references | PASS | Skip XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| review-link-references | PASS | Skip XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| review-link-references | PASS | Skip XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| review-link-references | PASS | Skip XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| review-link-references | PASS | Skip XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| review-link-references | PASS | Skip XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| review-link-references | PASS | Skip XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| review-link-references | PASS | Skip XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| review-link-references | PASS | Skip XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| review-link-references | PASS | Skip XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| review-link-references | PASS | Skip XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| review-link-references | PASS | Skip XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| review-link-references | PASS | Skip XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| review-link-references | PASS | Skip XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| review-link-references | PASS | Skip XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| review-link-references | PASS | Skip XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| review-link-references | PASS | Skip XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| review-link-references | PASS | Skip XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| review-link-references | PASS | Skip XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| review-link-references | PASS | Skip XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| review-link-references | PASS | Skip XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| review-link-references | PASS | Skip XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| review-link-references | PASS | Skip XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| review-link-references | PASS | Skip XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| review-link-references | PASS | Skip XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| review-link-references | PASS | Skip XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| review-link-references | PASS | Skip XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| review-link-references | PASS | Skip XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| review-link-references | PASS | Skip XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| review-link-references | PASS | Skip XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| review-link-references | PASS | Skip XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| review-link-references | PASS | Skip XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| review-link-references | PASS | Skip XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| review-link-references | PASS | Skip XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| review-link-references | PASS | Skip XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| review-link-references | PASS | Skip XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| review-link-references | PASS | Skip XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| review-link-references | PASS | Skip XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| review-link-references | PASS | Skip XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| review-link-references | PASS | Skip XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| review-link-references | PASS | Skip XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| review-link-references | PASS | Skip XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| review-link-references | PASS | Skip XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| review-link-references | PASS | Skip XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| review-link-references | PASS | Skip XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| review-link-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| review-link-references | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| review-link-references | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| review-link-references | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| review-link-references | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| review-link-references | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| review-link-references | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| review-link-references | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| review-link-references | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| review-link-references | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| review-link-references | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| review-link-references | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| review-link-references | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| review-link-references | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| review-link-references | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| review-link-references | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| review-link-references | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| review-link-references | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| review-link-references | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| review-link-references | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| review-link-references | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| review-link-references | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| review-link-references | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| review-link-references | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| approve-exact-link | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| approve-exact-link | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| approve-exact-link | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| approve-exact-link | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| approve-exact-link | PASS | Execute XDX_REDUCE_LINK_DRAFT | Must execute | XDX_REDUCE_LINK_DRAFT | Executed |
| approve-exact-link | PASS | Execute XDX_SAVE_LINK_DRAFT | Must execute | XDX_SAVE_LINK_DRAFT | Executed |
| approve-exact-link | PASS | Execute XDX_LINK_NEEDS_REFERENCES | Must execute | XDX_LINK_NEEDS_REFERENCES | Executed |
| approve-exact-link | PASS | Execute XDX_LINK_DRAFT_RESPONSE | Must execute | XDX_LINK_DRAFT_RESPONSE | Executed |
| approve-exact-link | PASS | Skip XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| approve-exact-link | PASS | Skip XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| approve-exact-link | PASS | Skip XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| approve-exact-link | PASS | Skip XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| approve-exact-link | PASS | Skip XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| approve-exact-link | PASS | Skip XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| approve-exact-link | PASS | Skip XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| approve-exact-link | PASS | Skip XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| approve-exact-link | PASS | Skip XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| approve-exact-link | PASS | Skip XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| approve-exact-link | PASS | Skip XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| approve-exact-link | PASS | Skip XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| approve-exact-link | PASS | Skip XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| approve-exact-link | PASS | Skip XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| approve-exact-link | PASS | Skip XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| approve-exact-link | PASS | Skip XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| approve-exact-link | PASS | Skip XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| approve-exact-link | PASS | Skip XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| approve-exact-link | PASS | Skip XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| approve-exact-link | PASS | Skip XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| approve-exact-link | PASS | Skip XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| approve-exact-link | PASS | Skip XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| approve-exact-link | PASS | Skip XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| approve-exact-link | PASS | Skip XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| approve-exact-link | PASS | Skip XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| approve-exact-link | PASS | Skip XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| approve-exact-link | PASS | Skip XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| approve-exact-link | PASS | Skip XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| approve-exact-link | PASS | Skip XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| approve-exact-link | PASS | Skip XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| approve-exact-link | PASS | Skip XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| approve-exact-link | PASS | Skip XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| approve-exact-link | PASS | Skip XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| approve-exact-link | PASS | Skip XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| approve-exact-link | PASS | Skip XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| approve-exact-link | PASS | Skip XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| approve-exact-link | PASS | Skip XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| approve-exact-link | PASS | Skip XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| approve-exact-link | PASS | Skip XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| approve-exact-link | PASS | Skip XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| approve-exact-link | PASS | Skip XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| approve-exact-link | PASS | Skip XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| approve-exact-link | PASS | Skip XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| approve-exact-link | PASS | Skip XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| approve-exact-link | PASS | Skip XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| approve-exact-link | PASS | Skip XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| approve-exact-link | PASS | Skip XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| approve-exact-link | PASS | Skip XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| approve-exact-link | PASS | Skip XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| approve-exact-link | PASS | Skip XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| approve-exact-link | PASS | Skip XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| approve-exact-link | PASS | Skip XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| approve-exact-link | PASS | Skip XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| approve-exact-link | PASS | Skip XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| approve-exact-link | PASS | Skip XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| approve-exact-link | PASS | Skip XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| approve-exact-link | PASS | Skip XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| approve-exact-link | PASS | Skip XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| approve-exact-link | PASS | Skip XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| approve-exact-link | PASS | Skip XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| approve-exact-link | PASS | Skip XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| approve-exact-link | PASS | Skip XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| approve-exact-link | PASS | Skip XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| approve-exact-link | PASS | Skip XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| approve-exact-link | PASS | Skip XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| approve-exact-link | PASS | Skip XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| approve-exact-link | PASS | Skip XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| approve-exact-link | PASS | Skip XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| approve-exact-link | PASS | Skip XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| approve-exact-link | PASS | Skip XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| approve-exact-link | PASS | Skip XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| approve-exact-link | PASS | Skip XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| approve-exact-link | PASS | Skip XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| approve-exact-link | PASS | Skip XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| approve-exact-link | PASS | Skip XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| approve-exact-link | PASS | Skip XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| approve-exact-link | PASS | Skip XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| approve-exact-link | PASS | Skip XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| approve-exact-link | PASS | Skip XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| approve-exact-link | PASS | Skip XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| approve-exact-link | PASS | Skip XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| approve-exact-link | PASS | Skip XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| approve-exact-link | PASS | Skip XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| approve-exact-link | PASS | Skip XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| approve-exact-link | PASS | Skip XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| approve-exact-link | PASS | Skip XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| approve-exact-link | PASS | Skip XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| approve-exact-link | PASS | Skip XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| approve-exact-link | PASS | Skip XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| approve-exact-link | PASS | Skip XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| approve-exact-link | PASS | Skip XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| approve-exact-link | PASS | Skip XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| approve-exact-link | PASS | Skip XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| approve-exact-link | PASS | Skip XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| approve-exact-link | PASS | Skip XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| approve-exact-link | PASS | Skip XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| approve-exact-link | PASS | Skip XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| approve-exact-link | PASS | Skip XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| approve-exact-link | PASS | Skip XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| approve-exact-link | PASS | Skip XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| approve-exact-link | PASS | Skip XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| approve-exact-link | PASS | Skip XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| approve-exact-link | PASS | Skip XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| approve-exact-link | PASS | Skip XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-exact-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| approve-exact-link | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| approve-exact-link | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| approve-exact-link | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| approve-exact-link | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| approve-exact-link | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| approve-exact-link | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| approve-exact-link | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| approve-exact-link | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| approve-exact-link | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| approve-exact-link | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| approve-exact-link | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| approve-exact-link | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| approve-exact-link | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| approve-exact-link | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| approve-exact-link | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| approve-exact-link | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| approve-exact-link | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| approve-exact-link | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| approve-exact-link | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| approve-exact-link | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| approve-exact-link | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| approve-exact-link | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| approve-exact-link | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| create-approved-link | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| create-approved-link | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| create-approved-link | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| create-approved-link | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| create-approved-link | PASS | Execute XDX_REDUCE_LINK_DRAFT | Must execute | XDX_REDUCE_LINK_DRAFT | Executed |
| create-approved-link | PASS | Execute XDX_SAVE_LINK_DRAFT | Must execute | XDX_SAVE_LINK_DRAFT | Executed |
| create-approved-link | PASS | Execute XDX_LINK_NEEDS_REFERENCES | Must execute | XDX_LINK_NEEDS_REFERENCES | Executed |
| create-approved-link | PASS | Execute XDX_RESOLVE_LINK_PARENT | Must execute | XDX_RESOLVE_LINK_PARENT | Executed |
| create-approved-link | PASS | Execute XDX_BIND_LINK_PARENT | Must execute | XDX_BIND_LINK_PARENT | Executed |
| create-approved-link | PASS | Execute XDX_VALID_LINK_PARENT | Must execute | XDX_VALID_LINK_PARENT | Executed |
| create-approved-link | PASS | Execute XDX_RESOLVE_LINK_ADDRESS | Must execute | XDX_RESOLVE_LINK_ADDRESS | Executed |
| create-approved-link | PASS | Execute XDX_BIND_LINK_ADDRESS | Must execute | XDX_BIND_LINK_ADDRESS | Executed |
| create-approved-link | PASS | Execute XDX_VALID_LINK_ADDRESS | Must execute | XDX_VALID_LINK_ADDRESS | Executed |
| create-approved-link | PASS | Execute XDX_RESOLVE_LINK_CONTACT | Must execute | XDX_RESOLVE_LINK_CONTACT | Executed |
| create-approved-link | PASS | Execute XDX_BIND_LINK_REFERENCES | Must execute | XDX_BIND_LINK_REFERENCES | Executed |
| create-approved-link | PASS | Execute XDX_VALID_LINK_REFERENCES | Must execute | XDX_VALID_LINK_REFERENCES | Executed |
| create-approved-link | PASS | Execute XDX_LINK_IS_REVIEW | Must execute | XDX_LINK_IS_REVIEW | Executed |
| create-approved-link | PASS | Execute XDX_CHECK_LINK_DUPLICATE | Must execute | XDX_CHECK_LINK_DUPLICATE | Executed |
| create-approved-link | PASS | Execute XDX_DECIDE_LINK_CREATE | Must execute | XDX_DECIDE_LINK_CREATE | Executed |
| create-approved-link | PASS | Execute XDX_CAN_POST_LINK | Must execute | XDX_CAN_POST_LINK | Executed |
| create-approved-link | PASS | Execute XDX_SAVE_LINK_ATTEMPT | Must execute | XDX_SAVE_LINK_ATTEMPT | Executed |
| create-approved-link | PASS | Execute XDX_CREATE_LINK | Must execute | XDX_CREATE_LINK | Executed |
| create-approved-link | PASS | Execute XDX_VERIFY_LINK | Must execute | XDX_VERIFY_LINK | Executed |
| create-approved-link | PASS | Execute XDX_CONFIRM_LINK_CREATE | Must execute | XDX_CONFIRM_LINK_CREATE | Executed |
| create-approved-link | PASS | Execute XDX_SAVE_LINK_CONFIRMATION | Must execute | XDX_SAVE_LINK_CONFIRMATION | Executed |
| create-approved-link | PASS | Execute XDX_LINK_CREATE_RESULT | Must execute | XDX_LINK_CREATE_RESULT | Executed |
| create-approved-link | PASS | Skip XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| create-approved-link | PASS | Skip XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| create-approved-link | PASS | Skip XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| create-approved-link | PASS | Skip XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| create-approved-link | PASS | Skip XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| create-approved-link | PASS | Skip XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| create-approved-link | PASS | Skip XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| create-approved-link | PASS | Skip XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| create-approved-link | PASS | Skip XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| create-approved-link | PASS | Skip XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| create-approved-link | PASS | Skip XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| create-approved-link | PASS | Skip XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| create-approved-link | PASS | Skip XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| create-approved-link | PASS | Skip XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| create-approved-link | PASS | Skip XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| create-approved-link | PASS | Skip XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| create-approved-link | PASS | Skip XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| create-approved-link | PASS | Skip XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| create-approved-link | PASS | Skip XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| create-approved-link | PASS | Skip XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| create-approved-link | PASS | Skip XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| create-approved-link | PASS | Skip XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| create-approved-link | PASS | Skip XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| create-approved-link | PASS | Skip XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| create-approved-link | PASS | Skip XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| create-approved-link | PASS | Skip XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| create-approved-link | PASS | Skip XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| create-approved-link | PASS | Skip XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| create-approved-link | PASS | Skip XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| create-approved-link | PASS | Skip XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| create-approved-link | PASS | Skip XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| create-approved-link | PASS | Skip XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| create-approved-link | PASS | Skip XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| create-approved-link | PASS | Skip XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| create-approved-link | PASS | Skip XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| create-approved-link | PASS | Skip XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| create-approved-link | PASS | Skip XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| create-approved-link | PASS | Skip XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| create-approved-link | PASS | Skip XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| create-approved-link | PASS | Skip XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| create-approved-link | PASS | Skip XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| create-approved-link | PASS | Skip XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| create-approved-link | PASS | Skip XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| create-approved-link | PASS | Skip XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| create-approved-link | PASS | Skip XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| create-approved-link | PASS | Skip XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| create-approved-link | PASS | Skip XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| create-approved-link | PASS | Skip XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| create-approved-link | PASS | Skip XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| create-approved-link | PASS | Skip XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| create-approved-link | PASS | Skip XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| create-approved-link | PASS | Skip XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| create-approved-link | PASS | Skip XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| create-approved-link | PASS | Skip XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| create-approved-link | PASS | Skip XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| create-approved-link | PASS | Skip XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| create-approved-link | PASS | Skip XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| create-approved-link | PASS | Skip XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| create-approved-link | PASS | Skip XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| create-approved-link | PASS | Skip XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| create-approved-link | PASS | Skip XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| create-approved-link | PASS | Skip XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| create-approved-link | PASS | Skip XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| create-approved-link | PASS | Skip XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| create-approved-link | PASS | Skip XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| create-approved-link | PASS | Skip XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| create-approved-link | PASS | Skip XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| create-approved-link | PASS | Skip XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| create-approved-link | PASS | Skip XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| create-approved-link | PASS | Skip XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| create-approved-link | PASS | Skip XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| create-approved-link | PASS | Skip XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| create-approved-link | PASS | Skip XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| create-approved-link | PASS | Skip XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| create-approved-link | PASS | Skip XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| create-approved-link | PASS | Skip XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| create-approved-link | PASS | Skip XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| create-approved-link | PASS | Skip XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| create-approved-link | PASS | Skip XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| create-approved-link | PASS | Skip XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| create-approved-link | PASS | Skip XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| create-approved-link | PASS | Skip XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| create-approved-link | PASS | Skip XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| create-approved-link | PASS | Skip XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| create-approved-link | PASS | Skip XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| create-approved-link | PASS | Skip XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| create-approved-link | PASS | Skip XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| create-approved-link | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| create-approved-link | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| create-approved-link | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| create-approved-link | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| create-approved-link | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| create-approved-link | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| create-approved-link | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| create-approved-link | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| create-approved-link | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| create-approved-link | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| create-approved-link | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| create-approved-link | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| create-approved-link | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| create-approved-link | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| create-approved-link | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| create-approved-link | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| create-approved-link | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| create-approved-link | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-link | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-link | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-link | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| create-approved-link | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| create-approved-link | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| create-approved-link | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |

## Node Assertions

| Step | Status | Assertion | Node Code | Occurrence | Asserted Value | Operator | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| prepare-required-link | PASS | Link draft revision retained | XDX_REDUCE_LINK_DRAFT | last | output/result/state/revision | equals | 1 | number |
| review-link-references | PASS | Resolved reference 0 | XDX_BIND_LINK_REFERENCES | last | output/result/snapshot/supplierId | equals | "300000333814329" | string (15 characters) |
| review-link-references | PASS | Resolved reference 1 | XDX_BIND_LINK_REFERENCES | last | output/result/snapshot/contactId | equals | "300000333814350" | string (15 characters) |
| review-link-references | PASS | Resolved reference 2 | XDX_BIND_LINK_REFERENCES | last | output/result/snapshot/payload/SupplierAddressId | equals | 300000333814336 | number |
| approve-exact-link | PASS | Current link revision approved | XDX_REDUCE_LINK_DRAFT | last | output/result/state/approvedRevision | equals | 1 | number |
| create-approved-link | PASS | Link persisted values confirmed | XDX_CONFIRM_LINK_CREATE | last | output/result/confirmed | equals | true | boolean |

## Workflow Run Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-link | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| review-link-references | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| approve-exact-link | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| create-approved-link | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| Conversation | PASS | conversationStepOrder | conversationStepOrder | prepare-required-link -> review-link-references -> approve-exact-link -> create-approved-link | Verified |
| Conversation | PASS | conversationIdReuse | conversationIdReuse | Every executed step uses one conversation ID. | Verified |

## Output Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-link | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| prepare-required-link | PASS | Retained reference 0 | contains | XDX Lifecycle Retry 20260923 A | Found "XDX Lifecycle Retry 20260923 A" |
| prepare-required-link | PASS | Retained reference 1 | contains | xdx-contact-retry-20260923-a@example.invalid | Found "xdx-contact-retry-20260923-a@example.invalid" |
| prepare-required-link | PASS | Retained reference 2 | contains | XDX HQ Retry 20260923 A | Found "XDX HQ Retry 20260923 A" |
| review-link-references | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| review-link-references | PASS | Exact approval instruction | contains | Approve contact-address revision 1 | Found "Approve contact-address revision 1" |
| approve-exact-link | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| approve-exact-link | PASS | Exact create instruction | contains | Create contact-address revision 1 | Found "Create contact-address revision 1" |
| create-approved-link | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| create-approved-link | PASS | Persisted association | contains | Contact-address association created and independently verified | Found "Contact-address association created and independently verified" |

## Runtime Metrics

Workflow time: 10743 ms (sum of node times)
Test run time: 17924 ms (includes CLI overhead)
Token usage: observed from runtime events

Aggregate Token Usage

| Input Tokens | Output Tokens | Total Tokens | Model |
| --- | --- | --- | --- |
| 18060 | 2150 | 20210 | oci-agent/openai.gpt-4.1-mini-2025-04-14 |

| Node | Input Tokens | Output Tokens | Total Tokens | Model | Source |
| --- | --- | --- | --- | --- | --- |
| approve-exact-link:XDX_EXTRACT_SEARCH | 4597 | 533 | 5130 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| create-approved-link:XDX_EXTRACT_SEARCH | 4755 | 533 | 5288 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| prepare-required-link:XDX_EXTRACT_SEARCH | 4280 | 542 | 4822 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| review-link-references:XDX_EXTRACT_SEARCH | 4428 | 542 | 4970 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |


AI Units: computed
Total Token Units: 4
Total AI Units: 20

| Node | Input | Output | Token Units | AI Units | Model Type | Action Type |
| --- | --- | --- | --- | --- | --- | --- |
| approve-exact-link:XDX_EXTRACT_SEARCH | 4597 | 533 | 1 | 5 | premium | general |
| create-approved-link:XDX_EXTRACT_SEARCH | 4755 | 533 | 1 | 5 | premium | general |
| prepare-required-link:XDX_EXTRACT_SEARCH | 4280 | 542 | 1 | 5 | premium | general |
| review-link-references:XDX_EXTRACT_SEARCH | 4428 | 542 | 1 | 5 | premium | general |

| Node | Node Time (ms) | LLM Call Time (ms) | Details |
| --- | --- | --- | --- |
| prepare-required-link:XDX_EXTRACT_SEARCH | 2644 | 2551 | 1 runtime detail; see JSON report |
| review-link-references:XDX_EXTRACT_SEARCH | 2665 | 2579 | 1 runtime detail; see JSON report |
| review-link-references:XDX_RESOLVE_LINK_PARENT | 45 |  | 0 runtime details; see JSON report |
| review-link-references:XDX_RESOLVE_LINK_ADDRESS | 47 |  | 0 runtime details; see JSON report |
| review-link-references:XDX_RESOLVE_LINK_CONTACT | 45 |  | 0 runtime details; see JSON report |
| approve-exact-link:XDX_EXTRACT_SEARCH | 2508 | 2425 | 1 runtime detail; see JSON report |
| create-approved-link:XDX_EXTRACT_SEARCH | 2518 | 2436 | 1 runtime detail; see JSON report |
| create-approved-link:XDX_RESOLVE_LINK_PARENT | 45 |  | 0 runtime details; see JSON report |
| create-approved-link:XDX_RESOLVE_LINK_ADDRESS | 45 |  | 0 runtime details; see JSON report |
| create-approved-link:XDX_RESOLVE_LINK_CONTACT | 46 |  | 0 runtime details; see JSON report |
| create-approved-link:XDX_CHECK_LINK_DUPLICATE | 45 |  | 0 runtime details; see JSON report |
| create-approved-link:XDX_CREATE_LINK | 45 |  | 0 runtime details; see JSON report |
| create-approved-link:XDX_VERIFY_LINK | 45 |  | 0 runtime details; see JSON report |

| Observed Field | Values |
| --- | --- |
| modelName | "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14" |
| inputTokens | 4280; 4428; 4597; 4755 |
| outputTokens | 542; 542; 533; 533 |

## Test Data

| Step | Data Source | Evaluation |
| --- | --- | --- |
| prepare-required-link | File replay | Deterministic |
| review-link-references | File replay | Deterministic |
| approve-exact-link | File replay | Deterministic |
| create-approved-link | File replay | Deterministic |

## Workflow Run

### Execution Timeline

| Step | Phase Sequence | Node | Event |
| --- | --- | --- | --- |
| prepare-required-link | 1 | START | NODE_EXECUTED |
| prepare-required-link | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| prepare-required-link | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| prepare-required-link | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| prepare-required-link | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| prepare-required-link | 6 | XDX_REDUCE_LINK_DRAFT | NODE_EXECUTED |
| prepare-required-link | 7 | XDX_SAVE_LINK_DRAFT | NODE_EXECUTED |
| prepare-required-link | 8 | XDX_LINK_NEEDS_REFERENCES | NODE_EXECUTED |
| prepare-required-link | 9 | XDX_LINK_DRAFT_RESPONSE | NODE_EXECUTED |
| review-link-references | 1 | START | NODE_EXECUTED |
| review-link-references | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| review-link-references | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| review-link-references | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| review-link-references | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| review-link-references | 6 | XDX_REDUCE_LINK_DRAFT | NODE_EXECUTED |
| review-link-references | 7 | XDX_SAVE_LINK_DRAFT | NODE_EXECUTED |
| review-link-references | 8 | XDX_LINK_NEEDS_REFERENCES | NODE_EXECUTED |
| review-link-references | 9 | XDX_RESOLVE_LINK_PARENT | NODE_START |
| review-link-references | 10 | XDX_BIND_LINK_PARENT | NODE_EXECUTED |
| review-link-references | 11 | XDX_VALID_LINK_PARENT | NODE_EXECUTED |
| review-link-references | 12 | XDX_RESOLVE_LINK_ADDRESS | NODE_START |
| review-link-references | 13 | XDX_BIND_LINK_ADDRESS | NODE_EXECUTED |
| review-link-references | 14 | XDX_VALID_LINK_ADDRESS | NODE_EXECUTED |
| review-link-references | 15 | XDX_RESOLVE_LINK_CONTACT | NODE_START |
| review-link-references | 16 | XDX_BIND_LINK_REFERENCES | NODE_EXECUTED |
| review-link-references | 17 | XDX_VALID_LINK_REFERENCES | NODE_EXECUTED |
| review-link-references | 18 | XDX_LINK_IS_REVIEW | NODE_EXECUTED |
| review-link-references | 19 | XDX_SAVE_LINK_REVIEW | NODE_EXECUTED |
| review-link-references | 20 | XDX_LINK_REVIEW_RESPONSE | NODE_EXECUTED |
| approve-exact-link | 1 | START | NODE_EXECUTED |
| approve-exact-link | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| approve-exact-link | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| approve-exact-link | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| approve-exact-link | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| approve-exact-link | 6 | XDX_REDUCE_LINK_DRAFT | NODE_EXECUTED |
| approve-exact-link | 7 | XDX_SAVE_LINK_DRAFT | NODE_EXECUTED |
| approve-exact-link | 8 | XDX_LINK_NEEDS_REFERENCES | NODE_EXECUTED |
| approve-exact-link | 9 | XDX_LINK_DRAFT_RESPONSE | NODE_EXECUTED |
| create-approved-link | 1 | START | NODE_EXECUTED |
| create-approved-link | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| create-approved-link | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| create-approved-link | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| create-approved-link | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| create-approved-link | 6 | XDX_REDUCE_LINK_DRAFT | NODE_EXECUTED |
| create-approved-link | 7 | XDX_SAVE_LINK_DRAFT | NODE_EXECUTED |
| create-approved-link | 8 | XDX_LINK_NEEDS_REFERENCES | NODE_EXECUTED |
| create-approved-link | 9 | XDX_RESOLVE_LINK_PARENT | NODE_START |
| create-approved-link | 10 | XDX_BIND_LINK_PARENT | NODE_EXECUTED |
| create-approved-link | 11 | XDX_VALID_LINK_PARENT | NODE_EXECUTED |
| create-approved-link | 12 | XDX_RESOLVE_LINK_ADDRESS | NODE_START |
| create-approved-link | 13 | XDX_BIND_LINK_ADDRESS | NODE_EXECUTED |
| create-approved-link | 14 | XDX_VALID_LINK_ADDRESS | NODE_EXECUTED |
| create-approved-link | 15 | XDX_RESOLVE_LINK_CONTACT | NODE_START |
| create-approved-link | 16 | XDX_BIND_LINK_REFERENCES | NODE_EXECUTED |
| create-approved-link | 17 | XDX_VALID_LINK_REFERENCES | NODE_EXECUTED |
| create-approved-link | 18 | XDX_LINK_IS_REVIEW | NODE_EXECUTED |
| create-approved-link | 19 | XDX_CHECK_LINK_DUPLICATE | NODE_START |
| create-approved-link | 20 | XDX_DECIDE_LINK_CREATE | NODE_EXECUTED |
| create-approved-link | 21 | XDX_CAN_POST_LINK | NODE_EXECUTED |
| create-approved-link | 22 | XDX_SAVE_LINK_ATTEMPT | NODE_EXECUTED |
| create-approved-link | 23 | XDX_CREATE_LINK | NODE_START |
| create-approved-link | 24 | XDX_VERIFY_LINK | NODE_START |
| create-approved-link | 25 | XDX_CONFIRM_LINK_CREATE | NODE_EXECUTED |
| create-approved-link | 26 | XDX_SAVE_LINK_CONFIRMATION | NODE_EXECUTED |
| create-approved-link | 27 | XDX_LINK_CREATE_RESULT | NODE_EXECUTED |

### Other Observed Nodes

| Node | Observed |
| --- | --- |
| START | 4 |
| XDX_BIND_LINK_ADDRESS | 2 |
| XDX_BIND_LINK_PARENT | 2 |
| XDX_BIND_LINK_REFERENCES | 2 |
| XDX_CAN_POST_LINK | 1 |
| XDX_CHECK_LINK_DUPLICATE | 1 |
| XDX_CONFIRM_LINK_CREATE | 1 |
| XDX_DECIDE_LINK_CREATE | 1 |
| XDX_EXTRACT_SEARCH | 4 |
| XDX_LINK_CREATE_RESULT | 1 |
| XDX_LINK_DRAFT_RESPONSE | 2 |
| XDX_LINK_IS_REVIEW | 2 |
| XDX_LINK_NEEDS_REFERENCES | 4 |
| XDX_LINK_REVIEW_RESPONSE | 1 |
| XDX_NORMALIZE_REQUEST | 4 |
| XDX_REDUCE_LINK_DRAFT | 4 |
| XDX_RESOLVE_LINK_ADDRESS | 2 |
| XDX_RESOLVE_LINK_CONTACT | 2 |
| XDX_RESOLVE_LINK_PARENT | 2 |
| XDX_ROUTE_APP_STAGE | 4 |
| XDX_ROUTE_REQUEST_INTENT | 4 |
| XDX_SAVE_LINK_ATTEMPT | 1 |
| XDX_SAVE_LINK_CONFIRMATION | 1 |
| XDX_SAVE_LINK_DRAFT | 4 |
| XDX_SAVE_LINK_REVIEW | 1 |
| XDX_VALID_LINK_ADDRESS | 2 |
| XDX_VALID_LINK_PARENT | 2 |
| XDX_VALID_LINK_REFERENCES | 2 |
| XDX_VERIFY_LINK | 1 |

## Report Files

- JSON report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-contact-address-create\result.json`
- Markdown report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-contact-address-create\result.md`
- Test file: `test/workflows/xdx_supplier_lifecycle_agent/xdx-contact-address-create.json`
