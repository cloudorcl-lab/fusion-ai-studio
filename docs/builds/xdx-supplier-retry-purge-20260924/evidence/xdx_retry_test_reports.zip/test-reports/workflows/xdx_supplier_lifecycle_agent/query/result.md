# Workflow Test Result: query

**Status:** PASSED
**Workflow:** XDX_SUPPLIER_LIFECYCLE_AGENT (DRAFT v86153667)
**Scenario:** sync-plan app-stage
**Test Intent:** Verify the workflow routes the Agentic App Query trigger context through its dedicated app-stage path and returns the expected app-stage output.
**Data Source:** file
**Evaluation:** hybrid
**Workflow Time:** 4320 ms (sum of node times)
**Test Run Time:** 5916 ms
**Test File:** `test/workflows/xdx_supplier_lifecycle_agent/query.json`
**JSON Report:** `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\query\result.json`
**Markdown Report:** `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\query\result.md`
**HTML Report:** `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\query\result.html`

## Test Intent

**Type:** sync-plan app-stage
**Intent:** Verify the workflow routes the Agentic App Query trigger context through its dedicated app-stage path and returns the expected app-stage output.

## Invocation

**Message:** `Find suppliers with Lee in the name. Show up to 5 matches.`
**Trigger Type:** app
**Single Turn:** no

```json
{
  "appHint": "Query",
  "OraUserContext": "",
  "OraAppContext": ""
}
```

## Final Output

```text
<oraInfoDisplay key="list-300000047414503-300000333813822">
{
  "title": "Supplier results",
  "patternId": "multiRecordWidget",
  "description": "List of suppliers matching 'Lee' with status and business relationship",
  "properties": {
    "subtitle": "Showing 3 of 3 suppliers",
    "selectMode": "none",
    "cols": ["Supplier", "Supplier number", "Business relationship", "Status"],
    "rows": [
      {
        "cells": ["Lee Supplies", "1252", "Spend Authorized", "Active"]
      },
      {
        "cells": ["XDX Lee Supplies 0917133857", "1496", "Spend Authorized", "Active"]
      },
      {
        "cells": ["XDX Lee Supplies 20260917152534", "1497", "Spend Authorized", "Active"]
      }
    ]
  }
}
</oraInfoDisplay>
```

## Verification Summary

| Verification | Status | Result |
| --- | --- | --- |
| Path assertions | PASSED | 249/249 passed |
| Semantic evaluation | PASSED | 4/4 passed |
| Workflow run checks | PASSED | 1/1 passed |
| Output checks | PASSED | 1/1 passed |

## Path Assertions

| Status | Assertion | Requirement | Node Code | Observed or Failure |
| --- | --- | --- | --- | --- |
| PASS | XDX_ROUTE_APP_STAGE executes | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| PASS | XDX_EXTRACT_SEARCH executes | Must execute | XDX_EXTRACT_SEARCH | Executed |
| PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| PASS | XDX_ROUTE_REQUEST_INTENT executes | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| PASS | XDX_PREPARE_SEARCH executes | Must execute | XDX_PREPARE_SEARCH | Executed |
| PASS | XDX_VALID_SEARCH executes | Must execute | XDX_VALID_SEARCH | Executed |
| PASS | XDX_FETCH_SUPPLIERS executes | Must execute | XDX_FETCH_SUPPLIERS | Executed |
| PASS | XDX_ROUTE_READ_RESOURCE executes | Must execute | XDX_ROUTE_READ_RESOURCE | Executed |
| PASS | XDX_QUERY_RESPONSE executes | Must execute | XDX_QUERY_RESPONSE | Executed |
| PASS | XDX_INITIAL_DISPLAY does not execute | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| PASS | XDX_REDUCE_SUPPLIER_DRAFT does not execute | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| PASS | XDX_SAVE_SUPPLIER_DRAFT does not execute | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| PASS | XDX_SUPPLIER_DRAFT_RESPONSE does not execute | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| PASS | XDX_PREPARE_SUPPLIER_CREATE does not execute | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| PASS | XDX_VALID_SUPPLIER_CREATE does not execute | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| PASS | XDX_CHECK_SUPPLIER_DUPLICATE does not execute | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| PASS | XDX_DECIDE_SUPPLIER_CREATE does not execute | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| PASS | XDX_CAN_POST_SUPPLIER does not execute | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| PASS | XDX_SAVE_SUPPLIER_ATTEMPT does not execute | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| PASS | XDX_CREATE_SUPPLIER does not execute | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| PASS | XDX_VERIFY_SUPPLIER does not execute | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| PASS | XDX_CONFIRM_SUPPLIER_CREATE does not execute | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| PASS | XDX_SAVE_SUPPLIER_CONFIRMATION does not execute | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| PASS | XDX_SUPPLIER_CREATE_RESULT does not execute | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| PASS | XDX_SAVE_SUPPLIER_RECONCILIATION does not execute | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| PASS | XDX_SUPPLIER_CREATE_DECISION does not execute | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| PASS | XDX_SUPPLIER_CREATE_BLOCKED does not execute | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| PASS | XDX_REDUCE_ADDRESS_DRAFT does not execute | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| PASS | XDX_SAVE_ADDRESS_DRAFT does not execute | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| PASS | XDX_ADDRESS_DRAFT_RESPONSE does not execute | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| PASS | XDX_PREPARE_ADDRESS_CREATE does not execute | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| PASS | XDX_VALID_ADDRESS_CREATE does not execute | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| PASS | XDX_RESOLVE_ADDRESS_PARENT does not execute | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| PASS | XDX_BIND_ADDRESS_PARENT does not execute | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| PASS | XDX_VALID_ADDRESS_PARENT does not execute | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| PASS | XDX_CHECK_ADDRESS_DUPLICATE does not execute | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| PASS | XDX_DECIDE_ADDRESS_CREATE does not execute | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| PASS | XDX_CAN_POST_ADDRESS does not execute | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| PASS | XDX_SAVE_ADDRESS_ATTEMPT does not execute | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| PASS | XDX_CREATE_ADDRESS does not execute | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| PASS | XDX_VERIFY_ADDRESS does not execute | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| PASS | XDX_CONFIRM_ADDRESS_CREATE does not execute | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| PASS | XDX_SAVE_ADDRESS_CONFIRMATION does not execute | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| PASS | XDX_ADDRESS_CREATE_RESULT does not execute | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| PASS | XDX_SAVE_ADDRESS_RECONCILIATION does not execute | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| PASS | XDX_ADDRESS_CREATE_DECISION does not execute | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| PASS | XDX_ADDRESS_PARENT_BLOCKED does not execute | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| PASS | XDX_ADDRESS_CREATE_BLOCKED does not execute | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| PASS | XDX_REDUCE_SITE_DRAFT does not execute | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| PASS | XDX_SAVE_SITE_DRAFT does not execute | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| PASS | XDX_SITE_NEEDS_REFERENCES does not execute | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| PASS | XDX_RESOLVE_SITE_PARENT does not execute | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| PASS | XDX_BIND_SITE_PARENT does not execute | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| PASS | XDX_VALID_SITE_PARENT does not execute | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| PASS | XDX_RESOLVE_SITE_ADDRESS does not execute | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| PASS | XDX_BIND_SITE_ADDRESS does not execute | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| PASS | XDX_VALID_SITE_ADDRESS does not execute | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| PASS | XDX_RESOLVE_SITE_BU does not execute | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| PASS | XDX_BIND_SITE_REFERENCES does not execute | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| PASS | XDX_VALID_SITE_REFERENCES does not execute | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| PASS | XDX_SITE_IS_REVIEW does not execute | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| PASS | XDX_SAVE_SITE_REVIEW does not execute | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| PASS | XDX_SITE_REVIEW_RESPONSE does not execute | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| PASS | XDX_CHECK_SITE_DUPLICATE does not execute | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| PASS | XDX_DECIDE_SITE_CREATE does not execute | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| PASS | XDX_CAN_POST_SITE does not execute | Must not execute | XDX_CAN_POST_SITE | Not executed |
| PASS | XDX_SAVE_SITE_ATTEMPT does not execute | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| PASS | XDX_CREATE_SITE does not execute | Must not execute | XDX_CREATE_SITE | Not executed |
| PASS | XDX_VERIFY_SITE does not execute | Must not execute | XDX_VERIFY_SITE | Not executed |
| PASS | XDX_CONFIRM_SITE_CREATE does not execute | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| PASS | XDX_SAVE_SITE_CONFIRMATION does not execute | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| PASS | XDX_SITE_CREATE_RESULT does not execute | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| PASS | XDX_SAVE_SITE_RECONCILIATION does not execute | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| PASS | XDX_SITE_CREATE_DECISION does not execute | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| PASS | XDX_SITE_REFERENCES_BLOCKED does not execute | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| PASS | XDX_SITE_ADDRESS_BLOCKED does not execute | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| PASS | XDX_SITE_PARENT_BLOCKED does not execute | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| PASS | XDX_SITE_DRAFT_RESPONSE does not execute | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| PASS | XDX_REDUCE_CONTACT_DRAFT does not execute | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| PASS | XDX_SAVE_CONTACT_DRAFT does not execute | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| PASS | XDX_CONTACT_NEEDS_PARENT does not execute | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| PASS | XDX_RESOLVE_CONTACT_PARENT does not execute | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| PASS | XDX_BIND_CONTACT_PARENT does not execute | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| PASS | XDX_VALID_CONTACT_PARENT does not execute | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| PASS | XDX_CONTACT_IS_REVIEW does not execute | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| PASS | XDX_SAVE_CONTACT_REVIEW does not execute | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| PASS | XDX_CONTACT_REVIEW_RESPONSE does not execute | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| PASS | XDX_CHECK_CONTACT_DUPLICATE does not execute | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| PASS | XDX_DECIDE_CONTACT_CREATE does not execute | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| PASS | XDX_CAN_POST_CONTACT does not execute | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| PASS | XDX_SAVE_CONTACT_ATTEMPT does not execute | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| PASS | XDX_CREATE_CONTACT does not execute | Must not execute | XDX_CREATE_CONTACT | Not executed |
| PASS | XDX_VERIFY_CONTACT does not execute | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| PASS | XDX_CONFIRM_CONTACT_CREATE does not execute | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| PASS | XDX_SAVE_CONTACT_CONFIRMATION does not execute | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| PASS | XDX_CONTACT_CREATE_RESULT does not execute | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| PASS | XDX_SAVE_CONTACT_RECONCILIATION does not execute | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| PASS | XDX_CONTACT_CREATE_DECISION does not execute | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| PASS | XDX_CONTACT_PARENT_BLOCKED does not execute | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| PASS | XDX_CONTACT_DRAFT_RESPONSE does not execute | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| PASS | XDX_REDUCE_CLASSIFICATION_DRAFT does not execute | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| PASS | XDX_SAVE_CLASSIFICATION_DRAFT does not execute | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| PASS | XDX_CLASSIFICATION_NEEDS_PARENT does not execute | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| PASS | XDX_RESOLVE_CLASSIFICATION_PARENT does not execute | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| PASS | XDX_BIND_CLASSIFICATION_PARENT does not execute | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| PASS | XDX_VALID_CLASSIFICATION_PARENT does not execute | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| PASS | XDX_CLASSIFICATION_IS_REVIEW does not execute | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| PASS | XDX_SAVE_CLASSIFICATION_REVIEW does not execute | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| PASS | XDX_CLASSIFICATION_REVIEW_RESPONSE does not execute | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| PASS | XDX_CHECK_CLASSIFICATION_DUPLICATE does not execute | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| PASS | XDX_DECIDE_CLASSIFICATION_CREATE does not execute | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| PASS | XDX_CAN_POST_CLASSIFICATION does not execute | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| PASS | XDX_SAVE_CLASSIFICATION_ATTEMPT does not execute | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| PASS | XDX_CREATE_CLASSIFICATION does not execute | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| PASS | XDX_VERIFY_CLASSIFICATION does not execute | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| PASS | XDX_CONFIRM_CLASSIFICATION_CREATE does not execute | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| PASS | XDX_SAVE_CLASSIFICATION_CONFIRMATION does not execute | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| PASS | XDX_CLASSIFICATION_CREATE_RESULT does not execute | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| PASS | XDX_SAVE_CLASSIFICATION_RECONCILIATION does not execute | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| PASS | XDX_CLASSIFICATION_CREATE_DECISION does not execute | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| PASS | XDX_CLASSIFICATION_PARENT_BLOCKED does not execute | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| PASS | XDX_CLASSIFICATION_DRAFT_RESPONSE does not execute | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| PASS | XDX_REDUCE_LINK_DRAFT does not execute | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| PASS | XDX_SAVE_LINK_DRAFT does not execute | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| PASS | XDX_LINK_NEEDS_REFERENCES does not execute | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| PASS | XDX_RESOLVE_LINK_PARENT does not execute | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| PASS | XDX_BIND_LINK_PARENT does not execute | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| PASS | XDX_VALID_LINK_PARENT does not execute | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| PASS | XDX_RESOLVE_LINK_ADDRESS does not execute | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| PASS | XDX_BIND_LINK_ADDRESS does not execute | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| PASS | XDX_VALID_LINK_ADDRESS does not execute | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| PASS | XDX_RESOLVE_LINK_CONTACT does not execute | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| PASS | XDX_BIND_LINK_REFERENCES does not execute | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| PASS | XDX_VALID_LINK_REFERENCES does not execute | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| PASS | XDX_LINK_IS_REVIEW does not execute | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| PASS | XDX_SAVE_LINK_REVIEW does not execute | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| PASS | XDX_LINK_REVIEW_RESPONSE does not execute | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| PASS | XDX_CHECK_LINK_DUPLICATE does not execute | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| PASS | XDX_DECIDE_LINK_CREATE does not execute | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| PASS | XDX_CAN_POST_LINK does not execute | Must not execute | XDX_CAN_POST_LINK | Not executed |
| PASS | XDX_SAVE_LINK_ATTEMPT does not execute | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| PASS | XDX_CREATE_LINK does not execute | Must not execute | XDX_CREATE_LINK | Not executed |
| PASS | XDX_VERIFY_LINK does not execute | Must not execute | XDX_VERIFY_LINK | Not executed |
| PASS | XDX_CONFIRM_LINK_CREATE does not execute | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| PASS | XDX_SAVE_LINK_CONFIRMATION does not execute | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| PASS | XDX_LINK_CREATE_RESULT does not execute | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| PASS | XDX_SAVE_LINK_RECONCILIATION does not execute | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| PASS | XDX_LINK_CREATE_DECISION does not execute | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| PASS | XDX_LINK_REFERENCES_BLOCKED does not execute | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| PASS | XDX_LINK_ADDRESS_BLOCKED does not execute | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| PASS | XDX_LINK_PARENT_BLOCKED does not execute | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| PASS | XDX_LINK_DRAFT_RESPONSE does not execute | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| PASS | XDX_REDUCE_PRODUCT_DRAFT does not execute | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| PASS | XDX_SAVE_PRODUCT_DRAFT does not execute | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| PASS | XDX_PRODUCT_NEEDS_REFERENCES does not execute | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| PASS | XDX_RESOLVE_PRODUCT_PARENT does not execute | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| PASS | XDX_BIND_PRODUCT_PARENT does not execute | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| PASS | XDX_VALID_PRODUCT_PARENT does not execute | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| PASS | XDX_RESOLVE_PRODUCT_CATEGORY does not execute | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| PASS | XDX_BIND_PRODUCT_REFERENCES does not execute | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| PASS | XDX_VALID_PRODUCT_REFERENCES does not execute | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| PASS | XDX_PRODUCT_IS_REVIEW does not execute | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| PASS | XDX_SAVE_PRODUCT_REVIEW does not execute | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| PASS | XDX_PRODUCT_REVIEW_RESPONSE does not execute | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| PASS | XDX_CHECK_PRODUCT_DUPLICATE does not execute | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| PASS | XDX_DECIDE_PRODUCT_CREATE does not execute | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| PASS | XDX_CAN_POST_PRODUCT does not execute | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| PASS | XDX_SAVE_PRODUCT_ATTEMPT does not execute | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| PASS | XDX_CREATE_PRODUCT does not execute | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| PASS | XDX_VERIFY_PRODUCT does not execute | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| PASS | XDX_CONFIRM_PRODUCT_CREATE does not execute | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| PASS | XDX_SAVE_PRODUCT_CONFIRMATION does not execute | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| PASS | XDX_PRODUCT_CREATE_RESULT does not execute | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| PASS | XDX_SAVE_PRODUCT_RECONCILIATION does not execute | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| PASS | XDX_PRODUCT_CREATE_DECISION does not execute | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| PASS | XDX_PRODUCT_REFERENCES_BLOCKED does not execute | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| PASS | XDX_PRODUCT_PARENT_BLOCKED does not execute | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| PASS | XDX_PRODUCT_DRAFT_RESPONSE does not execute | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| PASS | XDX_REDUCE_ASSIGNMENT_DRAFT does not execute | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| PASS | XDX_SAVE_ASSIGNMENT_DRAFT does not execute | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| PASS | XDX_ASSIGNMENT_NEEDS_REFERENCES does not execute | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| PASS | XDX_RESOLVE_ASSIGNMENT_PARENT does not execute | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| PASS | XDX_BIND_ASSIGNMENT_PARENT does not execute | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| PASS | XDX_VALID_ASSIGNMENT_PARENT does not execute | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| PASS | XDX_RESOLVE_ASSIGNMENT_SITE does not execute | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| PASS | XDX_BIND_ASSIGNMENT_SITE does not execute | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| PASS | XDX_VALID_ASSIGNMENT_SITE does not execute | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| PASS | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU does not execute | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| PASS | XDX_BIND_ASSIGNMENT_CLIENT_BU does not execute | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| PASS | XDX_VALID_ASSIGNMENT_CLIENT_BU does not execute | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| PASS | XDX_RESOLVE_ASSIGNMENT_BILL_BU does not execute | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| PASS | XDX_BIND_ASSIGNMENT_REFERENCES does not execute | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| PASS | XDX_VALID_ASSIGNMENT_REFERENCES does not execute | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| PASS | XDX_ASSIGNMENT_IS_REVIEW does not execute | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| PASS | XDX_SAVE_ASSIGNMENT_REVIEW does not execute | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| PASS | XDX_ASSIGNMENT_REVIEW_RESPONSE does not execute | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| PASS | XDX_CHECK_ASSIGNMENT_DUPLICATE does not execute | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| PASS | XDX_DECIDE_ASSIGNMENT_CREATE does not execute | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| PASS | XDX_CAN_POST_ASSIGNMENT does not execute | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| PASS | XDX_SAVE_ASSIGNMENT_ATTEMPT does not execute | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| PASS | XDX_CREATE_ASSIGNMENT does not execute | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| PASS | XDX_VERIFY_ASSIGNMENT does not execute | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| PASS | XDX_CONFIRM_ASSIGNMENT_CREATE does not execute | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| PASS | XDX_SAVE_ASSIGNMENT_CONFIRMATION does not execute | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| PASS | XDX_ASSIGNMENT_CREATE_RESULT does not execute | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| PASS | XDX_SAVE_ASSIGNMENT_RECONCILIATION does not execute | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| PASS | XDX_ASSIGNMENT_CREATE_DECISION does not execute | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| PASS | XDX_ASSIGNMENT_REFERENCES_BLOCKED does not execute | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| PASS | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED does not execute | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| PASS | XDX_ASSIGNMENT_SITE_BLOCKED does not execute | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| PASS | XDX_ASSIGNMENT_PARENT_BLOCKED does not execute | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| PASS | XDX_ASSIGNMENT_DRAFT_RESPONSE does not execute | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| PASS | XDX_REQUEST_SEARCH_NAME does not execute | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| PASS | XDX_RESOLVE_SUPPLIER does not execute | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| PASS | XDX_VALID_PARENT does not execute | Must not execute | XDX_VALID_PARENT | Not executed |
| PASS | XDX_REQUEST_EXACT_PARENT does not execute | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| PASS | XDX_ROUTE_CHILD_READ does not execute | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| PASS | XDX_FETCH_ADDRESSES does not execute | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| PASS | XDX_ADDRESS_RESPONSE does not execute | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| PASS | XDX_FETCH_SITES does not execute | Must not execute | XDX_FETCH_SITES | Not executed |
| PASS | XDX_SITE_RESPONSE does not execute | Must not execute | XDX_SITE_RESPONSE | Not executed |
| PASS | XDX_FETCH_CONTACTS remains inactive | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| PASS | XDX_CONTACT_RESPONSE remains inactive | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| PASS | XDX_FETCH_CLASSIFICATIONS does not execute | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| PASS | XDX_FORMAT_CLASSIFICATIONS does not execute | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| PASS | XDX_CLASSIFICATION_RESPONSE does not execute | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| PASS | XDX_PREPARE_LINK_READ does not execute | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| PASS | XDX_VALID_LINK_READ_SELECTOR does not execute | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| PASS | XDX_RESOLVE_LINK_READ_CONTACT does not execute | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| PASS | XDX_BIND_LINK_READ_CONTACT does not execute | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| PASS | XDX_VALID_LINK_READ_CONTACT does not execute | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| PASS | XDX_FETCH_LINK_READ does not execute | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| PASS | XDX_FORMAT_LINK_READ does not execute | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| PASS | XDX_LINK_READ_RESPONSE does not execute | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| PASS | XDX_LINK_READ_CONTACT_REQUIRED does not execute | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| PASS | XDX_LINK_READ_SELECTOR_REQUIRED does not execute | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| PASS | XDX_PREPARE_ASSIGNMENT_READ does not execute | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| PASS | XDX_VALID_ASSIGNMENT_READ_SELECTOR does not execute | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| PASS | XDX_RESOLVE_ASSIGNMENT_READ_SITE does not execute | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| PASS | XDX_BIND_ASSIGNMENT_READ_SITE does not execute | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| PASS | XDX_VALID_ASSIGNMENT_READ_SITE does not execute | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| PASS | XDX_FETCH_ASSIGNMENT_READ does not execute | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| PASS | XDX_FORMAT_ASSIGNMENT_READ does not execute | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| PASS | XDX_ASSIGNMENT_READ_RESPONSE does not execute | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| PASS | XDX_ASSIGNMENT_READ_SITE_REQUIRED does not execute | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| PASS | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED does not execute | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |


## Semantic Evaluation

**Judge Contract:** model-authored
**Terminal Output Owner:** `XDX_QUERY_RESPONSE`
**Status:** passed
**Provider:** local
**Overall Score:** 5/5
**Minimum Score:** 4/5
**Summary:** All three captured Lee suppliers1252/1496/1497 display with Spend Authorized and Active in exactly four business columns. Showing3of3 matches count3/hasMorefalse. Internal keys appear only in widget identity, never business cells.

### Criterion Results

| Status | Assertion | Criterion | Notes |
| --- | --- | --- | --- |
| PASS | Response stays grounded in recorded data | The output is grounded in the replayed test data. | All three captured Lee suppliers1252/1496/1497 display with Spend Authorized and Active in exactly four business columns. Showing3of3 matches count3/hasMorefalse. Internal keys appear only in widget identity, never business cells. |
| PASS | Grounded supplier results | Every displayed supplier, number, relationship and status agrees with the actual captured BO response; no invented rows or missing returned rows. | All three captured Lee suppliers1252/1496/1497 display with Spend Authorized and Active in exactly four business columns. Showing3of3 matches count3/hasMorefalse. Internal keys appear only in widget identity, never business cells. |
| PASS | Clear business presentation | The output uses a valid oraInfoDisplay multiRecordWidget with exactly Supplier, Supplier number, Business relationship and Status columns; each row has four matching cells, with no displayed SupplierId, node labels or Markdown table syntax. | All three captured Lee suppliers1252/1496/1497 display with Spend Authorized and Active in exactly four business columns. Showing3of3 matches count3/hasMorefalse. Internal keys appear only in widget identity, never business cells. |
| PASS | Accurate result state | An empty items array is reported as no matches, an error as a failed query, and additional pages only when hasMore is true with correct next offset. | All three captured Lee suppliers1252/1496/1497 display with Spend Authorized and Active in exactly four business columns. Showing3of3 matches count3/hasMorefalse. Internal keys appear only in widget identity, never business cells. |

### Unsupported Claims

None.

## Workflow Run Checks

| Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- |
| PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |

## Output Checks

| Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- |
| PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |



## Runtime Metrics

Workflow time: 4320 ms (sum of node times)
Test run time: 5916 ms (includes CLI overhead)
Token usage: observed from runtime events

Aggregate Token Usage

| Input Tokens | Output Tokens | Total Tokens | Model |
| --- | --- | --- | --- |
| 10728 | 766 | 11494 | oci-agent/openai.gpt-4.1-mini-2025-04-14 |

| Node | Input Tokens | Output Tokens | Total Tokens | Model | Source |
| --- | --- | --- | --- | --- | --- |
| XDX_EXTRACT_SEARCH | 4248 | 503 | 4751 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| XDX_QUERY_RESPONSE | 6480 | 263 | 6743 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |


AI Units: computed
Total Token Units: 2
Total AI Units: 10

| Node | Input | Output | Token Units | AI Units | Model Type | Action Type |
| --- | --- | --- | --- | --- | --- | --- |
| XDX_EXTRACT_SEARCH | 4248 | 503 | 1 | 5 | premium | general |
| XDX_QUERY_RESPONSE | 6480 | 263 | 1 | 5 | premium | general |

| Node | Node Time (ms) | LLM Call Time (ms) | Details |
| --- | --- | --- | --- |
| XDX_EXTRACT_SEARCH | 2483 | 2380 | 1 runtime detail; see JSON report |
| XDX_FETCH_SUPPLIERS | 47 |  | 0 runtime details; see JSON report |
| XDX_QUERY_RESPONSE | 1790 | 1717 | 1 runtime detail; see JSON report |

| Observed Field | Values |
| --- | --- |
| modelName | "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14" |
| inputTokens | 4248; 6480 |
| outputTokens | 503; 263 |

## Test Data

Capture policy: record-now

| Node | Node Type | Capture Mode | Truncated | Items | Response Bytes |
| --- | --- | --- | --- | --- | --- |
| XDX_FETCH_SUPPLIERS | BO_FUNCTION | raw | no | 3 | 2376 |

## Workflow Run

**Conversation ID:** workflow-test-query-3a1a551a-01fc-4df2-abe3-654b6d6d263e
**Job ID:** 0eafa46c-c080-4126-b5a7-1707f927d882
**Finish Reason:** stop
**Raw Event Count:** 37

| Node | Events | Input Captured | Output Captured |
| --- | --- | --- | --- |
| START | NODE_EXECUTED | yes | yes |
| XDX_ROUTE_APP_STAGE | NODE_START, NODE_END | yes | yes |
| XDX_EXTRACT_SEARCH | NODE_START, NODE_END | yes | yes |
| XDX_NORMALIZE_REQUEST | NODE_EXECUTED | yes | yes |
| XDX_ROUTE_REQUEST_INTENT | NODE_START, NODE_END | yes | yes |
| XDX_PREPARE_SEARCH | NODE_EXECUTED | yes | yes |
| XDX_VALID_SEARCH | NODE_EXECUTED | yes | yes |
| XDX_FETCH_SUPPLIERS | NODE_START, NODE_END | yes | yes |
| XDX_ROUTE_READ_RESOURCE | NODE_START, NODE_END | yes | yes |
| XDX_QUERY_RESPONSE | NODE_START, NODE_END | yes | yes |


