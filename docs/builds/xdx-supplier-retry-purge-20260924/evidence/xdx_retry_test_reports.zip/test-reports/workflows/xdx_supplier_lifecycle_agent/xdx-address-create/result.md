# Workflow Conversation Test Result: xdx-address-create

**Status:** PASSED
**Workflow:** XDX_SUPPLIER_LIFECYCLE_AGENT (DRAFT v86153667)
**Goal:** Retain the supplier and address draft across review and exact approval, then verify all five submitted fields and both generated keys.
**Data Source:** File replay
**Evaluation:** Deterministic
**Steps:** 4

## Conversation Journey

| # | Step | Type | Intent | Interaction | Outcome | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | prepare-required-address | chat | Prepare a new address draft named XDX HQ Retry 20260923 A for supplier XDX Lifecycle Retry 20260923 A. Set address line to 100 Main St, country code US, email xdx-address-retry-20260923-a@example.invalid, and purchasing purpose true. | Prepare a new address draft named XDX HQ Retry 20260923 A for supplier XDX Lifecycle Retry 20260923 A. Set address line to 100 Main St, country code US, email xdx-address-retry-20260923-a@example.invalid, and purchasing purpose true. | <oraInfoDisplay key="address-result">{"patternId":"multiRecordWidget","title":"Address draft revision 1","description":"Exact supplier and address payload review","properties":{"subtitle":"Address draft saved. No address has been created.","cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Address name","XDX HQ Retry 20260923 A"]},{"cells":["Address line","100 Main St"]},{"cells":["Country code","US"]},{"cells":["Email","xdx-address-retry-20260923-a@example.invalid"]},{"cells":["Purchasing purpose","Yes"]}]}}</oraInfoDisplay> | passed |
| 2 | review-exact-address | chat | Review the exact address draft. | Review the exact address draft. | <oraInfoDisplay key="address-result">{"patternId":"multiRecordWidget","title":"Address draft revision 1","description":"Exact supplier and address payload review","properties":{"subtitle":"Review this supplier and exact five-field address payload. To approve without creating, enter: Approve address revision 1.","cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Address name","XDX HQ Retry 20260923 A"]},{"cells":["Address line","100 Main St"]},{"cells":["Country code","US"]},{"cells":["Email","xdx-address-retry-20260923-a@example.invalid"]},{"cells":["Purchasing purpose","Yes"]}]}}</oraInfoDisplay> | passed |
| 3 | approve-exact-address | chat | Approve address revision 1 | Approve address revision 1 | <oraInfoDisplay key="address-result">{"patternId":"multiRecordWidget","title":"Address draft revision 1","description":"Exact supplier and address payload review","properties":{"subtitle":"Address revision 1 is approved. No address has been created. To create this exact approved address, enter: Create address revision 1.","cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Address name","XDX HQ Retry 20260923 A"]},{"cells":["Address line","100 Main St"]},{"cells":["Country code","US"]},{"cells":["Email","xdx-address-retry-20260923-a@example.invalid"]},{"cells":["Purchasing purpose","Yes"]}]}}</oraInfoDisplay> | passed |
| 4 | create-approved-address | chat | Create address revision 1 | Create address revision 1 | <oraInfoDisplay key="address-result">{"patternId":"multiRecordWidget","title":"Address confirmation","description":"Independent supplier-scoped address verification","properties":{"subtitle":"Address created and independently verified under the approved supplier.","cols":["Supplier","Address","Country","Purchasing purpose"],"selectMode":"none","rows":[{"cells":["XDX Lifecycle Retry 20260923 A","XDX HQ Retry 20260923 A","US","Yes"]}]}}</oraInfoDisplay> | passed |

## Step 1: prepare-required-address

**Status:** passed
**Type:** chat
**Intent:** Prepare a new address draft named XDX HQ Retry 20260923 A for supplier XDX Lifecycle Retry 20260923 A. Set address line to 100 Main St, country code US, email xdx-address-retry-20260923-a@example.invalid, and purchasing purpose true.
**Context Step IDs:** None (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Prepare a new address draft named XDX HQ Retry 20260923 A for supplier XDX Lifecycle Retry 20260923 A. Set address line to 100 Main St, country code US, email xdx-address-retry-20260923-a@example.invalid, and purchasing purpose true.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="address-result">{"patternId":"multiRecordWidget","title":"Address draft revision 1","description":"Exact supplier and address payload review","properties":{"subtitle":"Address draft saved. No address has been created.","cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Address name","XDX HQ Retry 20260923 A"]},{"cells":["Address line","100 Main St"]},{"cells":["Country code","US"]},{"cells":["Email","xdx-address-retry-20260923-a@example.invalid"]},{"cells":["Purchasing purpose","Yes"]}]}}</oraInfoDisplay>
~~~

## Step 2: review-exact-address

**Status:** passed
**Type:** chat
**Intent:** Review the exact address draft.
**Context Step IDs:** prepare-required-address (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Review the exact address draft.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="address-result">{"patternId":"multiRecordWidget","title":"Address draft revision 1","description":"Exact supplier and address payload review","properties":{"subtitle":"Review this supplier and exact five-field address payload. To approve without creating, enter: Approve address revision 1.","cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Address name","XDX HQ Retry 20260923 A"]},{"cells":["Address line","100 Main St"]},{"cells":["Country code","US"]},{"cells":["Email","xdx-address-retry-20260923-a@example.invalid"]},{"cells":["Purchasing purpose","Yes"]}]}}</oraInfoDisplay>
~~~

## Step 3: approve-exact-address

**Status:** passed
**Type:** chat
**Intent:** Approve address revision 1
**Context Step IDs:** prepare-required-address, review-exact-address (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Approve address revision 1",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="address-result">{"patternId":"multiRecordWidget","title":"Address draft revision 1","description":"Exact supplier and address payload review","properties":{"subtitle":"Address revision 1 is approved. No address has been created. To create this exact approved address, enter: Create address revision 1.","cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Address name","XDX HQ Retry 20260923 A"]},{"cells":["Address line","100 Main St"]},{"cells":["Country code","US"]},{"cells":["Email","xdx-address-retry-20260923-a@example.invalid"]},{"cells":["Purchasing purpose","Yes"]}]}}</oraInfoDisplay>
~~~

## Step 4: create-approved-address

**Status:** passed
**Type:** chat
**Intent:** Create address revision 1
**Context Step IDs:** prepare-required-address, review-exact-address, approve-exact-address (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Create address revision 1",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="address-result">{"patternId":"multiRecordWidget","title":"Address confirmation","description":"Independent supplier-scoped address verification","properties":{"subtitle":"Address created and independently verified under the approved supplier.","cols":["Supplier","Address","Country","Purchasing purpose"],"selectMode":"none","rows":[{"cells":["XDX Lifecycle Retry 20260923 A","XDX HQ Retry 20260923 A","US","Yes"]}]}}</oraInfoDisplay>
~~~

## Verification Summary

| Verification | Status | Result |
| --- | --- | --- |
| Node order and counts | PASSED | 5/5 passed |
| Path assertions | PASSED | 996/996 passed |
| Node assertions | PASSED | 5/5 passed |
| Workflow run checks | PASSED | 6/6 passed |
| Output checks | PASSED | 11/11 passed |

## Node Order and Count

### Required Relative Order

Other nodes may execute between the listed nodes.

| Step | Status | Assertion | Required Relative Order | Observed or Failure |
| --- | --- | --- | --- | --- |
| prepare-required-address | PASS | Address route execution order | XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_ADDRESS_DRAFT -> XDX_SAVE_ADDRESS_DRAFT -> XDX_ADDRESS_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_ADDRESS_DRAFT -> XDX_SAVE_ADDRESS_DRAFT -> XDX_ADDRESS_DRAFT_RESPONSE |
| review-exact-address | PASS | Address route execution order | XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_ADDRESS_DRAFT -> XDX_SAVE_ADDRESS_DRAFT -> XDX_ADDRESS_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_ADDRESS_DRAFT -> XDX_SAVE_ADDRESS_DRAFT -> XDX_ADDRESS_DRAFT_RESPONSE |
| approve-exact-address | PASS | Address route execution order | XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_ADDRESS_DRAFT -> XDX_SAVE_ADDRESS_DRAFT -> XDX_ADDRESS_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_ADDRESS_DRAFT -> XDX_SAVE_ADDRESS_DRAFT -> XDX_ADDRESS_DRAFT_RESPONSE |
| create-approved-address | PASS | Address route execution order | XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_ROUTE_REQUEST_INTENT -> XDX_PREPARE_ADDRESS_CREATE -> XDX_VALID_ADDRESS_CREATE -> XDX_RESOLVE_ADDRESS_PARENT -> XDX_BIND_ADDRESS_PARENT -> XDX_VALID_ADDRESS_PARENT -> XDX_CHECK_ADDRESS_DUPLICATE -> XDX_DECIDE_ADDRESS_CREATE -> XDX_CAN_POST_ADDRESS -> XDX_SAVE_ADDRESS_ATTEMPT -> XDX_CREATE_ADDRESS -> XDX_VERIFY_ADDRESS -> XDX_CONFIRM_ADDRESS_CREATE -> XDX_SAVE_ADDRESS_CONFIRMATION -> XDX_ADDRESS_CREATE_RESULT | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_PREPARE_ADDRESS_CREATE -> XDX_VALID_ADDRESS_CREATE -> XDX_RESOLVE_ADDRESS_PARENT -> XDX_BIND_ADDRESS_PARENT -> XDX_VALID_ADDRESS_PARENT -> XDX_CHECK_ADDRESS_DUPLICATE -> XDX_DECIDE_ADDRESS_CREATE -> XDX_CAN_POST_ADDRESS -> XDX_SAVE_ADDRESS_ATTEMPT -> XDX_CREATE_ADDRESS -> XDX_VERIFY_ADDRESS -> XDX_CONFIRM_ADDRESS_CREATE -> XDX_SAVE_ADDRESS_CONFIRMATION -> XDX_ADDRESS_CREATE_RESULT |

### Node Count Checks

| Step | Assertion | Node Code | Expected | Observed | Status |
| --- | --- | --- | --- | --- | --- |
| create-approved-address | One address POST node | XDX_CREATE_ADDRESS | exactly 1 | 1 | PASS |

## Path Assertions

| Step | Status | Assertion | Requirement | Node Code | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-address | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| prepare-required-address | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| prepare-required-address | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| prepare-required-address | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| prepare-required-address | PASS | Execute XDX_REDUCE_ADDRESS_DRAFT | Must execute | XDX_REDUCE_ADDRESS_DRAFT | Executed |
| prepare-required-address | PASS | Execute XDX_SAVE_ADDRESS_DRAFT | Must execute | XDX_SAVE_ADDRESS_DRAFT | Executed |
| prepare-required-address | PASS | Execute XDX_ADDRESS_DRAFT_RESPONSE | Must execute | XDX_ADDRESS_DRAFT_RESPONSE | Executed |
| prepare-required-address | PASS | Do not execute XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| prepare-required-address | PASS | Do not execute XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| prepare-required-address | PASS | Do not execute XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| prepare-required-address | PASS | Do not execute XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| prepare-required-address | PASS | Do not execute XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| prepare-required-address | PASS | Do not execute XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| prepare-required-address | PASS | Do not execute XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| prepare-required-address | PASS | Do not execute XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| prepare-required-address | PASS | Do not execute XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| prepare-required-address | PASS | Do not execute XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| prepare-required-address | PASS | Do not execute XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| prepare-required-address | PASS | Do not execute XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| prepare-required-address | PASS | Do not execute XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| prepare-required-address | PASS | Do not execute XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| prepare-required-address | PASS | Do not execute XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| prepare-required-address | PASS | Do not execute XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| prepare-required-address | PASS | Do not execute XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| prepare-required-address | PASS | Do not execute XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| prepare-required-address | PASS | Do not execute XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| prepare-required-address | PASS | Do not execute XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| prepare-required-address | PASS | Do not execute XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| prepare-required-address | PASS | Do not execute XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| prepare-required-address | PASS | Do not execute XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| prepare-required-address | PASS | Do not execute XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| prepare-required-address | PASS | Do not execute XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| prepare-required-address | PASS | Do not execute XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| prepare-required-address | PASS | Do not execute XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| prepare-required-address | PASS | Do not execute XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| prepare-required-address | PASS | Do not execute XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| prepare-required-address | PASS | Do not execute XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| prepare-required-address | PASS | Do not execute XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| prepare-required-address | PASS | Do not execute XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| prepare-required-address | PASS | Do not execute XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| prepare-required-address | PASS | Do not execute XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| prepare-required-address | PASS | Do not execute XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| prepare-required-address | PASS | Do not execute XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| prepare-required-address | PASS | Do not execute XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| prepare-required-address | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| prepare-required-address | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| prepare-required-address | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| prepare-required-address | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| prepare-required-address | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| prepare-required-address | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| prepare-required-address | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| prepare-required-address | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| prepare-required-address | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| prepare-required-address | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| prepare-required-address | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| prepare-required-address | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| prepare-required-address | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| prepare-required-address | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| prepare-required-address | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| prepare-required-address | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| prepare-required-address | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| prepare-required-address | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| prepare-required-address | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| prepare-required-address | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-address | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-address | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-address | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| prepare-required-address | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| prepare-required-address | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| prepare-required-address | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| review-exact-address | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| review-exact-address | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| review-exact-address | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| review-exact-address | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| review-exact-address | PASS | Execute XDX_REDUCE_ADDRESS_DRAFT | Must execute | XDX_REDUCE_ADDRESS_DRAFT | Executed |
| review-exact-address | PASS | Execute XDX_SAVE_ADDRESS_DRAFT | Must execute | XDX_SAVE_ADDRESS_DRAFT | Executed |
| review-exact-address | PASS | Execute XDX_ADDRESS_DRAFT_RESPONSE | Must execute | XDX_ADDRESS_DRAFT_RESPONSE | Executed |
| review-exact-address | PASS | Do not execute XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| review-exact-address | PASS | Do not execute XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| review-exact-address | PASS | Do not execute XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| review-exact-address | PASS | Do not execute XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| review-exact-address | PASS | Do not execute XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| review-exact-address | PASS | Do not execute XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| review-exact-address | PASS | Do not execute XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| review-exact-address | PASS | Do not execute XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| review-exact-address | PASS | Do not execute XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| review-exact-address | PASS | Do not execute XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| review-exact-address | PASS | Do not execute XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| review-exact-address | PASS | Do not execute XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| review-exact-address | PASS | Do not execute XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| review-exact-address | PASS | Do not execute XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| review-exact-address | PASS | Do not execute XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| review-exact-address | PASS | Do not execute XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| review-exact-address | PASS | Do not execute XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| review-exact-address | PASS | Do not execute XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| review-exact-address | PASS | Do not execute XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| review-exact-address | PASS | Do not execute XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| review-exact-address | PASS | Do not execute XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| review-exact-address | PASS | Do not execute XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| review-exact-address | PASS | Do not execute XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| review-exact-address | PASS | Do not execute XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| review-exact-address | PASS | Do not execute XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| review-exact-address | PASS | Do not execute XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| review-exact-address | PASS | Do not execute XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| review-exact-address | PASS | Do not execute XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| review-exact-address | PASS | Do not execute XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| review-exact-address | PASS | Do not execute XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| review-exact-address | PASS | Do not execute XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| review-exact-address | PASS | Do not execute XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| review-exact-address | PASS | Do not execute XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| review-exact-address | PASS | Do not execute XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| review-exact-address | PASS | Do not execute XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| review-exact-address | PASS | Do not execute XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| review-exact-address | PASS | Do not execute XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| review-exact-address | PASS | Do not execute XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| review-exact-address | PASS | Do not execute XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| review-exact-address | PASS | Do not execute XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| review-exact-address | PASS | Do not execute XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| review-exact-address | PASS | Do not execute XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| review-exact-address | PASS | Do not execute XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| review-exact-address | PASS | Do not execute XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| review-exact-address | PASS | Do not execute XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| review-exact-address | PASS | Do not execute XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| review-exact-address | PASS | Do not execute XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| review-exact-address | PASS | Do not execute XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| review-exact-address | PASS | Do not execute XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| review-exact-address | PASS | Do not execute XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| review-exact-address | PASS | Do not execute XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| review-exact-address | PASS | Do not execute XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| review-exact-address | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| review-exact-address | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| review-exact-address | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| review-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| review-exact-address | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| review-exact-address | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| review-exact-address | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| review-exact-address | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| review-exact-address | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| review-exact-address | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| review-exact-address | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| review-exact-address | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| review-exact-address | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| review-exact-address | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| review-exact-address | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| review-exact-address | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| review-exact-address | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| review-exact-address | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| review-exact-address | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| review-exact-address | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| review-exact-address | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| review-exact-address | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| review-exact-address | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| review-exact-address | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| review-exact-address | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| review-exact-address | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| review-exact-address | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| approve-exact-address | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| approve-exact-address | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| approve-exact-address | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| approve-exact-address | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| approve-exact-address | PASS | Execute XDX_REDUCE_ADDRESS_DRAFT | Must execute | XDX_REDUCE_ADDRESS_DRAFT | Executed |
| approve-exact-address | PASS | Execute XDX_SAVE_ADDRESS_DRAFT | Must execute | XDX_SAVE_ADDRESS_DRAFT | Executed |
| approve-exact-address | PASS | Execute XDX_ADDRESS_DRAFT_RESPONSE | Must execute | XDX_ADDRESS_DRAFT_RESPONSE | Executed |
| approve-exact-address | PASS | Do not execute XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| approve-exact-address | PASS | Do not execute XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| approve-exact-address | PASS | Do not execute XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| approve-exact-address | PASS | Do not execute XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| approve-exact-address | PASS | Do not execute XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| approve-exact-address | PASS | Do not execute XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| approve-exact-address | PASS | Do not execute XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| approve-exact-address | PASS | Do not execute XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| approve-exact-address | PASS | Do not execute XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| approve-exact-address | PASS | Do not execute XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| approve-exact-address | PASS | Do not execute XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| approve-exact-address | PASS | Do not execute XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| approve-exact-address | PASS | Do not execute XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| approve-exact-address | PASS | Do not execute XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| approve-exact-address | PASS | Do not execute XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| approve-exact-address | PASS | Do not execute XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| approve-exact-address | PASS | Do not execute XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| approve-exact-address | PASS | Do not execute XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| approve-exact-address | PASS | Do not execute XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| approve-exact-address | PASS | Do not execute XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| approve-exact-address | PASS | Do not execute XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| approve-exact-address | PASS | Do not execute XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| approve-exact-address | PASS | Do not execute XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| approve-exact-address | PASS | Do not execute XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| approve-exact-address | PASS | Do not execute XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| approve-exact-address | PASS | Do not execute XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| approve-exact-address | PASS | Do not execute XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| approve-exact-address | PASS | Do not execute XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| approve-exact-address | PASS | Do not execute XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| approve-exact-address | PASS | Do not execute XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| approve-exact-address | PASS | Do not execute XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| approve-exact-address | PASS | Do not execute XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| approve-exact-address | PASS | Do not execute XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| approve-exact-address | PASS | Do not execute XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| approve-exact-address | PASS | Do not execute XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| approve-exact-address | PASS | Do not execute XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| approve-exact-address | PASS | Do not execute XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| approve-exact-address | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| approve-exact-address | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| approve-exact-address | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-exact-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| approve-exact-address | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| approve-exact-address | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| approve-exact-address | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| approve-exact-address | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| approve-exact-address | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| approve-exact-address | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| approve-exact-address | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| approve-exact-address | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| approve-exact-address | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| approve-exact-address | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| approve-exact-address | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| approve-exact-address | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| approve-exact-address | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| approve-exact-address | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| approve-exact-address | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| approve-exact-address | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| approve-exact-address | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| approve-exact-address | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| approve-exact-address | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| approve-exact-address | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| approve-exact-address | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| approve-exact-address | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| approve-exact-address | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| create-approved-address | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| create-approved-address | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| create-approved-address | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| create-approved-address | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| create-approved-address | PASS | Execute XDX_PREPARE_ADDRESS_CREATE | Must execute | XDX_PREPARE_ADDRESS_CREATE | Executed |
| create-approved-address | PASS | Execute XDX_VALID_ADDRESS_CREATE | Must execute | XDX_VALID_ADDRESS_CREATE | Executed |
| create-approved-address | PASS | Execute XDX_RESOLVE_ADDRESS_PARENT | Must execute | XDX_RESOLVE_ADDRESS_PARENT | Executed |
| create-approved-address | PASS | Execute XDX_BIND_ADDRESS_PARENT | Must execute | XDX_BIND_ADDRESS_PARENT | Executed |
| create-approved-address | PASS | Execute XDX_VALID_ADDRESS_PARENT | Must execute | XDX_VALID_ADDRESS_PARENT | Executed |
| create-approved-address | PASS | Execute XDX_CHECK_ADDRESS_DUPLICATE | Must execute | XDX_CHECK_ADDRESS_DUPLICATE | Executed |
| create-approved-address | PASS | Execute XDX_DECIDE_ADDRESS_CREATE | Must execute | XDX_DECIDE_ADDRESS_CREATE | Executed |
| create-approved-address | PASS | Execute XDX_CAN_POST_ADDRESS | Must execute | XDX_CAN_POST_ADDRESS | Executed |
| create-approved-address | PASS | Execute XDX_SAVE_ADDRESS_ATTEMPT | Must execute | XDX_SAVE_ADDRESS_ATTEMPT | Executed |
| create-approved-address | PASS | Execute XDX_CREATE_ADDRESS | Must execute | XDX_CREATE_ADDRESS | Executed |
| create-approved-address | PASS | Execute XDX_VERIFY_ADDRESS | Must execute | XDX_VERIFY_ADDRESS | Executed |
| create-approved-address | PASS | Execute XDX_CONFIRM_ADDRESS_CREATE | Must execute | XDX_CONFIRM_ADDRESS_CREATE | Executed |
| create-approved-address | PASS | Execute XDX_SAVE_ADDRESS_CONFIRMATION | Must execute | XDX_SAVE_ADDRESS_CONFIRMATION | Executed |
| create-approved-address | PASS | Execute XDX_ADDRESS_CREATE_RESULT | Must execute | XDX_ADDRESS_CREATE_RESULT | Executed |
| create-approved-address | PASS | Do not execute XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| create-approved-address | PASS | Do not execute XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| create-approved-address | PASS | Do not execute XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| create-approved-address | PASS | Do not execute XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| create-approved-address | PASS | Do not execute XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| create-approved-address | PASS | Do not execute XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| create-approved-address | PASS | Do not execute XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| create-approved-address | PASS | Do not execute XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| create-approved-address | PASS | Do not execute XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| create-approved-address | PASS | Do not execute XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| create-approved-address | PASS | Do not execute XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| create-approved-address | PASS | Do not execute XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| create-approved-address | PASS | Do not execute XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| create-approved-address | PASS | Do not execute XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| create-approved-address | PASS | Do not execute XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| create-approved-address | PASS | Do not execute XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| create-approved-address | PASS | Do not execute XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| create-approved-address | PASS | Do not execute XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| create-approved-address | PASS | Do not execute XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| create-approved-address | PASS | Do not execute XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| create-approved-address | PASS | Do not execute XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| create-approved-address | PASS | Do not execute XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| create-approved-address | PASS | Do not execute XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| create-approved-address | PASS | Do not execute XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| create-approved-address | PASS | Do not execute XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| create-approved-address | PASS | Do not execute XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| create-approved-address | PASS | Do not execute XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| create-approved-address | PASS | Do not execute XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| create-approved-address | PASS | Do not execute XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| create-approved-address | PASS | Do not execute XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| create-approved-address | PASS | Do not execute XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| create-approved-address | PASS | Do not execute XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| create-approved-address | PASS | Do not execute XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| create-approved-address | PASS | Do not execute XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| create-approved-address | PASS | Do not execute XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| create-approved-address | PASS | Do not execute XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| create-approved-address | PASS | Do not execute XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| create-approved-address | PASS | Do not execute XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| create-approved-address | PASS | Do not execute XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| create-approved-address | PASS | Do not execute XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| create-approved-address | PASS | Do not execute XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| create-approved-address | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| create-approved-address | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| create-approved-address | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| create-approved-address | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| create-approved-address | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| create-approved-address | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| create-approved-address | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| create-approved-address | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| create-approved-address | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| create-approved-address | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| create-approved-address | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| create-approved-address | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| create-approved-address | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| create-approved-address | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| create-approved-address | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| create-approved-address | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| create-approved-address | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| create-approved-address | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| create-approved-address | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| create-approved-address | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| create-approved-address | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-address | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-address | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-address | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| create-approved-address | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| create-approved-address | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| create-approved-address | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |

## Node Assertions

| Step | Status | Assertion | Node Code | Occurrence | Asserted Value | Operator | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| prepare-required-address | PASS | Approved supplier name retained | XDX_REDUCE_ADDRESS_DRAFT | last | output/result/state/supplierName | equals | "XDX Lifecycle Retry 20260923 A" | string (30 characters) |
| prepare-required-address | PASS | Initial address revision | XDX_REDUCE_ADDRESS_DRAFT | last | output/result/state/revision | equals | 1 | number |
| review-exact-address | PASS | Purchasing purpose retained | XDX_REDUCE_ADDRESS_DRAFT | last | output/result/state/payload/AddressPurposeOrderingFlag | equals | true | boolean |
| approve-exact-address | PASS | Current exact address revision approved | XDX_REDUCE_ADDRESS_DRAFT | last | output/result/state/approvedRevision | equals | 1 | number |
| create-approved-address | PASS | Independent address verification succeeds | XDX_CONFIRM_ADDRESS_CREATE | last | output/result/confirmed | equals | true | boolean |

## Workflow Run Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-address | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| review-exact-address | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| approve-exact-address | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| create-approved-address | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| Conversation | PASS | conversationStepOrder | conversationStepOrder | prepare-required-address -> review-exact-address -> approve-exact-address -> create-approved-address | Verified |
| Conversation | PASS | conversationIdReuse | conversationIdReuse | Every executed step uses one conversation ID. | Verified |

## Output Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-address | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| prepare-required-address | PASS | Expected address result 1 | contains | XDX HQ Retry 20260923 A | Found "XDX HQ Retry 20260923 A" |
| prepare-required-address | PASS | Expected address result 2 | contains | XDX Lifecycle Retry 20260923 A | Found "XDX Lifecycle Retry 20260923 A" |
| review-exact-address | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| review-exact-address | PASS | Expected address result 1 | contains | Approve address revision 1 | Found "Approve address revision 1" |
| review-exact-address | PASS | Expected address result 2 | contains | xdx-address-retry-20260923-a@example.invalid | Found "xdx-address-retry-20260923-a@example.invalid" |
| approve-exact-address | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| approve-exact-address | PASS | Expected address result 1 | contains | Create address revision 1 | Found "Create address revision 1" |
| create-approved-address | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| create-approved-address | PASS | Expected address result 1 | contains | Address created and independently verified | Found "Address created and independently verified" |
| create-approved-address | PASS | Expected address result 2 | contains | XDX HQ Retry 20260923 A | Found "XDX HQ Retry 20260923 A" |

## Runtime Metrics

Workflow time: 18005 ms (sum of node times)
Test run time: 24180 ms (includes CLI overhead)
Token usage: observed from runtime events

Aggregate Token Usage

| Input Tokens | Output Tokens | Total Tokens | Model |
| --- | --- | --- | --- |
| 18334 | 2090 | 20424 | oci-agent/openai.gpt-4.1-mini-2025-04-14 |

| Node | Input Tokens | Output Tokens | Total Tokens | Model | Source |
| --- | --- | --- | --- | --- | --- |
| approve-exact-address:XDX_EXTRACT_SEARCH | 4680 | 501 | 5181 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| create-approved-address:XDX_EXTRACT_SEARCH | 4883 | 535 | 5418 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| prepare-required-address:XDX_EXTRACT_SEARCH | 4292 | 544 | 4836 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| review-exact-address:XDX_EXTRACT_SEARCH | 4479 | 510 | 4989 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |


AI Units: computed
Total Token Units: 4
Total AI Units: 20

| Node | Input | Output | Token Units | AI Units | Model Type | Action Type |
| --- | --- | --- | --- | --- | --- | --- |
| approve-exact-address:XDX_EXTRACT_SEARCH | 4680 | 501 | 1 | 5 | premium | general |
| create-approved-address:XDX_EXTRACT_SEARCH | 4883 | 535 | 1 | 5 | premium | general |
| prepare-required-address:XDX_EXTRACT_SEARCH | 4292 | 544 | 1 | 5 | premium | general |
| review-exact-address:XDX_EXTRACT_SEARCH | 4479 | 510 | 1 | 5 | premium | general |

| Node | Node Time (ms) | LLM Call Time (ms) | Details |
| --- | --- | --- | --- |
| prepare-required-address:XDX_EXTRACT_SEARCH | 9888 | 9371 | 1 runtime detail; see JSON report |
| review-exact-address:XDX_EXTRACT_SEARCH | 2492 | 2405 | 1 runtime detail; see JSON report |
| approve-exact-address:XDX_EXTRACT_SEARCH | 2784 | 2661 | 1 runtime detail; see JSON report |
| create-approved-address:XDX_EXTRACT_SEARCH | 2682 | 2593 | 1 runtime detail; see JSON report |
| create-approved-address:XDX_RESOLVE_ADDRESS_PARENT | 45 |  | 0 runtime details; see JSON report |
| create-approved-address:XDX_CHECK_ADDRESS_DUPLICATE | 47 |  | 0 runtime details; see JSON report |
| create-approved-address:XDX_CREATE_ADDRESS | 47 |  | 0 runtime details; see JSON report |
| create-approved-address:XDX_VERIFY_ADDRESS | 20 |  | 0 runtime details; see JSON report |

| Observed Field | Values |
| --- | --- |
| modelName | "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14" |
| inputTokens | 4292; 4479; 4680; 4883 |
| outputTokens | 544; 510; 501; 535 |

## Test Data

| Step | Data Source | Evaluation |
| --- | --- | --- |
| prepare-required-address | File replay | Deterministic |
| review-exact-address | File replay | Deterministic |
| approve-exact-address | File replay | Deterministic |
| create-approved-address | File replay | Deterministic |

## Workflow Run

### Execution Timeline

| Step | Phase Sequence | Node | Event |
| --- | --- | --- | --- |
| prepare-required-address | 1 | START | NODE_EXECUTED |
| prepare-required-address | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| prepare-required-address | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| prepare-required-address | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| prepare-required-address | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| prepare-required-address | 6 | XDX_REDUCE_ADDRESS_DRAFT | NODE_EXECUTED |
| prepare-required-address | 7 | XDX_SAVE_ADDRESS_DRAFT | NODE_EXECUTED |
| prepare-required-address | 8 | XDX_ADDRESS_DRAFT_RESPONSE | NODE_EXECUTED |
| review-exact-address | 1 | START | NODE_EXECUTED |
| review-exact-address | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| review-exact-address | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| review-exact-address | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| review-exact-address | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| review-exact-address | 6 | XDX_REDUCE_ADDRESS_DRAFT | NODE_EXECUTED |
| review-exact-address | 7 | XDX_SAVE_ADDRESS_DRAFT | NODE_EXECUTED |
| review-exact-address | 8 | XDX_ADDRESS_DRAFT_RESPONSE | NODE_EXECUTED |
| approve-exact-address | 1 | START | NODE_EXECUTED |
| approve-exact-address | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| approve-exact-address | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| approve-exact-address | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| approve-exact-address | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| approve-exact-address | 6 | XDX_REDUCE_ADDRESS_DRAFT | NODE_EXECUTED |
| approve-exact-address | 7 | XDX_SAVE_ADDRESS_DRAFT | NODE_EXECUTED |
| approve-exact-address | 8 | XDX_ADDRESS_DRAFT_RESPONSE | NODE_EXECUTED |
| create-approved-address | 1 | START | NODE_EXECUTED |
| create-approved-address | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| create-approved-address | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| create-approved-address | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| create-approved-address | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| create-approved-address | 6 | XDX_PREPARE_ADDRESS_CREATE | NODE_EXECUTED |
| create-approved-address | 7 | XDX_VALID_ADDRESS_CREATE | NODE_EXECUTED |
| create-approved-address | 8 | XDX_RESOLVE_ADDRESS_PARENT | NODE_START |
| create-approved-address | 9 | XDX_BIND_ADDRESS_PARENT | NODE_EXECUTED |
| create-approved-address | 10 | XDX_VALID_ADDRESS_PARENT | NODE_EXECUTED |
| create-approved-address | 11 | XDX_CHECK_ADDRESS_DUPLICATE | NODE_START |
| create-approved-address | 12 | XDX_DECIDE_ADDRESS_CREATE | NODE_EXECUTED |
| create-approved-address | 13 | XDX_CAN_POST_ADDRESS | NODE_EXECUTED |
| create-approved-address | 14 | XDX_SAVE_ADDRESS_ATTEMPT | NODE_EXECUTED |
| create-approved-address | 15 | XDX_CREATE_ADDRESS | NODE_START |
| create-approved-address | 16 | XDX_VERIFY_ADDRESS | NODE_START |
| create-approved-address | 17 | XDX_CONFIRM_ADDRESS_CREATE | NODE_EXECUTED |
| create-approved-address | 18 | XDX_SAVE_ADDRESS_CONFIRMATION | NODE_EXECUTED |
| create-approved-address | 19 | XDX_ADDRESS_CREATE_RESULT | NODE_EXECUTED |

### Other Observed Nodes

| Node | Observed |
| --- | --- |
| START | 4 |
| XDX_ADDRESS_CREATE_RESULT | 1 |
| XDX_ADDRESS_DRAFT_RESPONSE | 3 |
| XDX_BIND_ADDRESS_PARENT | 1 |
| XDX_CAN_POST_ADDRESS | 1 |
| XDX_CHECK_ADDRESS_DUPLICATE | 1 |
| XDX_CONFIRM_ADDRESS_CREATE | 1 |
| XDX_DECIDE_ADDRESS_CREATE | 1 |
| XDX_EXTRACT_SEARCH | 4 |
| XDX_NORMALIZE_REQUEST | 4 |
| XDX_PREPARE_ADDRESS_CREATE | 1 |
| XDX_REDUCE_ADDRESS_DRAFT | 3 |
| XDX_RESOLVE_ADDRESS_PARENT | 1 |
| XDX_ROUTE_APP_STAGE | 4 |
| XDX_ROUTE_REQUEST_INTENT | 4 |
| XDX_SAVE_ADDRESS_ATTEMPT | 1 |
| XDX_SAVE_ADDRESS_CONFIRMATION | 1 |
| XDX_SAVE_ADDRESS_DRAFT | 3 |
| XDX_VALID_ADDRESS_CREATE | 1 |
| XDX_VALID_ADDRESS_PARENT | 1 |
| XDX_VERIFY_ADDRESS | 1 |

## Report Files

- JSON report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-address-create\result.json`
- Markdown report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-address-create\result.md`
- Test file: `test/workflows/xdx_supplier_lifecycle_agent/xdx-address-create.json`
