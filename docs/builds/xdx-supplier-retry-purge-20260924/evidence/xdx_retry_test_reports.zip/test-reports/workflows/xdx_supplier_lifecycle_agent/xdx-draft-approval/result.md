# Workflow Conversation Test Result: xdx-draft-approval

**Status:** PASSED
**Workflow:** XDX_SUPPLIER_LIFECYCLE_AGENT (DRAFT v86153667)
**Goal:** Prove deterministic supplier draft persistence, exact payload review, approval and invalidation after editing.
**Data Source:** File replay
**Evaluation:** Hybrid
**Steps:** 6

## Conversation Journey

| # | Step | Type | Intent | Interaction | Outcome | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | start-supplier-draft | chat | Prepare a new supplier draft named XDX Review Only 20260923 A. | Prepare a new supplier draft named XDX Review Only 20260923 A. | <oraInfoDisplay key="list"><br>{<br>  "title": "Supplier draft revision 1",<br>  "patternId": "multiRecordWidget",<br>  "description": "Supplier draft details with validation errors",<br>  "properties": {<br>    "subtitle": "Draft updated. Any previous approval is invalid. No supplier has been created. Errors: Business relationship must be explicitly set to the validated value Spend Authorized. Tax organization type must be explicitly set to the validated value Corporation.",<br>    "selectMode": "none",<br>    "cols": ["Field", "Value"],<br>    "rows": [<br>      {<br>        "cells": ["Supplier name", "XDX Review Only 20260923 A"]<br>      },<br>      {<br>        "cells": ["Business relationship", "Required"]<br>      },<br>      {<br>        "cells": ["Tax organization type", "Required"]<br>      }<br>    ]<br>  }<br>}<br></oraInfoDisplay> | passed |
| 2 | complete-required-fields | chat | Set the supplier draft business relationship to Spend Authorized and tax organization type to Corporation. | Set the supplier draft business relationship to Spend Authorized and tax organization type to Corporation. | <oraInfoDisplay key="list"><br>{<br>  "title": "Supplier draft revision 2",<br>  "patternId": "multiRecordWidget",<br>  "description": "Supplier draft details with current revision and validation status",<br>  "properties": {<br>    "subtitle": "Draft updated. Any previous approval is invalid. No supplier has been created.",<br>    "selectMode": "none",<br>    "cols": ["Field", "Value"],<br>    "rows": [<br>      {<br>        "cells": ["Supplier", "XDX Review Only 20260923 A"]<br>      },<br>      {<br>        "cells": ["BusinessRelationship", "Spend Authorized"]<br>      },<br>      {<br>        "cells": ["TaxOrganizationType", "Corporation"]<br>      }<br>    ]<br>  }<br>}<br></oraInfoDisplay> | passed |
| 3 | review-exact-payload | chat | Review the supplier draft. | Review the supplier draft. | <oraInfoDisplay key="list"><br>{<br>  "title": "Supplier draft revision 2",<br>  "patternId": "multiRecordWidget",<br>  "description": "Exact required supplier payload fields for review",<br>  "properties": {<br>    "subtitle": "Review these exact three fields. To approve this draft without creating it, enter: Approve supplier revision 2.",<br>    "selectMode": "none",<br>    "cols": ["Field", "Value"],<br>    "rows": [<br>      {<br>        "cells": ["Supplier", "XDX Review Only 20260923 A"]<br>      },<br>      {<br>        "cells": ["BusinessRelationship", "Spend Authorized"]<br>      },<br>      {<br>        "cells": ["TaxOrganizationType", "Corporation"]<br>      }<br>    ]<br>  }<br>}<br></oraInfoDisplay> | passed |
| 4 | approve-reviewed-revision | chat | Approve supplier revision 2 | Approve supplier revision 2 | <oraInfoDisplay key="list"><br>{<br>  "title": "Supplier draft revision 2",<br>  "patternId": "multiRecordWidget",<br>  "description": "Exact required supplier payload fields and values",<br>  "properties": {<br>    "subtitle": "Supplier draft revision 2 is approved. No supplier has been created. To create this exact approved payload, enter: Create supplier revision 2.",<br>    "selectMode": "none",<br>    "cols": ["Field", "Value"],<br>    "rows": [<br>      {<br>        "cells": ["Supplier", "XDX Review Only 20260923 A"]<br>      },<br>      {<br>        "cells": ["BusinessRelationship", "Spend Authorized"]<br>      },<br>      {<br>        "cells": ["TaxOrganizationType", "Corporation"]<br>      }<br>    ]<br>  }<br>}<br></oraInfoDisplay> | passed |
| 5 | edit-approved-draft | chat | Change the supplier draft name to XDX Review Only 20260923 A Revised. | Change the supplier draft name to XDX Review Only 20260923 A Revised. | <oraInfoDisplay key="list"><br>{<br>  "title": "Supplier draft revision 3",<br>  "patternId": "multiRecordWidget",<br>  "description": "Current supplier draft details",<br>  "properties": {<br>    "subtitle": "Draft updated. Any previous approval is invalid. No supplier has been created.",<br>    "selectMode": "none",<br>    "cols": ["Field", "Value"],<br>    "rows": [<br>      {<br>        "cells": ["Supplier", "XDX Review Only 20260923 A Revised"]<br>      },<br>      {<br>        "cells": ["BusinessRelationship", "Spend Authorized"]<br>      },<br>      {<br>        "cells": ["TaxOrganizationType", "Corporation"]<br>      }<br>    ]<br>  }<br>}<br></oraInfoDisplay> | passed |
| 6 | review-revised-payload | chat | Review the supplier draft again. | Review the supplier draft again. | <oraInfoDisplay key="list"><br>{<br>  "title": "Supplier draft revision 3",<br>  "patternId": "multiRecordWidget",<br>  "description": "Exact required supplier payload fields for review",<br>  "properties": {<br>    "subtitle": "Review these exact three fields. To approve this draft without creating it, enter: Approve supplier revision 3.",<br>    "cols": ["Field", "Value"],<br>    "rows": [<br>      {<br>        "cells": ["Supplier", "XDX Review Only 20260923 A Revised"]<br>      },<br>      {<br>        "cells": ["BusinessRelationship", "Spend Authorized"]<br>      },<br>      {<br>        "cells": ["TaxOrganizationType", "Corporation"]<br>      }<br>    ],<br>    "selectMode": "none"<br>  }<br>}<br></oraInfoDisplay> | passed |

## Step 1: start-supplier-draft

**Status:** passed
**Type:** chat
**Intent:** Prepare a new supplier draft named XDX Review Only 20260923 A.
**Context Step IDs:** None (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Prepare a new supplier draft named XDX Review Only 20260923 A.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="list">
{
  "title": "Supplier draft revision 1",
  "patternId": "multiRecordWidget",
  "description": "Supplier draft details with validation errors",
  "properties": {
    "subtitle": "Draft updated. Any previous approval is invalid. No supplier has been created. Errors: Business relationship must be explicitly set to the validated value Spend Authorized. Tax organization type must be explicitly set to the validated value Corporation.",
    "selectMode": "none",
    "cols": ["Field", "Value"],
    "rows": [
      {
        "cells": ["Supplier name", "XDX Review Only 20260923 A"]
      },
      {
        "cells": ["Business relationship", "Required"]
      },
      {
        "cells": ["Tax organization type", "Required"]
      }
    ]
  }
}
</oraInfoDisplay>
~~~

## Step 2: complete-required-fields

**Status:** passed
**Type:** chat
**Intent:** Set the supplier draft business relationship to Spend Authorized and tax organization type to Corporation.
**Context Step IDs:** start-supplier-draft (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Set the supplier draft business relationship to Spend Authorized and tax organization type to Corporation.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="list">
{
  "title": "Supplier draft revision 2",
  "patternId": "multiRecordWidget",
  "description": "Supplier draft details with current revision and validation status",
  "properties": {
    "subtitle": "Draft updated. Any previous approval is invalid. No supplier has been created.",
    "selectMode": "none",
    "cols": ["Field", "Value"],
    "rows": [
      {
        "cells": ["Supplier", "XDX Review Only 20260923 A"]
      },
      {
        "cells": ["BusinessRelationship", "Spend Authorized"]
      },
      {
        "cells": ["TaxOrganizationType", "Corporation"]
      }
    ]
  }
}
</oraInfoDisplay>
~~~

## Step 3: review-exact-payload

**Status:** passed
**Type:** chat
**Intent:** Review the supplier draft.
**Context Step IDs:** start-supplier-draft, complete-required-fields (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Review the supplier draft.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="list">
{
  "title": "Supplier draft revision 2",
  "patternId": "multiRecordWidget",
  "description": "Exact required supplier payload fields for review",
  "properties": {
    "subtitle": "Review these exact three fields. To approve this draft without creating it, enter: Approve supplier revision 2.",
    "selectMode": "none",
    "cols": ["Field", "Value"],
    "rows": [
      {
        "cells": ["Supplier", "XDX Review Only 20260923 A"]
      },
      {
        "cells": ["BusinessRelationship", "Spend Authorized"]
      },
      {
        "cells": ["TaxOrganizationType", "Corporation"]
      }
    ]
  }
}
</oraInfoDisplay>
~~~

## Step 4: approve-reviewed-revision

**Status:** passed
**Type:** chat
**Intent:** Approve supplier revision 2
**Context Step IDs:** start-supplier-draft, complete-required-fields, review-exact-payload (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Approve supplier revision 2",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="list">
{
  "title": "Supplier draft revision 2",
  "patternId": "multiRecordWidget",
  "description": "Exact required supplier payload fields and values",
  "properties": {
    "subtitle": "Supplier draft revision 2 is approved. No supplier has been created. To create this exact approved payload, enter: Create supplier revision 2.",
    "selectMode": "none",
    "cols": ["Field", "Value"],
    "rows": [
      {
        "cells": ["Supplier", "XDX Review Only 20260923 A"]
      },
      {
        "cells": ["BusinessRelationship", "Spend Authorized"]
      },
      {
        "cells": ["TaxOrganizationType", "Corporation"]
      }
    ]
  }
}
</oraInfoDisplay>
~~~

## Step 5: edit-approved-draft

**Status:** passed
**Type:** chat
**Intent:** Change the supplier draft name to XDX Review Only 20260923 A Revised.
**Context Step IDs:** start-supplier-draft, complete-required-fields, review-exact-payload, approve-reviewed-revision (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Change the supplier draft name to XDX Review Only 20260923 A Revised.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="list">
{
  "title": "Supplier draft revision 3",
  "patternId": "multiRecordWidget",
  "description": "Current supplier draft details",
  "properties": {
    "subtitle": "Draft updated. Any previous approval is invalid. No supplier has been created.",
    "selectMode": "none",
    "cols": ["Field", "Value"],
    "rows": [
      {
        "cells": ["Supplier", "XDX Review Only 20260923 A Revised"]
      },
      {
        "cells": ["BusinessRelationship", "Spend Authorized"]
      },
      {
        "cells": ["TaxOrganizationType", "Corporation"]
      }
    ]
  }
}
</oraInfoDisplay>
~~~

## Step 6: review-revised-payload

**Status:** passed
**Type:** chat
**Intent:** Review the supplier draft again.
**Context Step IDs:** start-supplier-draft, complete-required-fields, review-exact-payload, approve-reviewed-revision, edit-approved-draft (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Review the supplier draft again.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="list">
{
  "title": "Supplier draft revision 3",
  "patternId": "multiRecordWidget",
  "description": "Exact required supplier payload fields for review",
  "properties": {
    "subtitle": "Review these exact three fields. To approve this draft without creating it, enter: Approve supplier revision 3.",
    "cols": ["Field", "Value"],
    "rows": [
      {
        "cells": ["Supplier", "XDX Review Only 20260923 A Revised"]
      },
      {
        "cells": ["BusinessRelationship", "Spend Authorized"]
      },
      {
        "cells": ["TaxOrganizationType", "Corporation"]
      }
    ],
    "selectMode": "none"
  }
}
</oraInfoDisplay>
~~~

## Verification Summary

| Verification | Status | Result |
| --- | --- | --- |
| Node order and counts | PASSED | 12/12 passed |
| Path assertions | PASSED | 1494/1494 passed |
| Node assertions | PASSED | 19/19 passed |
| Semantic evaluation | PASSED | 13/13 passed |
| Workflow run checks | PASSED | 8/8 passed |
| Output checks | PASSED | 6/6 passed |

## Node Order and Count

### Required Relative Order

Other nodes may execute between the listed nodes.

| Step | Status | Assertion | Required Relative Order | Observed or Failure |
| --- | --- | --- | --- | --- |
| start-supplier-draft | PASS | Reduce then persist then display | XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE |
| complete-required-fields | PASS | Reduce then persist then display | XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE |
| review-exact-payload | PASS | Reduce then persist then display | XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE |
| approve-reviewed-revision | PASS | Reduce then persist then display | XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE |
| edit-approved-draft | PASS | Reduce then persist then display | XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE |
| review-revised-payload | PASS | Reduce then persist then display | XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SUPPLIER_DRAFT -> XDX_SAVE_SUPPLIER_DRAFT -> XDX_SUPPLIER_DRAFT_RESPONSE |

### Node Count Checks

| Step | Assertion | Node Code | Expected | Observed | Status |
| --- | --- | --- | --- | --- | --- |
| start-supplier-draft | Draft state saved once | XDX_SAVE_SUPPLIER_DRAFT | exactly 1 | 1 | PASS |
| complete-required-fields | Draft state saved once | XDX_SAVE_SUPPLIER_DRAFT | exactly 1 | 1 | PASS |
| review-exact-payload | Draft state saved once | XDX_SAVE_SUPPLIER_DRAFT | exactly 1 | 1 | PASS |
| approve-reviewed-revision | Draft state saved once | XDX_SAVE_SUPPLIER_DRAFT | exactly 1 | 1 | PASS |
| edit-approved-draft | Draft state saved once | XDX_SAVE_SUPPLIER_DRAFT | exactly 1 | 1 | PASS |
| review-revised-payload | Draft state saved once | XDX_SAVE_SUPPLIER_DRAFT | exactly 1 | 1 | PASS |

## Path Assertions

| Step | Status | Assertion | Requirement | Node Code | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| start-supplier-draft | PASS | XDX_ROUTE_APP_STAGE executes | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| start-supplier-draft | PASS | XDX_EXTRACT_SEARCH executes | Must execute | XDX_EXTRACT_SEARCH | Executed |
| start-supplier-draft | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| start-supplier-draft | PASS | XDX_ROUTE_REQUEST_INTENT executes | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| start-supplier-draft | PASS | XDX_REDUCE_SUPPLIER_DRAFT executes | Must execute | XDX_REDUCE_SUPPLIER_DRAFT | Executed |
| start-supplier-draft | PASS | XDX_SAVE_SUPPLIER_DRAFT executes | Must execute | XDX_SAVE_SUPPLIER_DRAFT | Executed |
| start-supplier-draft | PASS | XDX_SUPPLIER_DRAFT_RESPONSE executes | Must execute | XDX_SUPPLIER_DRAFT_RESPONSE | Executed |
| start-supplier-draft | PASS | XDX_INITIAL_DISPLAY remains inactive | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| start-supplier-draft | PASS | XDX_PREPARE_SEARCH remains inactive | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| start-supplier-draft | PASS | XDX_VALID_SEARCH remains inactive | Must not execute | XDX_VALID_SEARCH | Not executed |
| start-supplier-draft | PASS | XDX_REQUEST_SEARCH_NAME remains inactive | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| start-supplier-draft | PASS | XDX_FETCH_SUPPLIERS remains inactive | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| start-supplier-draft | PASS | XDX_QUERY_RESPONSE remains inactive | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| start-supplier-draft | PASS | XDX_ROUTE_READ_RESOURCE remains inactive | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| start-supplier-draft | PASS | XDX_RESOLVE_SUPPLIER remains inactive | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| start-supplier-draft | PASS | XDX_VALID_PARENT remains inactive | Must not execute | XDX_VALID_PARENT | Not executed |
| start-supplier-draft | PASS | XDX_REQUEST_EXACT_PARENT remains inactive | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| start-supplier-draft | PASS | XDX_FETCH_ADDRESSES remains inactive | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| start-supplier-draft | PASS | XDX_ADDRESS_RESPONSE remains inactive | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| start-supplier-draft | PASS | XDX_ROUTE_CHILD_READ remains inactive | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| start-supplier-draft | PASS | XDX_FETCH_SITES remains inactive | Must not execute | XDX_FETCH_SITES | Not executed |
| start-supplier-draft | PASS | XDX_SITE_RESPONSE remains inactive | Must not execute | XDX_SITE_RESPONSE | Not executed |
| start-supplier-draft | PASS | XDX_FETCH_CONTACTS remains inactive | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| start-supplier-draft | PASS | XDX_CONTACT_RESPONSE remains inactive | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| start-supplier-draft | PASS | XDX_PREPARE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| start-supplier-draft | PASS | XDX_VALID_SUPPLIER_CREATE remains inactive | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| start-supplier-draft | PASS | XDX_CHECK_SUPPLIER_DUPLICATE remains inactive | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| start-supplier-draft | PASS | XDX_DECIDE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| start-supplier-draft | PASS | XDX_CAN_POST_SUPPLIER remains inactive | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| start-supplier-draft | PASS | XDX_SAVE_SUPPLIER_ATTEMPT remains inactive | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| start-supplier-draft | PASS | XDX_SAVE_SUPPLIER_RECONCILIATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| start-supplier-draft | PASS | XDX_CREATE_SUPPLIER remains inactive | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| start-supplier-draft | PASS | XDX_VERIFY_SUPPLIER remains inactive | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| start-supplier-draft | PASS | XDX_CONFIRM_SUPPLIER_CREATE remains inactive | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| start-supplier-draft | PASS | XDX_SAVE_SUPPLIER_CONFIRMATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| start-supplier-draft | PASS | XDX_SUPPLIER_CREATE_BLOCKED remains inactive | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| start-supplier-draft | PASS | XDX_SUPPLIER_CREATE_DECISION remains inactive | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| start-supplier-draft | PASS | XDX_SUPPLIER_CREATE_RESULT remains inactive | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| start-supplier-draft | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| start-supplier-draft | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| start-supplier-draft | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| start-supplier-draft | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| start-supplier-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| start-supplier-draft | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| start-supplier-draft | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| start-supplier-draft | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| start-supplier-draft | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| start-supplier-draft | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| start-supplier-draft | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| start-supplier-draft | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| start-supplier-draft | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| start-supplier-draft | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| start-supplier-draft | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| start-supplier-draft | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| start-supplier-draft | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| start-supplier-draft | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| start-supplier-draft | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| start-supplier-draft | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| start-supplier-draft | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| start-supplier-draft | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| start-supplier-draft | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| start-supplier-draft | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| start-supplier-draft | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| start-supplier-draft | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| start-supplier-draft | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| start-supplier-draft | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| complete-required-fields | PASS | XDX_ROUTE_APP_STAGE executes | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| complete-required-fields | PASS | XDX_EXTRACT_SEARCH executes | Must execute | XDX_EXTRACT_SEARCH | Executed |
| complete-required-fields | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| complete-required-fields | PASS | XDX_ROUTE_REQUEST_INTENT executes | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| complete-required-fields | PASS | XDX_REDUCE_SUPPLIER_DRAFT executes | Must execute | XDX_REDUCE_SUPPLIER_DRAFT | Executed |
| complete-required-fields | PASS | XDX_SAVE_SUPPLIER_DRAFT executes | Must execute | XDX_SAVE_SUPPLIER_DRAFT | Executed |
| complete-required-fields | PASS | XDX_SUPPLIER_DRAFT_RESPONSE executes | Must execute | XDX_SUPPLIER_DRAFT_RESPONSE | Executed |
| complete-required-fields | PASS | XDX_INITIAL_DISPLAY remains inactive | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| complete-required-fields | PASS | XDX_PREPARE_SEARCH remains inactive | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| complete-required-fields | PASS | XDX_VALID_SEARCH remains inactive | Must not execute | XDX_VALID_SEARCH | Not executed |
| complete-required-fields | PASS | XDX_REQUEST_SEARCH_NAME remains inactive | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| complete-required-fields | PASS | XDX_FETCH_SUPPLIERS remains inactive | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| complete-required-fields | PASS | XDX_QUERY_RESPONSE remains inactive | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| complete-required-fields | PASS | XDX_ROUTE_READ_RESOURCE remains inactive | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| complete-required-fields | PASS | XDX_RESOLVE_SUPPLIER remains inactive | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| complete-required-fields | PASS | XDX_VALID_PARENT remains inactive | Must not execute | XDX_VALID_PARENT | Not executed |
| complete-required-fields | PASS | XDX_REQUEST_EXACT_PARENT remains inactive | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| complete-required-fields | PASS | XDX_FETCH_ADDRESSES remains inactive | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| complete-required-fields | PASS | XDX_ADDRESS_RESPONSE remains inactive | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| complete-required-fields | PASS | XDX_ROUTE_CHILD_READ remains inactive | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| complete-required-fields | PASS | XDX_FETCH_SITES remains inactive | Must not execute | XDX_FETCH_SITES | Not executed |
| complete-required-fields | PASS | XDX_SITE_RESPONSE remains inactive | Must not execute | XDX_SITE_RESPONSE | Not executed |
| complete-required-fields | PASS | XDX_FETCH_CONTACTS remains inactive | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| complete-required-fields | PASS | XDX_CONTACT_RESPONSE remains inactive | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| complete-required-fields | PASS | XDX_PREPARE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| complete-required-fields | PASS | XDX_VALID_SUPPLIER_CREATE remains inactive | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| complete-required-fields | PASS | XDX_CHECK_SUPPLIER_DUPLICATE remains inactive | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| complete-required-fields | PASS | XDX_DECIDE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| complete-required-fields | PASS | XDX_CAN_POST_SUPPLIER remains inactive | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| complete-required-fields | PASS | XDX_SAVE_SUPPLIER_ATTEMPT remains inactive | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| complete-required-fields | PASS | XDX_SAVE_SUPPLIER_RECONCILIATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| complete-required-fields | PASS | XDX_CREATE_SUPPLIER remains inactive | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| complete-required-fields | PASS | XDX_VERIFY_SUPPLIER remains inactive | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| complete-required-fields | PASS | XDX_CONFIRM_SUPPLIER_CREATE remains inactive | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| complete-required-fields | PASS | XDX_SAVE_SUPPLIER_CONFIRMATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| complete-required-fields | PASS | XDX_SUPPLIER_CREATE_BLOCKED remains inactive | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| complete-required-fields | PASS | XDX_SUPPLIER_CREATE_DECISION remains inactive | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| complete-required-fields | PASS | XDX_SUPPLIER_CREATE_RESULT remains inactive | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| complete-required-fields | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| complete-required-fields | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| complete-required-fields | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| complete-required-fields | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| complete-required-fields | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| complete-required-fields | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| complete-required-fields | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| complete-required-fields | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| complete-required-fields | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| complete-required-fields | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| complete-required-fields | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| complete-required-fields | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| complete-required-fields | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| complete-required-fields | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| complete-required-fields | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| complete-required-fields | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| complete-required-fields | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| complete-required-fields | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| complete-required-fields | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| complete-required-fields | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| complete-required-fields | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| complete-required-fields | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| complete-required-fields | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| complete-required-fields | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| complete-required-fields | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| complete-required-fields | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| complete-required-fields | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| complete-required-fields | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| review-exact-payload | PASS | XDX_ROUTE_APP_STAGE executes | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| review-exact-payload | PASS | XDX_EXTRACT_SEARCH executes | Must execute | XDX_EXTRACT_SEARCH | Executed |
| review-exact-payload | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| review-exact-payload | PASS | XDX_ROUTE_REQUEST_INTENT executes | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| review-exact-payload | PASS | XDX_REDUCE_SUPPLIER_DRAFT executes | Must execute | XDX_REDUCE_SUPPLIER_DRAFT | Executed |
| review-exact-payload | PASS | XDX_SAVE_SUPPLIER_DRAFT executes | Must execute | XDX_SAVE_SUPPLIER_DRAFT | Executed |
| review-exact-payload | PASS | XDX_SUPPLIER_DRAFT_RESPONSE executes | Must execute | XDX_SUPPLIER_DRAFT_RESPONSE | Executed |
| review-exact-payload | PASS | XDX_INITIAL_DISPLAY remains inactive | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| review-exact-payload | PASS | XDX_PREPARE_SEARCH remains inactive | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| review-exact-payload | PASS | XDX_VALID_SEARCH remains inactive | Must not execute | XDX_VALID_SEARCH | Not executed |
| review-exact-payload | PASS | XDX_REQUEST_SEARCH_NAME remains inactive | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| review-exact-payload | PASS | XDX_FETCH_SUPPLIERS remains inactive | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| review-exact-payload | PASS | XDX_QUERY_RESPONSE remains inactive | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| review-exact-payload | PASS | XDX_ROUTE_READ_RESOURCE remains inactive | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| review-exact-payload | PASS | XDX_RESOLVE_SUPPLIER remains inactive | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| review-exact-payload | PASS | XDX_VALID_PARENT remains inactive | Must not execute | XDX_VALID_PARENT | Not executed |
| review-exact-payload | PASS | XDX_REQUEST_EXACT_PARENT remains inactive | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| review-exact-payload | PASS | XDX_FETCH_ADDRESSES remains inactive | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| review-exact-payload | PASS | XDX_ADDRESS_RESPONSE remains inactive | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| review-exact-payload | PASS | XDX_ROUTE_CHILD_READ remains inactive | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| review-exact-payload | PASS | XDX_FETCH_SITES remains inactive | Must not execute | XDX_FETCH_SITES | Not executed |
| review-exact-payload | PASS | XDX_SITE_RESPONSE remains inactive | Must not execute | XDX_SITE_RESPONSE | Not executed |
| review-exact-payload | PASS | XDX_FETCH_CONTACTS remains inactive | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| review-exact-payload | PASS | XDX_CONTACT_RESPONSE remains inactive | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| review-exact-payload | PASS | XDX_PREPARE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| review-exact-payload | PASS | XDX_VALID_SUPPLIER_CREATE remains inactive | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| review-exact-payload | PASS | XDX_CHECK_SUPPLIER_DUPLICATE remains inactive | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| review-exact-payload | PASS | XDX_DECIDE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| review-exact-payload | PASS | XDX_CAN_POST_SUPPLIER remains inactive | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| review-exact-payload | PASS | XDX_SAVE_SUPPLIER_ATTEMPT remains inactive | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| review-exact-payload | PASS | XDX_SAVE_SUPPLIER_RECONCILIATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| review-exact-payload | PASS | XDX_CREATE_SUPPLIER remains inactive | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| review-exact-payload | PASS | XDX_VERIFY_SUPPLIER remains inactive | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| review-exact-payload | PASS | XDX_CONFIRM_SUPPLIER_CREATE remains inactive | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| review-exact-payload | PASS | XDX_SAVE_SUPPLIER_CONFIRMATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| review-exact-payload | PASS | XDX_SUPPLIER_CREATE_BLOCKED remains inactive | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| review-exact-payload | PASS | XDX_SUPPLIER_CREATE_DECISION remains inactive | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| review-exact-payload | PASS | XDX_SUPPLIER_CREATE_RESULT remains inactive | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| review-exact-payload | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| review-exact-payload | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| review-exact-payload | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| review-exact-payload | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| review-exact-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| review-exact-payload | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| review-exact-payload | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| review-exact-payload | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| review-exact-payload | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| review-exact-payload | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| review-exact-payload | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| review-exact-payload | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| review-exact-payload | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| review-exact-payload | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| review-exact-payload | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| review-exact-payload | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| review-exact-payload | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| review-exact-payload | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| review-exact-payload | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| review-exact-payload | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| review-exact-payload | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| review-exact-payload | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| review-exact-payload | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| review-exact-payload | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| review-exact-payload | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| review-exact-payload | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| review-exact-payload | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| review-exact-payload | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | XDX_ROUTE_APP_STAGE executes | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| approve-reviewed-revision | PASS | XDX_EXTRACT_SEARCH executes | Must execute | XDX_EXTRACT_SEARCH | Executed |
| approve-reviewed-revision | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| approve-reviewed-revision | PASS | XDX_ROUTE_REQUEST_INTENT executes | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| approve-reviewed-revision | PASS | XDX_REDUCE_SUPPLIER_DRAFT executes | Must execute | XDX_REDUCE_SUPPLIER_DRAFT | Executed |
| approve-reviewed-revision | PASS | XDX_SAVE_SUPPLIER_DRAFT executes | Must execute | XDX_SAVE_SUPPLIER_DRAFT | Executed |
| approve-reviewed-revision | PASS | XDX_SUPPLIER_DRAFT_RESPONSE executes | Must execute | XDX_SUPPLIER_DRAFT_RESPONSE | Executed |
| approve-reviewed-revision | PASS | XDX_INITIAL_DISPLAY remains inactive | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| approve-reviewed-revision | PASS | XDX_PREPARE_SEARCH remains inactive | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| approve-reviewed-revision | PASS | XDX_VALID_SEARCH remains inactive | Must not execute | XDX_VALID_SEARCH | Not executed |
| approve-reviewed-revision | PASS | XDX_REQUEST_SEARCH_NAME remains inactive | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| approve-reviewed-revision | PASS | XDX_FETCH_SUPPLIERS remains inactive | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| approve-reviewed-revision | PASS | XDX_QUERY_RESPONSE remains inactive | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | XDX_ROUTE_READ_RESOURCE remains inactive | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| approve-reviewed-revision | PASS | XDX_RESOLVE_SUPPLIER remains inactive | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| approve-reviewed-revision | PASS | XDX_VALID_PARENT remains inactive | Must not execute | XDX_VALID_PARENT | Not executed |
| approve-reviewed-revision | PASS | XDX_REQUEST_EXACT_PARENT remains inactive | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| approve-reviewed-revision | PASS | XDX_FETCH_ADDRESSES remains inactive | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| approve-reviewed-revision | PASS | XDX_ADDRESS_RESPONSE remains inactive | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | XDX_ROUTE_CHILD_READ remains inactive | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| approve-reviewed-revision | PASS | XDX_FETCH_SITES remains inactive | Must not execute | XDX_FETCH_SITES | Not executed |
| approve-reviewed-revision | PASS | XDX_SITE_RESPONSE remains inactive | Must not execute | XDX_SITE_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | XDX_FETCH_CONTACTS remains inactive | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| approve-reviewed-revision | PASS | XDX_CONTACT_RESPONSE remains inactive | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | XDX_PREPARE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| approve-reviewed-revision | PASS | XDX_VALID_SUPPLIER_CREATE remains inactive | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| approve-reviewed-revision | PASS | XDX_CHECK_SUPPLIER_DUPLICATE remains inactive | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| approve-reviewed-revision | PASS | XDX_DECIDE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| approve-reviewed-revision | PASS | XDX_CAN_POST_SUPPLIER remains inactive | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| approve-reviewed-revision | PASS | XDX_SAVE_SUPPLIER_ATTEMPT remains inactive | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| approve-reviewed-revision | PASS | XDX_SAVE_SUPPLIER_RECONCILIATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| approve-reviewed-revision | PASS | XDX_CREATE_SUPPLIER remains inactive | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| approve-reviewed-revision | PASS | XDX_VERIFY_SUPPLIER remains inactive | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| approve-reviewed-revision | PASS | XDX_CONFIRM_SUPPLIER_CREATE remains inactive | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| approve-reviewed-revision | PASS | XDX_SAVE_SUPPLIER_CONFIRMATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| approve-reviewed-revision | PASS | XDX_SUPPLIER_CREATE_BLOCKED remains inactive | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | XDX_SUPPLIER_CREATE_DECISION remains inactive | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| approve-reviewed-revision | PASS | XDX_SUPPLIER_CREATE_RESULT remains inactive | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| approve-reviewed-revision | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| approve-reviewed-revision | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| approve-reviewed-revision | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| approve-reviewed-revision | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-reviewed-revision | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| approve-reviewed-revision | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| approve-reviewed-revision | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| approve-reviewed-revision | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| approve-reviewed-revision | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| approve-reviewed-revision | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| approve-reviewed-revision | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| approve-reviewed-revision | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| approve-reviewed-revision | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| approve-reviewed-revision | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| approve-reviewed-revision | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| approve-reviewed-revision | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| approve-reviewed-revision | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| approve-reviewed-revision | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| approve-reviewed-revision | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| approve-reviewed-revision | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| approve-reviewed-revision | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| approve-reviewed-revision | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| approve-reviewed-revision | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| approve-reviewed-revision | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| approve-reviewed-revision | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| approve-reviewed-revision | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| approve-reviewed-revision | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| edit-approved-draft | PASS | XDX_ROUTE_APP_STAGE executes | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| edit-approved-draft | PASS | XDX_EXTRACT_SEARCH executes | Must execute | XDX_EXTRACT_SEARCH | Executed |
| edit-approved-draft | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| edit-approved-draft | PASS | XDX_ROUTE_REQUEST_INTENT executes | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| edit-approved-draft | PASS | XDX_REDUCE_SUPPLIER_DRAFT executes | Must execute | XDX_REDUCE_SUPPLIER_DRAFT | Executed |
| edit-approved-draft | PASS | XDX_SAVE_SUPPLIER_DRAFT executes | Must execute | XDX_SAVE_SUPPLIER_DRAFT | Executed |
| edit-approved-draft | PASS | XDX_SUPPLIER_DRAFT_RESPONSE executes | Must execute | XDX_SUPPLIER_DRAFT_RESPONSE | Executed |
| edit-approved-draft | PASS | XDX_INITIAL_DISPLAY remains inactive | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| edit-approved-draft | PASS | XDX_PREPARE_SEARCH remains inactive | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| edit-approved-draft | PASS | XDX_VALID_SEARCH remains inactive | Must not execute | XDX_VALID_SEARCH | Not executed |
| edit-approved-draft | PASS | XDX_REQUEST_SEARCH_NAME remains inactive | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| edit-approved-draft | PASS | XDX_FETCH_SUPPLIERS remains inactive | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| edit-approved-draft | PASS | XDX_QUERY_RESPONSE remains inactive | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| edit-approved-draft | PASS | XDX_ROUTE_READ_RESOURCE remains inactive | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| edit-approved-draft | PASS | XDX_RESOLVE_SUPPLIER remains inactive | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| edit-approved-draft | PASS | XDX_VALID_PARENT remains inactive | Must not execute | XDX_VALID_PARENT | Not executed |
| edit-approved-draft | PASS | XDX_REQUEST_EXACT_PARENT remains inactive | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| edit-approved-draft | PASS | XDX_FETCH_ADDRESSES remains inactive | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| edit-approved-draft | PASS | XDX_ADDRESS_RESPONSE remains inactive | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| edit-approved-draft | PASS | XDX_ROUTE_CHILD_READ remains inactive | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| edit-approved-draft | PASS | XDX_FETCH_SITES remains inactive | Must not execute | XDX_FETCH_SITES | Not executed |
| edit-approved-draft | PASS | XDX_SITE_RESPONSE remains inactive | Must not execute | XDX_SITE_RESPONSE | Not executed |
| edit-approved-draft | PASS | XDX_FETCH_CONTACTS remains inactive | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| edit-approved-draft | PASS | XDX_CONTACT_RESPONSE remains inactive | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| edit-approved-draft | PASS | XDX_PREPARE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| edit-approved-draft | PASS | XDX_VALID_SUPPLIER_CREATE remains inactive | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| edit-approved-draft | PASS | XDX_CHECK_SUPPLIER_DUPLICATE remains inactive | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| edit-approved-draft | PASS | XDX_DECIDE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| edit-approved-draft | PASS | XDX_CAN_POST_SUPPLIER remains inactive | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| edit-approved-draft | PASS | XDX_SAVE_SUPPLIER_ATTEMPT remains inactive | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| edit-approved-draft | PASS | XDX_SAVE_SUPPLIER_RECONCILIATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| edit-approved-draft | PASS | XDX_CREATE_SUPPLIER remains inactive | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| edit-approved-draft | PASS | XDX_VERIFY_SUPPLIER remains inactive | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| edit-approved-draft | PASS | XDX_CONFIRM_SUPPLIER_CREATE remains inactive | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| edit-approved-draft | PASS | XDX_SAVE_SUPPLIER_CONFIRMATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| edit-approved-draft | PASS | XDX_SUPPLIER_CREATE_BLOCKED remains inactive | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| edit-approved-draft | PASS | XDX_SUPPLIER_CREATE_DECISION remains inactive | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| edit-approved-draft | PASS | XDX_SUPPLIER_CREATE_RESULT remains inactive | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| edit-approved-draft | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| edit-approved-draft | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| edit-approved-draft | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| edit-approved-draft | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| edit-approved-draft | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| edit-approved-draft | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| edit-approved-draft | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| edit-approved-draft | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| edit-approved-draft | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| edit-approved-draft | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| edit-approved-draft | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| edit-approved-draft | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| edit-approved-draft | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| edit-approved-draft | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| edit-approved-draft | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| edit-approved-draft | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| edit-approved-draft | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| edit-approved-draft | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| edit-approved-draft | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| edit-approved-draft | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| edit-approved-draft | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| edit-approved-draft | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| edit-approved-draft | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| edit-approved-draft | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| edit-approved-draft | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| edit-approved-draft | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| edit-approved-draft | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| edit-approved-draft | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| review-revised-payload | PASS | XDX_ROUTE_APP_STAGE executes | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| review-revised-payload | PASS | XDX_EXTRACT_SEARCH executes | Must execute | XDX_EXTRACT_SEARCH | Executed |
| review-revised-payload | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| review-revised-payload | PASS | XDX_ROUTE_REQUEST_INTENT executes | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| review-revised-payload | PASS | XDX_REDUCE_SUPPLIER_DRAFT executes | Must execute | XDX_REDUCE_SUPPLIER_DRAFT | Executed |
| review-revised-payload | PASS | XDX_SAVE_SUPPLIER_DRAFT executes | Must execute | XDX_SAVE_SUPPLIER_DRAFT | Executed |
| review-revised-payload | PASS | XDX_SUPPLIER_DRAFT_RESPONSE executes | Must execute | XDX_SUPPLIER_DRAFT_RESPONSE | Executed |
| review-revised-payload | PASS | XDX_INITIAL_DISPLAY remains inactive | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| review-revised-payload | PASS | XDX_PREPARE_SEARCH remains inactive | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| review-revised-payload | PASS | XDX_VALID_SEARCH remains inactive | Must not execute | XDX_VALID_SEARCH | Not executed |
| review-revised-payload | PASS | XDX_REQUEST_SEARCH_NAME remains inactive | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| review-revised-payload | PASS | XDX_FETCH_SUPPLIERS remains inactive | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| review-revised-payload | PASS | XDX_QUERY_RESPONSE remains inactive | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| review-revised-payload | PASS | XDX_ROUTE_READ_RESOURCE remains inactive | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| review-revised-payload | PASS | XDX_RESOLVE_SUPPLIER remains inactive | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| review-revised-payload | PASS | XDX_VALID_PARENT remains inactive | Must not execute | XDX_VALID_PARENT | Not executed |
| review-revised-payload | PASS | XDX_REQUEST_EXACT_PARENT remains inactive | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| review-revised-payload | PASS | XDX_FETCH_ADDRESSES remains inactive | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| review-revised-payload | PASS | XDX_ADDRESS_RESPONSE remains inactive | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| review-revised-payload | PASS | XDX_ROUTE_CHILD_READ remains inactive | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| review-revised-payload | PASS | XDX_FETCH_SITES remains inactive | Must not execute | XDX_FETCH_SITES | Not executed |
| review-revised-payload | PASS | XDX_SITE_RESPONSE remains inactive | Must not execute | XDX_SITE_RESPONSE | Not executed |
| review-revised-payload | PASS | XDX_FETCH_CONTACTS remains inactive | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| review-revised-payload | PASS | XDX_CONTACT_RESPONSE remains inactive | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| review-revised-payload | PASS | XDX_PREPARE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| review-revised-payload | PASS | XDX_VALID_SUPPLIER_CREATE remains inactive | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| review-revised-payload | PASS | XDX_CHECK_SUPPLIER_DUPLICATE remains inactive | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| review-revised-payload | PASS | XDX_DECIDE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| review-revised-payload | PASS | XDX_CAN_POST_SUPPLIER remains inactive | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| review-revised-payload | PASS | XDX_SAVE_SUPPLIER_ATTEMPT remains inactive | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| review-revised-payload | PASS | XDX_SAVE_SUPPLIER_RECONCILIATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| review-revised-payload | PASS | XDX_CREATE_SUPPLIER remains inactive | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| review-revised-payload | PASS | XDX_VERIFY_SUPPLIER remains inactive | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| review-revised-payload | PASS | XDX_CONFIRM_SUPPLIER_CREATE remains inactive | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| review-revised-payload | PASS | XDX_SAVE_SUPPLIER_CONFIRMATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| review-revised-payload | PASS | XDX_SUPPLIER_CREATE_BLOCKED remains inactive | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| review-revised-payload | PASS | XDX_SUPPLIER_CREATE_DECISION remains inactive | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| review-revised-payload | PASS | XDX_SUPPLIER_CREATE_RESULT remains inactive | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| review-revised-payload | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| review-revised-payload | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| review-revised-payload | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| review-revised-payload | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| review-revised-payload | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| review-revised-payload | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| review-revised-payload | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| review-revised-payload | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| review-revised-payload | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| review-revised-payload | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| review-revised-payload | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| review-revised-payload | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| review-revised-payload | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| review-revised-payload | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| review-revised-payload | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| review-revised-payload | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| review-revised-payload | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| review-revised-payload | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| review-revised-payload | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| review-revised-payload | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| review-revised-payload | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| review-revised-payload | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| review-revised-payload | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| review-revised-payload | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| review-revised-payload | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| review-revised-payload | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| review-revised-payload | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| review-revised-payload | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |

## Node Assertions

| Step | Status | Assertion | Node Code | Occurrence | Asserted Value | Operator | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| start-supplier-draft | PASS | Exact supplier name preserved | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/payload/Supplier | equals | "XDX Review Only 20260923 A" | string (26 characters) |
| start-supplier-draft | PASS | Correct draft revision | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/revision | equals | 1 | number |
| start-supplier-draft | PASS | Correct approval revision | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/approvedRevision | equals | 0 | number |
| start-supplier-draft | PASS | Initial name extracted into draft patch | XDX_EXTRACT_SEARCH | last | output/draftPatch/Supplier | equals | "XDX Review Only 20260923 A" | string (26 characters) |
| complete-required-fields | PASS | Exact supplier name preserved | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/payload/Supplier | equals | "XDX Review Only 20260923 A" | string (26 characters) |
| complete-required-fields | PASS | Correct draft revision | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/revision | equals | 2 | number |
| complete-required-fields | PASS | Correct approval revision | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/approvedRevision | equals | 0 | number |
| review-exact-payload | PASS | Exact supplier name preserved | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/payload/Supplier | equals | "XDX Review Only 20260923 A" | string (26 characters) |
| review-exact-payload | PASS | Correct draft revision | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/revision | equals | 2 | number |
| review-exact-payload | PASS | Correct approval revision | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/approvedRevision | equals | 0 | number |
| approve-reviewed-revision | PASS | Exact supplier name preserved | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/payload/Supplier | equals | "XDX Review Only 20260923 A" | string (26 characters) |
| approve-reviewed-revision | PASS | Correct draft revision | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/revision | equals | 2 | number |
| approve-reviewed-revision | PASS | Correct approval revision | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/approvedRevision | equals | 2 | number |
| edit-approved-draft | PASS | Exact supplier name preserved | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/payload/Supplier | equals | "XDX Review Only 20260923 A Revised" | string (34 characters) |
| edit-approved-draft | PASS | Correct draft revision | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/revision | equals | 3 | number |
| edit-approved-draft | PASS | Correct approval revision | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/approvedRevision | equals | 0 | number |
| review-revised-payload | PASS | Exact supplier name preserved | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/payload/Supplier | equals | "XDX Review Only 20260923 A Revised" | string (34 characters) |
| review-revised-payload | PASS | Correct draft revision | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/revision | equals | 3 | number |
| review-revised-payload | PASS | Correct approval revision | XDX_REDUCE_SUPPLIER_DRAFT | last | output/result/state/approvedRevision | equals | 0 | number |

## Semantic Evaluation

| Scope | Status | Score | Summary |
| --- | --- | --- | --- |
| start-supplier-draft | passed | 5/5 | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| complete-required-fields | passed | 5/5 | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| review-exact-payload | passed | 5/5 | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| approve-reviewed-revision | passed | 5/5 | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| edit-approved-draft | passed | 5/5 | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| review-revised-payload | passed | 5/5 | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| Conversation | passed | 5/5 | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |

### Criterion Results

| Scope | Status | Assertion | Criterion | Notes |
| --- | --- | --- | --- | --- |
| start-supplier-draft | PASS | Exact draft values and status | The table agrees with the deterministic reducer for all three fields, revision, errors and approval status. Missing required fields are not invented. | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| start-supplier-draft | PASS | Clear no-write review | No supplier creation is claimed. When review is valid the exact approval phrase names the current revision; edited drafts invalidate previous approval. | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| complete-required-fields | PASS | Exact draft values and status | The table agrees with the deterministic reducer for all three fields, revision, errors and approval status. Missing required fields are not invented. | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| complete-required-fields | PASS | Clear no-write review | No supplier creation is claimed. When review is valid the exact approval phrase names the current revision; edited drafts invalidate previous approval. | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| review-exact-payload | PASS | Exact draft values and status | The table agrees with the deterministic reducer for all three fields, revision, errors and approval status. Missing required fields are not invented. | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| review-exact-payload | PASS | Clear no-write review | No supplier creation is claimed. When review is valid the exact approval phrase names the current revision; edited drafts invalidate previous approval. | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| approve-reviewed-revision | PASS | Exact draft values and status | The table agrees with the deterministic reducer for all three fields, revision, errors and approval status. Missing required fields are not invented. | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| approve-reviewed-revision | PASS | Clear no-write review | No supplier creation is claimed. When review is valid the exact approval phrase names the current revision; edited drafts invalidate previous approval. | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| edit-approved-draft | PASS | Exact draft values and status | The table agrees with the deterministic reducer for all three fields, revision, errors and approval status. Missing required fields are not invented. | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| edit-approved-draft | PASS | Clear no-write review | No supplier creation is claimed. When review is valid the exact approval phrase names the current revision; edited drafts invalidate previous approval. | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| review-revised-payload | PASS | Exact draft values and status | The table agrees with the deterministic reducer for all three fields, revision, errors and approval status. Missing required fields are not invented. | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| review-revised-payload | PASS | Clear no-write review | No supplier creation is claimed. When review is valid the exact approval phrase names the current revision; edited drafts invalidate previous approval. | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |
| Conversation | PASS | Persisted state and approval continuity | Later messages do not repeat all fields. The same draft is preserved, only explicitly edited values change, review binds the exact payload, and edit clears prior approval. No history reconstruction may replace missing deterministic state. | Six fresh outputs show missing required fields honestly at revision1; field-only completion preserves the supplier name and creates revision2. Exact review and approval retain all three fields and no-write status. Name edit alone produces revision3 and clears approval; renewed review uses revision3. Current deterministic name/revision/approval checks and write exclusions all pass. |

## Workflow Run Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| start-supplier-draft | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| complete-required-fields | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| review-exact-payload | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| approve-reviewed-revision | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| edit-approved-draft | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| review-revised-payload | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| Conversation | PASS | conversationStepOrder | conversationStepOrder | start-supplier-draft -> complete-required-fields -> review-exact-payload -> approve-reviewed-revision -> edit-approved-draft -> review-revised-payload | Verified |
| Conversation | PASS | conversationIdReuse | conversationIdReuse | Every executed step uses one conversation ID. | Verified |

## Output Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| start-supplier-draft | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| complete-required-fields | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| review-exact-payload | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| approve-reviewed-revision | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| edit-approved-draft | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| review-revised-payload | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |

## Runtime Metrics

Workflow time: 27485 ms (sum of node times)
Test run time: 35990 ms (includes CLI overhead)
Token usage: observed from runtime events

Aggregate Token Usage

| Input Tokens | Output Tokens | Total Tokens | Model |
| --- | --- | --- | --- |
| 62655 | 4447 | 67102 | oci-agent/openai.gpt-4.1-mini-2025-04-14 |

| Node | Input Tokens | Output Tokens | Total Tokens | Model | Source |
| --- | --- | --- | --- | --- | --- |
| approve-reviewed-revision:XDX_EXTRACT_SEARCH | 4932 | 502 | 5434 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| approve-reviewed-revision:XDX_SUPPLIER_DRAFT_RESPONSE | 5684 | 235 | 5919 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| complete-required-fields:XDX_EXTRACT_SEARCH | 4498 | 516 | 5014 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| complete-required-fields:XDX_SUPPLIER_DRAFT_RESPONSE | 5580 | 223 | 5803 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| edit-approved-draft:XDX_EXTRACT_SEARCH | 5168 | 512 | 5680 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| edit-approved-draft:XDX_SUPPLIER_DRAFT_RESPONSE | 5582 | 219 | 5801 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| review-exact-payload:XDX_EXTRACT_SEARCH | 4711 | 511 | 5222 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| review-exact-payload:XDX_SUPPLIER_DRAFT_RESPONSE | 5634 | 229 | 5863 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| review-revised-payload:XDX_EXTRACT_SEARCH | 5378 | 512 | 5890 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| review-revised-payload:XDX_SUPPLIER_DRAFT_RESPONSE | 5637 | 230 | 5867 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| start-supplier-draft:XDX_EXTRACT_SEARCH | 4249 | 511 | 4760 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| start-supplier-draft:XDX_SUPPLIER_DRAFT_RESPONSE | 5602 | 247 | 5849 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |


AI Units: computed
Total Token Units: 12
Total AI Units: 60

| Node | Input | Output | Token Units | AI Units | Model Type | Action Type |
| --- | --- | --- | --- | --- | --- | --- |
| approve-reviewed-revision:XDX_EXTRACT_SEARCH | 4932 | 502 | 1 | 5 | premium | general |
| approve-reviewed-revision:XDX_SUPPLIER_DRAFT_RESPONSE | 5684 | 235 | 1 | 5 | premium | general |
| complete-required-fields:XDX_EXTRACT_SEARCH | 4498 | 516 | 1 | 5 | premium | general |
| complete-required-fields:XDX_SUPPLIER_DRAFT_RESPONSE | 5580 | 223 | 1 | 5 | premium | general |
| edit-approved-draft:XDX_EXTRACT_SEARCH | 5168 | 512 | 1 | 5 | premium | general |
| edit-approved-draft:XDX_SUPPLIER_DRAFT_RESPONSE | 5582 | 219 | 1 | 5 | premium | general |
| review-exact-payload:XDX_EXTRACT_SEARCH | 4711 | 511 | 1 | 5 | premium | general |
| review-exact-payload:XDX_SUPPLIER_DRAFT_RESPONSE | 5634 | 229 | 1 | 5 | premium | general |
| review-revised-payload:XDX_EXTRACT_SEARCH | 5378 | 512 | 1 | 5 | premium | general |
| review-revised-payload:XDX_SUPPLIER_DRAFT_RESPONSE | 5637 | 230 | 1 | 5 | premium | general |
| start-supplier-draft:XDX_EXTRACT_SEARCH | 4249 | 511 | 1 | 5 | premium | general |
| start-supplier-draft:XDX_SUPPLIER_DRAFT_RESPONSE | 5602 | 247 | 1 | 5 | premium | general |

| Node | Node Time (ms) | LLM Call Time (ms) | Details |
| --- | --- | --- | --- |
| start-supplier-draft:XDX_EXTRACT_SEARCH | 2885 | 2795 | 1 runtime detail; see JSON report |
| start-supplier-draft:XDX_SUPPLIER_DRAFT_RESPONSE | 1604 | 1507 | 1 runtime detail; see JSON report |
| complete-required-fields:XDX_EXTRACT_SEARCH | 3650 | 3565 | 1 runtime detail; see JSON report |
| complete-required-fields:XDX_SUPPLIER_DRAFT_RESPONSE | 1422 | 1339 | 1 runtime detail; see JSON report |
| review-exact-payload:XDX_EXTRACT_SEARCH | 3196 | 3117 | 1 runtime detail; see JSON report |
| review-exact-payload:XDX_SUPPLIER_DRAFT_RESPONSE | 1480 | 1395 | 1 runtime detail; see JSON report |
| approve-reviewed-revision:XDX_EXTRACT_SEARCH | 2662 | 2563 | 1 runtime detail; see JSON report |
| approve-reviewed-revision:XDX_SUPPLIER_DRAFT_RESPONSE | 1638 | 1591 | 1 runtime detail; see JSON report |
| edit-approved-draft:XDX_EXTRACT_SEARCH | 2884 | 2767 | 1 runtime detail; see JSON report |
| edit-approved-draft:XDX_SUPPLIER_DRAFT_RESPONSE | 1496 | 1421 | 1 runtime detail; see JSON report |
| review-revised-payload:XDX_EXTRACT_SEARCH | 3042 | 2952 | 1 runtime detail; see JSON report |
| review-revised-payload:XDX_SUPPLIER_DRAFT_RESPONSE | 1526 | 1454 | 1 runtime detail; see JSON report |

| Observed Field | Values |
| --- | --- |
| modelName | "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14" |
| inputTokens | 4249; 5602; 4498; 5580; 4711; 5634; 4932; 5684; 5168; 5582; 5378; 5637 |
| outputTokens | 511; 247; 516; 223; 511; 229; 502; 235; 512; 219; 512; 230 |

## Test Data

| Step | Data Source | Evaluation |
| --- | --- | --- |
| start-supplier-draft | File replay | Hybrid |
| complete-required-fields | File replay | Hybrid |
| review-exact-payload | File replay | Hybrid |
| approve-reviewed-revision | File replay | Hybrid |
| edit-approved-draft | File replay | Hybrid |
| review-revised-payload | File replay | Hybrid |

## Workflow Run

### Execution Timeline

| Step | Phase Sequence | Node | Event |
| --- | --- | --- | --- |
| start-supplier-draft | 1 | START | NODE_EXECUTED |
| start-supplier-draft | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| start-supplier-draft | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| start-supplier-draft | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| start-supplier-draft | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| start-supplier-draft | 6 | XDX_REDUCE_SUPPLIER_DRAFT | NODE_EXECUTED |
| start-supplier-draft | 7 | XDX_SAVE_SUPPLIER_DRAFT | NODE_EXECUTED |
| start-supplier-draft | 8 | XDX_SUPPLIER_DRAFT_RESPONSE | NODE_START |
| complete-required-fields | 1 | START | NODE_EXECUTED |
| complete-required-fields | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| complete-required-fields | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| complete-required-fields | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| complete-required-fields | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| complete-required-fields | 6 | XDX_REDUCE_SUPPLIER_DRAFT | NODE_EXECUTED |
| complete-required-fields | 7 | XDX_SAVE_SUPPLIER_DRAFT | NODE_EXECUTED |
| complete-required-fields | 8 | XDX_SUPPLIER_DRAFT_RESPONSE | NODE_START |
| review-exact-payload | 1 | START | NODE_EXECUTED |
| review-exact-payload | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| review-exact-payload | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| review-exact-payload | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| review-exact-payload | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| review-exact-payload | 6 | XDX_REDUCE_SUPPLIER_DRAFT | NODE_EXECUTED |
| review-exact-payload | 7 | XDX_SAVE_SUPPLIER_DRAFT | NODE_EXECUTED |
| review-exact-payload | 8 | XDX_SUPPLIER_DRAFT_RESPONSE | NODE_START |
| approve-reviewed-revision | 1 | START | NODE_EXECUTED |
| approve-reviewed-revision | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| approve-reviewed-revision | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| approve-reviewed-revision | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| approve-reviewed-revision | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| approve-reviewed-revision | 6 | XDX_REDUCE_SUPPLIER_DRAFT | NODE_EXECUTED |
| approve-reviewed-revision | 7 | XDX_SAVE_SUPPLIER_DRAFT | NODE_EXECUTED |
| approve-reviewed-revision | 8 | XDX_SUPPLIER_DRAFT_RESPONSE | NODE_START |
| edit-approved-draft | 1 | START | NODE_EXECUTED |
| edit-approved-draft | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| edit-approved-draft | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| edit-approved-draft | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| edit-approved-draft | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| edit-approved-draft | 6 | XDX_REDUCE_SUPPLIER_DRAFT | NODE_EXECUTED |
| edit-approved-draft | 7 | XDX_SAVE_SUPPLIER_DRAFT | NODE_EXECUTED |
| edit-approved-draft | 8 | XDX_SUPPLIER_DRAFT_RESPONSE | NODE_START |
| review-revised-payload | 1 | START | NODE_EXECUTED |
| review-revised-payload | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| review-revised-payload | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| review-revised-payload | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| review-revised-payload | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| review-revised-payload | 6 | XDX_REDUCE_SUPPLIER_DRAFT | NODE_EXECUTED |
| review-revised-payload | 7 | XDX_SAVE_SUPPLIER_DRAFT | NODE_EXECUTED |
| review-revised-payload | 8 | XDX_SUPPLIER_DRAFT_RESPONSE | NODE_START |

### Other Observed Nodes

| Node | Observed |
| --- | --- |
| START | 6 |
| XDX_EXTRACT_SEARCH | 6 |
| XDX_NORMALIZE_REQUEST | 6 |
| XDX_REDUCE_SUPPLIER_DRAFT | 6 |
| XDX_ROUTE_APP_STAGE | 6 |
| XDX_ROUTE_REQUEST_INTENT | 6 |
| XDX_SUPPLIER_DRAFT_RESPONSE | 6 |

## Report Files

- JSON report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-draft-approval\result.json`
- Markdown report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-draft-approval\result.md`
- Test file: `test/workflows/xdx_supplier_lifecycle_agent/xdx-draft-approval.json`
