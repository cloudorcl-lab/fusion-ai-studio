# Workflow Conversation Test Result: xdx-contact-address-read

**Status:** PASSED
**Workflow:** XDX_SUPPLIER_LIFECYCLE_AGENT (DRAFT v86153667)
**Goal:** Read contact-address associations for an explicitly selected supplier and contact, retaining both selections in the follow-up.
**Data Source:** File replay
**Evaluation:** Deterministic
**Steps:** 2

## Conversation Journey

| # | Step | Type | Intent | Interaction | Outcome | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | request-contact-addresses | chat | Select supplier and contact email explicitly | Use XDX Lifecycle Retry 20260923 A as my selected supplier and xdx-contact-retry-20260923-a@example.invalid as my selected contact. Show up to 2 addresses linked to that contact. | <oraInfoDisplay key="contact-address-list">{"patternId":"multiRecordWidget","title":"Supplier contact addresses","description":"Supplier XDX Lifecycle Retry 20260923 A. Contact xdx-contact-retry-20260923-a@example.invalid. 1 linked address(es).","properties":{"cols":["Address"],"selectMode":"none","rows":[{"cells":["XDX HQ Retry 20260923 A"]}]}}</oraInfoDisplay> | passed |
| 2 | repeat-selected-contact-addresses | chat | Retain supplier and contact selections | Show up to 2 linked addresses for the selected contact and supplier again. | <oraInfoDisplay key="contact-address-list">{"patternId":"multiRecordWidget","title":"Supplier contact addresses","description":"Supplier XDX Lifecycle Retry 20260923 A. Contact xdx-contact-retry-20260923-a@example.invalid. 1 linked address(es).","properties":{"cols":["Address"],"selectMode":"none","rows":[{"cells":["XDX HQ Retry 20260923 A"]}]}}</oraInfoDisplay> | passed |

## Step 1: request-contact-addresses

**Status:** passed
**Type:** chat
**Intent:** Select supplier and contact email explicitly
**Context Step IDs:** None (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Use XDX Lifecycle Retry 20260923 A as my selected supplier and xdx-contact-retry-20260923-a@example.invalid as my selected contact. Show up to 2 addresses linked to that contact.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraUserContext": "",
    "OraAppContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="contact-address-list">{"patternId":"multiRecordWidget","title":"Supplier contact addresses","description":"Supplier XDX Lifecycle Retry 20260923 A. Contact xdx-contact-retry-20260923-a@example.invalid. 1 linked address(es).","properties":{"cols":["Address"],"selectMode":"none","rows":[{"cells":["XDX HQ Retry 20260923 A"]}]}}</oraInfoDisplay>
~~~

## Step 2: repeat-selected-contact-addresses

**Status:** passed
**Type:** chat
**Intent:** Retain supplier and contact selections
**Context Step IDs:** request-contact-addresses (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Show up to 2 linked addresses for the selected contact and supplier again.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraUserContext": "",
    "OraAppContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="contact-address-list">{"patternId":"multiRecordWidget","title":"Supplier contact addresses","description":"Supplier XDX Lifecycle Retry 20260923 A. Contact xdx-contact-retry-20260923-a@example.invalid. 1 linked address(es).","properties":{"cols":["Address"],"selectMode":"none","rows":[{"cells":["XDX HQ Retry 20260923 A"]}]}}</oraInfoDisplay>
~~~

## Verification Summary

| Verification | Status | Result |
| --- | --- | --- |
| Node order and counts | PASSED | 4/4 passed |
| Path assertions | PASSED | 498/498 passed |
| Node assertions | PASSED | 6/6 passed |
| Workflow run checks | PASSED | 4/4 passed |
| Output checks | PASSED | 10/10 passed |

## Node Order and Count

### Required Relative Order

Other nodes may execute between the listed nodes.

| Step | Status | Assertion | Required Relative Order | Observed or Failure |
| --- | --- | --- | --- | --- |
| request-contact-addresses | PASS | Resolve both parents before reading associations | XDX_RESOLVE_SUPPLIER -> XDX_RESOLVE_LINK_READ_CONTACT -> XDX_BIND_LINK_READ_CONTACT -> XDX_FETCH_LINK_READ -> XDX_FORMAT_LINK_READ -> XDX_LINK_READ_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_PREPARE_SEARCH -> XDX_VALID_SEARCH -> XDX_FETCH_SUPPLIERS -> XDX_ROUTE_READ_RESOURCE -> XDX_RESOLVE_SUPPLIER -> XDX_VALID_PARENT -> XDX_ROUTE_CHILD_READ -> XDX_PREPARE_LINK_READ -> XDX_VALID_LINK_READ_SELECTOR -> XDX_RESOLVE_LINK_READ_CONTACT -> XDX_BIND_LINK_READ_CONTACT -> XDX_VALID_LINK_READ_CONTACT -> XDX_FETCH_LINK_READ -> XDX_FORMAT_LINK_READ -> XDX_LINK_READ_RESPONSE |
| repeat-selected-contact-addresses | PASS | Resolve both parents before reading associations | XDX_RESOLVE_SUPPLIER -> XDX_RESOLVE_LINK_READ_CONTACT -> XDX_BIND_LINK_READ_CONTACT -> XDX_FETCH_LINK_READ -> XDX_FORMAT_LINK_READ -> XDX_LINK_READ_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_PREPARE_SEARCH -> XDX_VALID_SEARCH -> XDX_FETCH_SUPPLIERS -> XDX_ROUTE_READ_RESOURCE -> XDX_RESOLVE_SUPPLIER -> XDX_VALID_PARENT -> XDX_ROUTE_CHILD_READ -> XDX_PREPARE_LINK_READ -> XDX_VALID_LINK_READ_SELECTOR -> XDX_RESOLVE_LINK_READ_CONTACT -> XDX_BIND_LINK_READ_CONTACT -> XDX_VALID_LINK_READ_CONTACT -> XDX_FETCH_LINK_READ -> XDX_FORMAT_LINK_READ -> XDX_LINK_READ_RESPONSE |

### Node Count Checks

| Step | Assertion | Node Code | Expected | Observed | Status |
| --- | --- | --- | --- | --- | --- |
| request-contact-addresses | One linked-address query | XDX_FETCH_LINK_READ | exactly 1 | 1 | PASS |
| repeat-selected-contact-addresses | One linked-address query | XDX_FETCH_LINK_READ | exactly 1 | 1 | PASS |

## Path Assertions

| Step | Status | Assertion | Requirement | Node Code | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| request-contact-addresses | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| request-contact-addresses | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| request-contact-addresses | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| request-contact-addresses | PASS | Execute XDX_PREPARE_SEARCH | Must execute | XDX_PREPARE_SEARCH | Executed |
| request-contact-addresses | PASS | Execute XDX_VALID_SEARCH | Must execute | XDX_VALID_SEARCH | Executed |
| request-contact-addresses | PASS | Execute XDX_FETCH_SUPPLIERS | Must execute | XDX_FETCH_SUPPLIERS | Executed |
| request-contact-addresses | PASS | Execute XDX_ROUTE_READ_RESOURCE | Must execute | XDX_ROUTE_READ_RESOURCE | Executed |
| request-contact-addresses | PASS | Execute XDX_RESOLVE_SUPPLIER | Must execute | XDX_RESOLVE_SUPPLIER | Executed |
| request-contact-addresses | PASS | Execute XDX_VALID_PARENT | Must execute | XDX_VALID_PARENT | Executed |
| request-contact-addresses | PASS | Execute XDX_ROUTE_CHILD_READ | Must execute | XDX_ROUTE_CHILD_READ | Executed |
| request-contact-addresses | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| request-contact-addresses | PASS | Execute XDX_PREPARE_LINK_READ | Must execute | XDX_PREPARE_LINK_READ | Executed |
| request-contact-addresses | PASS | Execute XDX_VALID_LINK_READ_SELECTOR | Must execute | XDX_VALID_LINK_READ_SELECTOR | Executed |
| request-contact-addresses | PASS | Execute XDX_RESOLVE_LINK_READ_CONTACT | Must execute | XDX_RESOLVE_LINK_READ_CONTACT | Executed |
| request-contact-addresses | PASS | Execute XDX_BIND_LINK_READ_CONTACT | Must execute | XDX_BIND_LINK_READ_CONTACT | Executed |
| request-contact-addresses | PASS | Execute XDX_VALID_LINK_READ_CONTACT | Must execute | XDX_VALID_LINK_READ_CONTACT | Executed |
| request-contact-addresses | PASS | Execute XDX_FETCH_LINK_READ | Must execute | XDX_FETCH_LINK_READ | Executed |
| request-contact-addresses | PASS | Execute XDX_FORMAT_LINK_READ | Must execute | XDX_FORMAT_LINK_READ | Executed |
| request-contact-addresses | PASS | Execute XDX_LINK_READ_RESPONSE | Must execute | XDX_LINK_READ_RESPONSE | Executed |
| request-contact-addresses | PASS | Skip XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| request-contact-addresses | PASS | Skip XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| request-contact-addresses | PASS | Skip XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| request-contact-addresses | PASS | Skip XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| request-contact-addresses | PASS | Skip XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| request-contact-addresses | PASS | Skip XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| request-contact-addresses | PASS | Skip XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| request-contact-addresses | PASS | Skip XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| request-contact-addresses | PASS | Skip XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| request-contact-addresses | PASS | Skip XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| request-contact-addresses | PASS | Skip XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| request-contact-addresses | PASS | Skip XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| request-contact-addresses | PASS | Skip XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| request-contact-addresses | PASS | Skip XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| request-contact-addresses | PASS | Skip XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| request-contact-addresses | PASS | Skip XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| request-contact-addresses | PASS | Skip XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| request-contact-addresses | PASS | Skip XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| request-contact-addresses | PASS | Skip XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| request-contact-addresses | PASS | Skip XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| request-contact-addresses | PASS | Skip XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| request-contact-addresses | PASS | Skip XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| request-contact-addresses | PASS | Skip XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| request-contact-addresses | PASS | Skip XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| request-contact-addresses | PASS | Skip XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| request-contact-addresses | PASS | Skip XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| request-contact-addresses | PASS | Skip XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| request-contact-addresses | PASS | Skip XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| request-contact-addresses | PASS | Skip XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| request-contact-addresses | PASS | Skip XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| request-contact-addresses | PASS | Skip XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| request-contact-addresses | PASS | Skip XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| request-contact-addresses | PASS | Skip XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| request-contact-addresses | PASS | Skip XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| request-contact-addresses | PASS | Skip XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| request-contact-addresses | PASS | Skip XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| request-contact-addresses | PASS | Skip XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| request-contact-addresses | PASS | Skip XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| request-contact-addresses | PASS | Skip XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| request-contact-addresses | PASS | Skip XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| request-contact-addresses | PASS | Skip XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| request-contact-addresses | PASS | Skip XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| request-contact-addresses | PASS | Skip XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| request-contact-addresses | PASS | Skip XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| request-contact-addresses | PASS | Skip XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| request-contact-addresses | PASS | Skip XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| request-contact-addresses | PASS | Skip XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| request-contact-addresses | PASS | Skip XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| request-contact-addresses | PASS | Skip XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| request-contact-addresses | PASS | Skip XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| request-contact-addresses | PASS | Skip XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| request-contact-addresses | PASS | Skip XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| request-contact-addresses | PASS | Skip XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| request-contact-addresses | PASS | Skip XDX_LINK_READ_SELECTOR_REQUIRED | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| request-contact-addresses | PASS | Skip XDX_LINK_READ_CONTACT_REQUIRED | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| request-contact-addresses | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| request-contact-addresses | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| request-contact-addresses | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| request-contact-addresses | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| request-contact-addresses | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| request-contact-addresses | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| request-contact-addresses | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| request-contact-addresses | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| request-contact-addresses | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| request-contact-addresses | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| repeat-selected-contact-addresses | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_PREPARE_SEARCH | Must execute | XDX_PREPARE_SEARCH | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_VALID_SEARCH | Must execute | XDX_VALID_SEARCH | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_FETCH_SUPPLIERS | Must execute | XDX_FETCH_SUPPLIERS | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_ROUTE_READ_RESOURCE | Must execute | XDX_ROUTE_READ_RESOURCE | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_RESOLVE_SUPPLIER | Must execute | XDX_RESOLVE_SUPPLIER | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_VALID_PARENT | Must execute | XDX_VALID_PARENT | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_ROUTE_CHILD_READ | Must execute | XDX_ROUTE_CHILD_READ | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_PREPARE_LINK_READ | Must execute | XDX_PREPARE_LINK_READ | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_VALID_LINK_READ_SELECTOR | Must execute | XDX_VALID_LINK_READ_SELECTOR | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_RESOLVE_LINK_READ_CONTACT | Must execute | XDX_RESOLVE_LINK_READ_CONTACT | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_BIND_LINK_READ_CONTACT | Must execute | XDX_BIND_LINK_READ_CONTACT | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_VALID_LINK_READ_CONTACT | Must execute | XDX_VALID_LINK_READ_CONTACT | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_FETCH_LINK_READ | Must execute | XDX_FETCH_LINK_READ | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_FORMAT_LINK_READ | Must execute | XDX_FORMAT_LINK_READ | Executed |
| repeat-selected-contact-addresses | PASS | Execute XDX_LINK_READ_RESPONSE | Must execute | XDX_LINK_READ_RESPONSE | Executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_LINK_READ_SELECTOR_REQUIRED | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| repeat-selected-contact-addresses | PASS | Skip XDX_LINK_READ_CONTACT_REQUIRED | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| repeat-selected-contact-addresses | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| repeat-selected-contact-addresses | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| repeat-selected-contact-addresses | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| repeat-selected-contact-addresses | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| repeat-selected-contact-addresses | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| repeat-selected-contact-addresses | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| repeat-selected-contact-addresses | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| repeat-selected-contact-addresses | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| repeat-selected-contact-addresses | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| repeat-selected-contact-addresses | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |

## Node Assertions

| Step | Status | Assertion | Node Code | Occurrence | Asserted Value | Operator | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| request-contact-addresses | PASS | Resolved intended supplier | XDX_RESOLVE_SUPPLIER | last | output/result/supplierId | equals | "300000333814329" | string (15 characters) |
| request-contact-addresses | PASS | Resolved intended contact | XDX_BIND_LINK_READ_CONTACT | last | output/result/contactId | equals | "300000333814350" | string (15 characters) |
| request-contact-addresses | PASS | Read contact-address branch | XDX_PREPARE_SEARCH | last | output/result/resource | equals | "contactAddresses" | string (16 characters) |
| repeat-selected-contact-addresses | PASS | Resolved intended supplier | XDX_RESOLVE_SUPPLIER | last | output/result/supplierId | equals | "300000333814329" | string (15 characters) |
| repeat-selected-contact-addresses | PASS | Resolved intended contact | XDX_BIND_LINK_READ_CONTACT | last | output/result/contactId | equals | "300000333814350" | string (15 characters) |
| repeat-selected-contact-addresses | PASS | Read contact-address branch | XDX_PREPARE_SEARCH | last | output/result/resource | equals | "contactAddresses" | string (16 characters) |

## Workflow Run Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| request-contact-addresses | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| repeat-selected-contact-addresses | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| Conversation | PASS | conversationStepOrder | conversationStepOrder | request-contact-addresses -> repeat-selected-contact-addresses | Verified |
| Conversation | PASS | conversationIdReuse | conversationIdReuse | Every executed step uses one conversation ID. | Verified |

## Output Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| request-contact-addresses | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| request-contact-addresses | PASS | Correct selected business value 0 | contains | XDX Lifecycle Retry 20260923 A | Found "XDX Lifecycle Retry 20260923 A" |
| request-contact-addresses | PASS | Correct selected business value 1 | contains | xdx-contact-retry-20260923-a@example.invalid | Found "xdx-contact-retry-20260923-a@example.invalid" |
| request-contact-addresses | PASS | Correct selected business value 2 | contains | XDX HQ Retry 20260923 A | Found "XDX HQ Retry 20260923 A" |
| request-contact-addresses | PASS | No technical association key displayed | notContains | 300000333814361 | Not found |
| repeat-selected-contact-addresses | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| repeat-selected-contact-addresses | PASS | Correct selected business value 0 | contains | XDX Lifecycle Retry 20260923 A | Found "XDX Lifecycle Retry 20260923 A" |
| repeat-selected-contact-addresses | PASS | Correct selected business value 1 | contains | xdx-contact-retry-20260923-a@example.invalid | Found "xdx-contact-retry-20260923-a@example.invalid" |
| repeat-selected-contact-addresses | PASS | Correct selected business value 2 | contains | XDX HQ Retry 20260923 A | Found "XDX HQ Retry 20260923 A" |
| repeat-selected-contact-addresses | PASS | No technical association key displayed | notContains | 300000333814361 | Not found |

## Runtime Metrics

Workflow time: 5222 ms (sum of node times)
Test run time: 9075 ms (includes CLI overhead)
Token usage: observed from runtime events

Aggregate Token Usage

| Input Tokens | Output Tokens | Total Tokens | Model |
| --- | --- | --- | --- |
| 8677 | 1046 | 9723 | oci-agent/openai.gpt-4.1-mini-2025-04-14 |

| Node | Input Tokens | Output Tokens | Total Tokens | Model | Source |
| --- | --- | --- | --- | --- | --- |
| repeat-selected-contact-addresses:XDX_EXTRACT_SEARCH | 4401 | 523 | 4924 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| request-contact-addresses:XDX_EXTRACT_SEARCH | 4276 | 523 | 4799 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |


AI Units: computed
Total Token Units: 2
Total AI Units: 10

| Node | Input | Output | Token Units | AI Units | Model Type | Action Type |
| --- | --- | --- | --- | --- | --- | --- |
| repeat-selected-contact-addresses:XDX_EXTRACT_SEARCH | 4401 | 523 | 1 | 5 | premium | general |
| request-contact-addresses:XDX_EXTRACT_SEARCH | 4276 | 523 | 1 | 5 | premium | general |

| Node | Node Time (ms) | LLM Call Time (ms) | Details |
| --- | --- | --- | --- |
| request-contact-addresses:XDX_EXTRACT_SEARCH | 2569 | 2484 | 1 runtime detail; see JSON report |
| request-contact-addresses:XDX_FETCH_SUPPLIERS | 46 |  | 0 runtime details; see JSON report |
| request-contact-addresses:XDX_RESOLVE_LINK_READ_CONTACT | 46 |  | 0 runtime details; see JSON report |
| request-contact-addresses:XDX_FETCH_LINK_READ | 46 |  | 0 runtime details; see JSON report |
| repeat-selected-contact-addresses:XDX_EXTRACT_SEARCH | 2408 | 2300 | 1 runtime detail; see JSON report |
| repeat-selected-contact-addresses:XDX_FETCH_SUPPLIERS | 16 |  | 0 runtime details; see JSON report |
| repeat-selected-contact-addresses:XDX_RESOLVE_LINK_READ_CONTACT | 46 |  | 0 runtime details; see JSON report |
| repeat-selected-contact-addresses:XDX_FETCH_LINK_READ | 45 |  | 0 runtime details; see JSON report |

| Observed Field | Values |
| --- | --- |
| modelName | "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14" |
| inputTokens | 4276; 4401 |
| outputTokens | 523; 523 |

## Test Data

| Step | Data Source | Evaluation |
| --- | --- | --- |
| request-contact-addresses | File replay | Deterministic |
| repeat-selected-contact-addresses | File replay | Deterministic |

## Workflow Run

### Execution Timeline

| Step | Phase Sequence | Node | Event |
| --- | --- | --- | --- |
| request-contact-addresses | 1 | START | NODE_EXECUTED |
| request-contact-addresses | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| request-contact-addresses | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| request-contact-addresses | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| request-contact-addresses | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| request-contact-addresses | 6 | XDX_PREPARE_SEARCH | NODE_EXECUTED |
| request-contact-addresses | 7 | XDX_VALID_SEARCH | NODE_EXECUTED |
| request-contact-addresses | 8 | XDX_FETCH_SUPPLIERS | NODE_START |
| request-contact-addresses | 9 | XDX_ROUTE_READ_RESOURCE | NODE_START |
| request-contact-addresses | 10 | XDX_RESOLVE_SUPPLIER | NODE_EXECUTED |
| request-contact-addresses | 11 | XDX_VALID_PARENT | NODE_EXECUTED |
| request-contact-addresses | 12 | XDX_ROUTE_CHILD_READ | NODE_START |
| request-contact-addresses | 13 | XDX_PREPARE_LINK_READ | NODE_EXECUTED |
| request-contact-addresses | 14 | XDX_VALID_LINK_READ_SELECTOR | NODE_EXECUTED |
| request-contact-addresses | 15 | XDX_RESOLVE_LINK_READ_CONTACT | NODE_START |
| request-contact-addresses | 16 | XDX_BIND_LINK_READ_CONTACT | NODE_EXECUTED |
| request-contact-addresses | 17 | XDX_VALID_LINK_READ_CONTACT | NODE_EXECUTED |
| request-contact-addresses | 18 | XDX_FETCH_LINK_READ | NODE_START |
| request-contact-addresses | 19 | XDX_FORMAT_LINK_READ | NODE_EXECUTED |
| request-contact-addresses | 20 | XDX_LINK_READ_RESPONSE | NODE_EXECUTED |
| repeat-selected-contact-addresses | 1 | START | NODE_EXECUTED |
| repeat-selected-contact-addresses | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| repeat-selected-contact-addresses | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| repeat-selected-contact-addresses | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| repeat-selected-contact-addresses | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| repeat-selected-contact-addresses | 6 | XDX_PREPARE_SEARCH | NODE_EXECUTED |
| repeat-selected-contact-addresses | 7 | XDX_VALID_SEARCH | NODE_EXECUTED |
| repeat-selected-contact-addresses | 8 | XDX_FETCH_SUPPLIERS | NODE_START |
| repeat-selected-contact-addresses | 9 | XDX_ROUTE_READ_RESOURCE | NODE_START |
| repeat-selected-contact-addresses | 10 | XDX_RESOLVE_SUPPLIER | NODE_EXECUTED |
| repeat-selected-contact-addresses | 11 | XDX_VALID_PARENT | NODE_EXECUTED |
| repeat-selected-contact-addresses | 12 | XDX_ROUTE_CHILD_READ | NODE_START |
| repeat-selected-contact-addresses | 13 | XDX_PREPARE_LINK_READ | NODE_EXECUTED |
| repeat-selected-contact-addresses | 14 | XDX_VALID_LINK_READ_SELECTOR | NODE_EXECUTED |
| repeat-selected-contact-addresses | 15 | XDX_RESOLVE_LINK_READ_CONTACT | NODE_START |
| repeat-selected-contact-addresses | 16 | XDX_BIND_LINK_READ_CONTACT | NODE_EXECUTED |
| repeat-selected-contact-addresses | 17 | XDX_VALID_LINK_READ_CONTACT | NODE_EXECUTED |
| repeat-selected-contact-addresses | 18 | XDX_FETCH_LINK_READ | NODE_START |
| repeat-selected-contact-addresses | 19 | XDX_FORMAT_LINK_READ | NODE_EXECUTED |
| repeat-selected-contact-addresses | 20 | XDX_LINK_READ_RESPONSE | NODE_EXECUTED |

### Other Observed Nodes

| Node | Observed |
| --- | --- |
| START | 2 |
| XDX_BIND_LINK_READ_CONTACT | 2 |
| XDX_EXTRACT_SEARCH | 2 |
| XDX_FETCH_SUPPLIERS | 2 |
| XDX_FORMAT_LINK_READ | 2 |
| XDX_LINK_READ_RESPONSE | 2 |
| XDX_NORMALIZE_REQUEST | 2 |
| XDX_PREPARE_LINK_READ | 2 |
| XDX_PREPARE_SEARCH | 2 |
| XDX_RESOLVE_LINK_READ_CONTACT | 2 |
| XDX_RESOLVE_SUPPLIER | 2 |
| XDX_ROUTE_APP_STAGE | 2 |
| XDX_ROUTE_CHILD_READ | 2 |
| XDX_ROUTE_READ_RESOURCE | 2 |
| XDX_ROUTE_REQUEST_INTENT | 2 |
| XDX_VALID_LINK_READ_CONTACT | 2 |
| XDX_VALID_LINK_READ_SELECTOR | 2 |
| XDX_VALID_PARENT | 2 |
| XDX_VALID_SEARCH | 2 |

## Report Files

- JSON report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-contact-address-read\result.json`
- Markdown report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-contact-address-read\result.md`
- Test file: `test/workflows/xdx_supplier_lifecycle_agent/xdx-contact-address-read.json`
