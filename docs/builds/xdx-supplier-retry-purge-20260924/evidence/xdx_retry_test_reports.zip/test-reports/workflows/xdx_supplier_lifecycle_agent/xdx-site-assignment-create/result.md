# Workflow Conversation Test Result: xdx-site-assignment-create

**Status:** PASSED
**Workflow:** XDX_SUPPLIER_LIFECYCLE_AGENT (DRAFT v86153667)
**Goal:** Prepare, review, approve and create one site assignment using the existing supplier site and two explicit BU roles.
**Data Source:** File replay
**Evaluation:** Deterministic
**Steps:** 4

## Conversation Journey

| # | Step | Type | Intent | Interaction | Outcome | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | prepare-required-assignment | chat | Prepare a site-assignment draft for supplier XDX Lifecycle Retry 20260923 A, existing site XDX SITE Retry 20260923 A, client business unit US1 Business Unit, and bill-to business unit US1 Business Unit. | Prepare a site-assignment draft for supplier XDX Lifecycle Retry 20260923 A, existing site XDX SITE Retry 20260923 A, client business unit US1 Business Unit, and bill-to business unit US1 Business Unit. | <oraInfoDisplay key="site-assignment-review">{"patternId":"multiRecordWidget","title":"Site assignment draft revision 1","description":"Site assignment draft saved. No assignment has been created.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Supplier site","XDX SITE Retry 20260923 A"]},{"cells":["Client business unit","US1 Business Unit"]},{"cells":["Bill-to business unit","US1 Business Unit"]}]}}</oraInfoDisplay> | passed |
| 2 | review-assignment-references | chat | Review the exact site-assignment draft. | Review the exact site-assignment draft. | <oraInfoDisplay key="site-assignment-review">{"patternId":"multiRecordWidget","title":"Site assignment draft revision 1","description":"Review this supplier site and the two business unit roles. The request contains only the two resolved BU references. To approve without writing, enter: Approve site-assignment revision 1.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Supplier site","XDX SITE Retry 20260923 A"]},{"cells":["Client business unit","US1 Business Unit"]},{"cells":["Bill-to business unit","US1 Business Unit"]}]}}</oraInfoDisplay> | passed |
| 3 | approve-exact-assignment | chat | Approve site-assignment revision 1 | Approve site-assignment revision 1 | <oraInfoDisplay key="site-assignment-review">{"patternId":"multiRecordWidget","title":"Site assignment draft revision 1","description":"Site assignment revision 1 approved without writing. To create, enter: Create site-assignment revision 1.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Supplier site","XDX SITE Retry 20260923 A"]},{"cells":["Client business unit","US1 Business Unit"]},{"cells":["Bill-to business unit","US1 Business Unit"]}]}}</oraInfoDisplay> | passed |
| 4 | create-approved-assignment | chat | Create site-assignment revision 1 | Create site-assignment revision 1 | <oraInfoDisplay key="site-assignment-review">{"patternId":"multiRecordWidget","title":"Site assignment draft revision 1","description":"Site assignment created and independently verified.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Supplier site","XDX SITE Retry 20260923 A"]},{"cells":["Client business unit","US1 Business Unit"]},{"cells":["Bill-to business unit","US1 Business Unit"]}]}}</oraInfoDisplay> | passed |

## Step 1: prepare-required-assignment

**Status:** passed
**Type:** chat
**Intent:** Prepare a site-assignment draft for supplier XDX Lifecycle Retry 20260923 A, existing site XDX SITE Retry 20260923 A, client business unit US1 Business Unit, and bill-to business unit US1 Business Unit.
**Context Step IDs:** None (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Prepare a site-assignment draft for supplier XDX Lifecycle Retry 20260923 A, existing site XDX SITE Retry 20260923 A, client business unit US1 Business Unit, and bill-to business unit US1 Business Unit.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="site-assignment-review">{"patternId":"multiRecordWidget","title":"Site assignment draft revision 1","description":"Site assignment draft saved. No assignment has been created.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Supplier site","XDX SITE Retry 20260923 A"]},{"cells":["Client business unit","US1 Business Unit"]},{"cells":["Bill-to business unit","US1 Business Unit"]}]}}</oraInfoDisplay>
~~~

## Step 2: review-assignment-references

**Status:** passed
**Type:** chat
**Intent:** Review the exact site-assignment draft.
**Context Step IDs:** prepare-required-assignment (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Review the exact site-assignment draft.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="site-assignment-review">{"patternId":"multiRecordWidget","title":"Site assignment draft revision 1","description":"Review this supplier site and the two business unit roles. The request contains only the two resolved BU references. To approve without writing, enter: Approve site-assignment revision 1.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Supplier site","XDX SITE Retry 20260923 A"]},{"cells":["Client business unit","US1 Business Unit"]},{"cells":["Bill-to business unit","US1 Business Unit"]}]}}</oraInfoDisplay>
~~~

## Step 3: approve-exact-assignment

**Status:** passed
**Type:** chat
**Intent:** Approve site-assignment revision 1
**Context Step IDs:** prepare-required-assignment, review-assignment-references (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Approve site-assignment revision 1",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="site-assignment-review">{"patternId":"multiRecordWidget","title":"Site assignment draft revision 1","description":"Site assignment revision 1 approved without writing. To create, enter: Create site-assignment revision 1.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Supplier site","XDX SITE Retry 20260923 A"]},{"cells":["Client business unit","US1 Business Unit"]},{"cells":["Bill-to business unit","US1 Business Unit"]}]}}</oraInfoDisplay>
~~~

## Step 4: create-approved-assignment

**Status:** passed
**Type:** chat
**Intent:** Create site-assignment revision 1
**Context Step IDs:** prepare-required-assignment, review-assignment-references, approve-exact-assignment (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Create site-assignment revision 1",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="site-assignment-review">{"patternId":"multiRecordWidget","title":"Site assignment draft revision 1","description":"Site assignment created and independently verified.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Supplier site","XDX SITE Retry 20260923 A"]},{"cells":["Client business unit","US1 Business Unit"]},{"cells":["Bill-to business unit","US1 Business Unit"]}]}}</oraInfoDisplay>
~~~

## Verification Summary

| Verification | Status | Result |
| --- | --- | --- |
| Node order and counts | PASSED | 5/5 passed |
| Path assertions | PASSED | 996/996 passed |
| Node assertions | PASSED | 7/7 passed |
| Workflow run checks | PASSED | 6/6 passed |
| Output checks | PASSED | 10/10 passed |

## Node Order and Count

### Required Relative Order

Other nodes may execute between the listed nodes.

| Step | Status | Assertion | Required Relative Order | Observed or Failure |
| --- | --- | --- | --- | --- |
| prepare-required-assignment | PASS | Review before write and verification | XDX_REDUCE_ASSIGNMENT_DRAFT -> XDX_ASSIGNMENT_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_ASSIGNMENT_DRAFT -> XDX_SAVE_ASSIGNMENT_DRAFT -> XDX_ASSIGNMENT_NEEDS_REFERENCES -> XDX_ASSIGNMENT_DRAFT_RESPONSE |
| review-assignment-references | PASS | Review before write and verification | XDX_REDUCE_ASSIGNMENT_DRAFT -> XDX_BIND_ASSIGNMENT_REFERENCES -> XDX_SAVE_ASSIGNMENT_REVIEW -> XDX_ASSIGNMENT_REVIEW_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_ASSIGNMENT_DRAFT -> XDX_SAVE_ASSIGNMENT_DRAFT -> XDX_ASSIGNMENT_NEEDS_REFERENCES -> XDX_RESOLVE_ASSIGNMENT_PARENT -> XDX_BIND_ASSIGNMENT_PARENT -> XDX_VALID_ASSIGNMENT_PARENT -> XDX_RESOLVE_ASSIGNMENT_SITE -> XDX_BIND_ASSIGNMENT_SITE -> XDX_VALID_ASSIGNMENT_SITE -> XDX_RESOLVE_ASSIGNMENT_CLIENT_BU -> XDX_BIND_ASSIGNMENT_CLIENT_BU -> XDX_VALID_ASSIGNMENT_CLIENT_BU -> XDX_RESOLVE_ASSIGNMENT_BILL_BU -> XDX_BIND_ASSIGNMENT_REFERENCES -> XDX_VALID_ASSIGNMENT_REFERENCES -> XDX_ASSIGNMENT_IS_REVIEW -> XDX_SAVE_ASSIGNMENT_REVIEW -> XDX_ASSIGNMENT_REVIEW_RESPONSE |
| approve-exact-assignment | PASS | Review before write and verification | XDX_REDUCE_ASSIGNMENT_DRAFT -> XDX_ASSIGNMENT_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_ASSIGNMENT_DRAFT -> XDX_SAVE_ASSIGNMENT_DRAFT -> XDX_ASSIGNMENT_NEEDS_REFERENCES -> XDX_ASSIGNMENT_DRAFT_RESPONSE |
| create-approved-assignment | PASS | Review before write and verification | XDX_REDUCE_ASSIGNMENT_DRAFT -> XDX_BIND_ASSIGNMENT_REFERENCES -> XDX_SAVE_ASSIGNMENT_ATTEMPT -> XDX_CREATE_ASSIGNMENT -> XDX_VERIFY_ASSIGNMENT -> XDX_CONFIRM_ASSIGNMENT_CREATE -> XDX_ASSIGNMENT_CREATE_RESULT | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_ASSIGNMENT_DRAFT -> XDX_SAVE_ASSIGNMENT_DRAFT -> XDX_ASSIGNMENT_NEEDS_REFERENCES -> XDX_RESOLVE_ASSIGNMENT_PARENT -> XDX_BIND_ASSIGNMENT_PARENT -> XDX_VALID_ASSIGNMENT_PARENT -> XDX_RESOLVE_ASSIGNMENT_SITE -> XDX_BIND_ASSIGNMENT_SITE -> XDX_VALID_ASSIGNMENT_SITE -> XDX_RESOLVE_ASSIGNMENT_CLIENT_BU -> XDX_BIND_ASSIGNMENT_CLIENT_BU -> XDX_VALID_ASSIGNMENT_CLIENT_BU -> XDX_RESOLVE_ASSIGNMENT_BILL_BU -> XDX_BIND_ASSIGNMENT_REFERENCES -> XDX_VALID_ASSIGNMENT_REFERENCES -> XDX_ASSIGNMENT_IS_REVIEW -> XDX_CHECK_ASSIGNMENT_DUPLICATE -> XDX_DECIDE_ASSIGNMENT_CREATE -> XDX_CAN_POST_ASSIGNMENT -> XDX_SAVE_ASSIGNMENT_ATTEMPT -> XDX_CREATE_ASSIGNMENT -> XDX_VERIFY_ASSIGNMENT -> XDX_CONFIRM_ASSIGNMENT_CREATE -> XDX_SAVE_ASSIGNMENT_CONFIRMATION -> XDX_ASSIGNMENT_CREATE_RESULT |

### Node Count Checks

| Step | Assertion | Node Code | Expected | Observed | Status |
| --- | --- | --- | --- | --- | --- |
| create-approved-assignment | One assignment POST node | XDX_CREATE_ASSIGNMENT | exactly 1 | 1 | PASS |

## Path Assertions

| Step | Status | Assertion | Requirement | Node Code | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-assignment | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| prepare-required-assignment | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| prepare-required-assignment | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| prepare-required-assignment | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| prepare-required-assignment | PASS | Execute XDX_REDUCE_ASSIGNMENT_DRAFT | Must execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Executed |
| prepare-required-assignment | PASS | Execute XDX_SAVE_ASSIGNMENT_DRAFT | Must execute | XDX_SAVE_ASSIGNMENT_DRAFT | Executed |
| prepare-required-assignment | PASS | Execute XDX_ASSIGNMENT_NEEDS_REFERENCES | Must execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Executed |
| prepare-required-assignment | PASS | Execute XDX_ASSIGNMENT_DRAFT_RESPONSE | Must execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Executed |
| prepare-required-assignment | PASS | Skip XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| prepare-required-assignment | PASS | Skip XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| prepare-required-assignment | PASS | Skip XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| prepare-required-assignment | PASS | Skip XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| prepare-required-assignment | PASS | Skip XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| prepare-required-assignment | PASS | Skip XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| prepare-required-assignment | PASS | Skip XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| prepare-required-assignment | PASS | Skip XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| prepare-required-assignment | PASS | Skip XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| prepare-required-assignment | PASS | Skip XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| prepare-required-assignment | PASS | Skip XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| prepare-required-assignment | PASS | Skip XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| prepare-required-assignment | PASS | Skip XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| prepare-required-assignment | PASS | Skip XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| prepare-required-assignment | PASS | Skip XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| prepare-required-assignment | PASS | Skip XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-assignment | PASS | Skip XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-assignment | PASS | Skip XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-assignment | PASS | Skip XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| prepare-required-assignment | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| prepare-required-assignment | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| prepare-required-assignment | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| prepare-required-assignment | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| prepare-required-assignment | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| prepare-required-assignment | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| prepare-required-assignment | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| prepare-required-assignment | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| prepare-required-assignment | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| prepare-required-assignment | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| prepare-required-assignment | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| prepare-required-assignment | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| prepare-required-assignment | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| prepare-required-assignment | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| prepare-required-assignment | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| prepare-required-assignment | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| prepare-required-assignment | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-assignment | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-assignment | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-assignment | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| prepare-required-assignment | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| prepare-required-assignment | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| prepare-required-assignment | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| review-assignment-references | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| review-assignment-references | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| review-assignment-references | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| review-assignment-references | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| review-assignment-references | PASS | Execute XDX_REDUCE_ASSIGNMENT_DRAFT | Must execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Executed |
| review-assignment-references | PASS | Execute XDX_SAVE_ASSIGNMENT_DRAFT | Must execute | XDX_SAVE_ASSIGNMENT_DRAFT | Executed |
| review-assignment-references | PASS | Execute XDX_ASSIGNMENT_NEEDS_REFERENCES | Must execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Executed |
| review-assignment-references | PASS | Execute XDX_RESOLVE_ASSIGNMENT_PARENT | Must execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Executed |
| review-assignment-references | PASS | Execute XDX_BIND_ASSIGNMENT_PARENT | Must execute | XDX_BIND_ASSIGNMENT_PARENT | Executed |
| review-assignment-references | PASS | Execute XDX_VALID_ASSIGNMENT_PARENT | Must execute | XDX_VALID_ASSIGNMENT_PARENT | Executed |
| review-assignment-references | PASS | Execute XDX_RESOLVE_ASSIGNMENT_SITE | Must execute | XDX_RESOLVE_ASSIGNMENT_SITE | Executed |
| review-assignment-references | PASS | Execute XDX_BIND_ASSIGNMENT_SITE | Must execute | XDX_BIND_ASSIGNMENT_SITE | Executed |
| review-assignment-references | PASS | Execute XDX_VALID_ASSIGNMENT_SITE | Must execute | XDX_VALID_ASSIGNMENT_SITE | Executed |
| review-assignment-references | PASS | Execute XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Executed |
| review-assignment-references | PASS | Execute XDX_BIND_ASSIGNMENT_REFERENCES | Must execute | XDX_BIND_ASSIGNMENT_REFERENCES | Executed |
| review-assignment-references | PASS | Execute XDX_VALID_ASSIGNMENT_REFERENCES | Must execute | XDX_VALID_ASSIGNMENT_REFERENCES | Executed |
| review-assignment-references | PASS | Execute XDX_ASSIGNMENT_IS_REVIEW | Must execute | XDX_ASSIGNMENT_IS_REVIEW | Executed |
| review-assignment-references | PASS | Execute XDX_SAVE_ASSIGNMENT_REVIEW | Must execute | XDX_SAVE_ASSIGNMENT_REVIEW | Executed |
| review-assignment-references | PASS | Execute XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Executed |
| review-assignment-references | PASS | Execute XDX_BIND_ASSIGNMENT_CLIENT_BU | Must execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Executed |
| review-assignment-references | PASS | Execute XDX_VALID_ASSIGNMENT_CLIENT_BU | Must execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Executed |
| review-assignment-references | PASS | Execute XDX_ASSIGNMENT_REVIEW_RESPONSE | Must execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Executed |
| review-assignment-references | PASS | Skip XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| review-assignment-references | PASS | Skip XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| review-assignment-references | PASS | Skip XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| review-assignment-references | PASS | Skip XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| review-assignment-references | PASS | Skip XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| review-assignment-references | PASS | Skip XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| review-assignment-references | PASS | Skip XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| review-assignment-references | PASS | Skip XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| review-assignment-references | PASS | Skip XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| review-assignment-references | PASS | Skip XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| review-assignment-references | PASS | Skip XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| review-assignment-references | PASS | Skip XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| review-assignment-references | PASS | Skip XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| review-assignment-references | PASS | Skip XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| review-assignment-references | PASS | Skip XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| review-assignment-references | PASS | Skip XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| review-assignment-references | PASS | Skip XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| review-assignment-references | PASS | Skip XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| review-assignment-references | PASS | Skip XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| review-assignment-references | PASS | Skip XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| review-assignment-references | PASS | Skip XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| review-assignment-references | PASS | Skip XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| review-assignment-references | PASS | Skip XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| review-assignment-references | PASS | Skip XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| review-assignment-references | PASS | Skip XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| review-assignment-references | PASS | Skip XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| review-assignment-references | PASS | Skip XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| review-assignment-references | PASS | Skip XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| review-assignment-references | PASS | Skip XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| review-assignment-references | PASS | Skip XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| review-assignment-references | PASS | Skip XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| review-assignment-references | PASS | Skip XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| review-assignment-references | PASS | Skip XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| review-assignment-references | PASS | Skip XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| review-assignment-references | PASS | Skip XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| review-assignment-references | PASS | Skip XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| review-assignment-references | PASS | Skip XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| review-assignment-references | PASS | Skip XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| review-assignment-references | PASS | Skip XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| review-assignment-references | PASS | Skip XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| review-assignment-references | PASS | Skip XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| review-assignment-references | PASS | Skip XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| review-assignment-references | PASS | Skip XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| review-assignment-references | PASS | Skip XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| review-assignment-references | PASS | Skip XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| review-assignment-references | PASS | Skip XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| review-assignment-references | PASS | Skip XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| review-assignment-references | PASS | Skip XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| review-assignment-references | PASS | Skip XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| review-assignment-references | PASS | Skip XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| review-assignment-references | PASS | Skip XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| review-assignment-references | PASS | Skip XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| review-assignment-references | PASS | Skip XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| review-assignment-references | PASS | Skip XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| review-assignment-references | PASS | Skip XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| review-assignment-references | PASS | Skip XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| review-assignment-references | PASS | Skip XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| review-assignment-references | PASS | Skip XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| review-assignment-references | PASS | Skip XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| review-assignment-references | PASS | Skip XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| review-assignment-references | PASS | Skip XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| review-assignment-references | PASS | Skip XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| review-assignment-references | PASS | Skip XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| review-assignment-references | PASS | Skip XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| review-assignment-references | PASS | Skip XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| review-assignment-references | PASS | Skip XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| review-assignment-references | PASS | Skip XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| review-assignment-references | PASS | Skip XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| review-assignment-references | PASS | Skip XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| review-assignment-references | PASS | Skip XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| review-assignment-references | PASS | Skip XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| review-assignment-references | PASS | Skip XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| review-assignment-references | PASS | Skip XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| review-assignment-references | PASS | Skip XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| review-assignment-references | PASS | Skip XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| review-assignment-references | PASS | Skip XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| review-assignment-references | PASS | Skip XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| review-assignment-references | PASS | Skip XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| review-assignment-references | PASS | Skip XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| review-assignment-references | PASS | Skip XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| review-assignment-references | PASS | Skip XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| review-assignment-references | PASS | Skip XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| review-assignment-references | PASS | Skip XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| review-assignment-references | PASS | Skip XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| review-assignment-references | PASS | Skip XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| review-assignment-references | PASS | Skip XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| review-assignment-references | PASS | Skip XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| review-assignment-references | PASS | Skip XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| review-assignment-references | PASS | Skip XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| review-assignment-references | PASS | Skip XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| review-assignment-references | PASS | Skip XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| review-assignment-references | PASS | Skip XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| review-assignment-references | PASS | Skip XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| review-assignment-references | PASS | Skip XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| review-assignment-references | PASS | Skip XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| review-assignment-references | PASS | Skip XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| review-assignment-references | PASS | Skip XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| review-assignment-references | PASS | Skip XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| review-assignment-references | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| review-assignment-references | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| review-assignment-references | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| review-assignment-references | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| review-assignment-references | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| review-assignment-references | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| review-assignment-references | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| review-assignment-references | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| review-assignment-references | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| review-assignment-references | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| review-assignment-references | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| review-assignment-references | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| review-assignment-references | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| review-assignment-references | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| review-assignment-references | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| review-assignment-references | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| review-assignment-references | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| review-assignment-references | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| review-assignment-references | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| review-assignment-references | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| review-assignment-references | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| review-assignment-references | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| review-assignment-references | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| approve-exact-assignment | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| approve-exact-assignment | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| approve-exact-assignment | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| approve-exact-assignment | PASS | Execute XDX_REDUCE_ASSIGNMENT_DRAFT | Must execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Executed |
| approve-exact-assignment | PASS | Execute XDX_SAVE_ASSIGNMENT_DRAFT | Must execute | XDX_SAVE_ASSIGNMENT_DRAFT | Executed |
| approve-exact-assignment | PASS | Execute XDX_ASSIGNMENT_NEEDS_REFERENCES | Must execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Executed |
| approve-exact-assignment | PASS | Execute XDX_ASSIGNMENT_DRAFT_RESPONSE | Must execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Executed |
| approve-exact-assignment | PASS | Skip XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| approve-exact-assignment | PASS | Skip XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| approve-exact-assignment | PASS | Skip XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| approve-exact-assignment | PASS | Skip XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| approve-exact-assignment | PASS | Skip XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| approve-exact-assignment | PASS | Skip XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| approve-exact-assignment | PASS | Skip XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| approve-exact-assignment | PASS | Skip XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| approve-exact-assignment | PASS | Skip XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| approve-exact-assignment | PASS | Skip XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| approve-exact-assignment | PASS | Skip XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| approve-exact-assignment | PASS | Skip XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| approve-exact-assignment | PASS | Skip XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| approve-exact-assignment | PASS | Skip XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| approve-exact-assignment | PASS | Skip XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| approve-exact-assignment | PASS | Skip XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-exact-assignment | PASS | Skip XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-exact-assignment | PASS | Skip XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-exact-assignment | PASS | Skip XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| approve-exact-assignment | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| approve-exact-assignment | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| approve-exact-assignment | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| approve-exact-assignment | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| approve-exact-assignment | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| approve-exact-assignment | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| approve-exact-assignment | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| approve-exact-assignment | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| approve-exact-assignment | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| approve-exact-assignment | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| approve-exact-assignment | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| approve-exact-assignment | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| approve-exact-assignment | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| approve-exact-assignment | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| approve-exact-assignment | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| approve-exact-assignment | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| approve-exact-assignment | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| approve-exact-assignment | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| approve-exact-assignment | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| approve-exact-assignment | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| approve-exact-assignment | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| approve-exact-assignment | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| approve-exact-assignment | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| create-approved-assignment | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| create-approved-assignment | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| create-approved-assignment | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| create-approved-assignment | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| create-approved-assignment | PASS | Execute XDX_REDUCE_ASSIGNMENT_DRAFT | Must execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Executed |
| create-approved-assignment | PASS | Execute XDX_SAVE_ASSIGNMENT_DRAFT | Must execute | XDX_SAVE_ASSIGNMENT_DRAFT | Executed |
| create-approved-assignment | PASS | Execute XDX_ASSIGNMENT_NEEDS_REFERENCES | Must execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Executed |
| create-approved-assignment | PASS | Execute XDX_RESOLVE_ASSIGNMENT_PARENT | Must execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Executed |
| create-approved-assignment | PASS | Execute XDX_BIND_ASSIGNMENT_PARENT | Must execute | XDX_BIND_ASSIGNMENT_PARENT | Executed |
| create-approved-assignment | PASS | Execute XDX_VALID_ASSIGNMENT_PARENT | Must execute | XDX_VALID_ASSIGNMENT_PARENT | Executed |
| create-approved-assignment | PASS | Execute XDX_RESOLVE_ASSIGNMENT_SITE | Must execute | XDX_RESOLVE_ASSIGNMENT_SITE | Executed |
| create-approved-assignment | PASS | Execute XDX_BIND_ASSIGNMENT_SITE | Must execute | XDX_BIND_ASSIGNMENT_SITE | Executed |
| create-approved-assignment | PASS | Execute XDX_VALID_ASSIGNMENT_SITE | Must execute | XDX_VALID_ASSIGNMENT_SITE | Executed |
| create-approved-assignment | PASS | Execute XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Executed |
| create-approved-assignment | PASS | Execute XDX_BIND_ASSIGNMENT_REFERENCES | Must execute | XDX_BIND_ASSIGNMENT_REFERENCES | Executed |
| create-approved-assignment | PASS | Execute XDX_VALID_ASSIGNMENT_REFERENCES | Must execute | XDX_VALID_ASSIGNMENT_REFERENCES | Executed |
| create-approved-assignment | PASS | Execute XDX_ASSIGNMENT_IS_REVIEW | Must execute | XDX_ASSIGNMENT_IS_REVIEW | Executed |
| create-approved-assignment | PASS | Execute XDX_CHECK_ASSIGNMENT_DUPLICATE | Must execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Executed |
| create-approved-assignment | PASS | Execute XDX_DECIDE_ASSIGNMENT_CREATE | Must execute | XDX_DECIDE_ASSIGNMENT_CREATE | Executed |
| create-approved-assignment | PASS | Execute XDX_CAN_POST_ASSIGNMENT | Must execute | XDX_CAN_POST_ASSIGNMENT | Executed |
| create-approved-assignment | PASS | Execute XDX_SAVE_ASSIGNMENT_ATTEMPT | Must execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Executed |
| create-approved-assignment | PASS | Execute XDX_CREATE_ASSIGNMENT | Must execute | XDX_CREATE_ASSIGNMENT | Executed |
| create-approved-assignment | PASS | Execute XDX_VERIFY_ASSIGNMENT | Must execute | XDX_VERIFY_ASSIGNMENT | Executed |
| create-approved-assignment | PASS | Execute XDX_CONFIRM_ASSIGNMENT_CREATE | Must execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Executed |
| create-approved-assignment | PASS | Execute XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Executed |
| create-approved-assignment | PASS | Execute XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Executed |
| create-approved-assignment | PASS | Execute XDX_BIND_ASSIGNMENT_CLIENT_BU | Must execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Executed |
| create-approved-assignment | PASS | Execute XDX_VALID_ASSIGNMENT_CLIENT_BU | Must execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Executed |
| create-approved-assignment | PASS | Execute XDX_ASSIGNMENT_CREATE_RESULT | Must execute | XDX_ASSIGNMENT_CREATE_RESULT | Executed |
| create-approved-assignment | PASS | Skip XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| create-approved-assignment | PASS | Skip XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| create-approved-assignment | PASS | Skip XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| create-approved-assignment | PASS | Skip XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| create-approved-assignment | PASS | Skip XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| create-approved-assignment | PASS | Skip XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| create-approved-assignment | PASS | Skip XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| create-approved-assignment | PASS | Skip XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| create-approved-assignment | PASS | Skip XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| create-approved-assignment | PASS | Skip XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| create-approved-assignment | PASS | Skip XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| create-approved-assignment | PASS | Skip XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| create-approved-assignment | PASS | Skip XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| create-approved-assignment | PASS | Skip XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| create-approved-assignment | PASS | Skip XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| create-approved-assignment | PASS | Skip XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| create-approved-assignment | PASS | Skip XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| create-approved-assignment | PASS | Skip XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| create-approved-assignment | PASS | Skip XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| create-approved-assignment | PASS | Skip XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| create-approved-assignment | PASS | Skip XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| create-approved-assignment | PASS | Skip XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| create-approved-assignment | PASS | Skip XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| create-approved-assignment | PASS | Skip XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| create-approved-assignment | PASS | Skip XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| create-approved-assignment | PASS | Skip XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| create-approved-assignment | PASS | Skip XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| create-approved-assignment | PASS | Skip XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| create-approved-assignment | PASS | Skip XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| create-approved-assignment | PASS | Skip XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| create-approved-assignment | PASS | Skip XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| create-approved-assignment | PASS | Skip XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| create-approved-assignment | PASS | Skip XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| create-approved-assignment | PASS | Skip XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| create-approved-assignment | PASS | Skip XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| create-approved-assignment | PASS | Skip XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| create-approved-assignment | PASS | Skip XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| create-approved-assignment | PASS | Skip XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| create-approved-assignment | PASS | Skip XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| create-approved-assignment | PASS | Skip XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| create-approved-assignment | PASS | Skip XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| create-approved-assignment | PASS | Skip XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| create-approved-assignment | PASS | Skip XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| create-approved-assignment | PASS | Skip XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| create-approved-assignment | PASS | Skip XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| create-approved-assignment | PASS | Skip XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| create-approved-assignment | PASS | Skip XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| create-approved-assignment | PASS | Skip XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| create-approved-assignment | PASS | Skip XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| create-approved-assignment | PASS | Skip XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| create-approved-assignment | PASS | Skip XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| create-approved-assignment | PASS | Skip XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| create-approved-assignment | PASS | Skip XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| create-approved-assignment | PASS | Skip XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| create-approved-assignment | PASS | Skip XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| create-approved-assignment | PASS | Skip XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| create-approved-assignment | PASS | Skip XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| create-approved-assignment | PASS | Skip XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| create-approved-assignment | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| create-approved-assignment | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| create-approved-assignment | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| create-approved-assignment | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| create-approved-assignment | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| create-approved-assignment | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| create-approved-assignment | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| create-approved-assignment | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| create-approved-assignment | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| create-approved-assignment | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| create-approved-assignment | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| create-approved-assignment | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| create-approved-assignment | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| create-approved-assignment | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| create-approved-assignment | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| create-approved-assignment | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| create-approved-assignment | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-assignment | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-assignment | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-assignment | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| create-approved-assignment | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| create-approved-assignment | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| create-approved-assignment | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |

## Node Assertions

| Step | Status | Assertion | Node Code | Occurrence | Asserted Value | Operator | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| prepare-required-assignment | PASS | Assignment draft revision retained | XDX_REDUCE_ASSIGNMENT_DRAFT | last | output/result/state/revision | equals | 1 | number |
| review-assignment-references | PASS | Reviewed reference 0 | XDX_BIND_ASSIGNMENT_REFERENCES | last | output/result/snapshot/supplierId | equals | "300000333814329" | string (15 characters) |
| review-assignment-references | PASS | Reviewed reference 1 | XDX_BIND_ASSIGNMENT_REFERENCES | last | output/result/snapshot/siteId | equals | "300000333814344" | string (15 characters) |
| review-assignment-references | PASS | Reviewed reference 2 | XDX_BIND_ASSIGNMENT_REFERENCES | last | output/result/snapshot/payload/ClientBUId | equals | 300000046987012 | number |
| review-assignment-references | PASS | Reviewed reference 3 | XDX_BIND_ASSIGNMENT_REFERENCES | last | output/result/snapshot/payload/BillToBUId | equals | 300000046987012 | number |
| approve-exact-assignment | PASS | Current assignment revision approved | XDX_REDUCE_ASSIGNMENT_DRAFT | last | output/result/state/approvedRevision | equals | 1 | number |
| create-approved-assignment | PASS | Assignment persisted values confirmed | XDX_CONFIRM_ASSIGNMENT_CREATE | last | output/result/confirmed | equals | true | boolean |

## Workflow Run Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-assignment | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| review-assignment-references | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| approve-exact-assignment | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| create-approved-assignment | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| Conversation | PASS | conversationStepOrder | conversationStepOrder | prepare-required-assignment -> review-assignment-references -> approve-exact-assignment -> create-approved-assignment | Verified |
| Conversation | PASS | conversationIdReuse | conversationIdReuse | Every executed step uses one conversation ID. | Verified |

## Output Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-assignment | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| prepare-required-assignment | PASS | Retained field 0 | contains | XDX Lifecycle Retry 20260923 A | Found "XDX Lifecycle Retry 20260923 A" |
| prepare-required-assignment | PASS | Retained field 1 | contains | XDX SITE Retry 20260923 A | Found "XDX SITE Retry 20260923 A" |
| prepare-required-assignment | PASS | Retained field 2 | contains | US1 Business Unit | Found "US1 Business Unit" |
| review-assignment-references | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| review-assignment-references | PASS | Approval instruction | contains | Approve site-assignment revision 1 | Found "Approve site-assignment revision 1" |
| approve-exact-assignment | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| approve-exact-assignment | PASS | Create instruction | contains | Create site-assignment revision 1 | Found "Create site-assignment revision 1" |
| create-approved-assignment | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| create-approved-assignment | PASS | Persisted assignment | contains | Site assignment created and independently verified | Found "Site assignment created and independently verified" |

## Runtime Metrics

Workflow time: 11495 ms (sum of node times)
Test run time: 19322 ms (includes CLI overhead)
Token usage: observed from runtime events

Aggregate Token Usage

| Input Tokens | Output Tokens | Total Tokens | Model |
| --- | --- | --- | --- |
| 18136 | 2125 | 20261 | oci-agent/openai.gpt-4.1-mini-2025-04-14 |

| Node | Input Tokens | Output Tokens | Total Tokens | Model | Source |
| --- | --- | --- | --- | --- | --- |
| approve-exact-assignment:XDX_EXTRACT_SEARCH | 4624 | 529 | 5153 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| create-approved-assignment:XDX_EXTRACT_SEARCH | 4791 | 529 | 5320 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| prepare-required-assignment:XDX_EXTRACT_SEARCH | 4281 | 529 | 4810 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| review-assignment-references:XDX_EXTRACT_SEARCH | 4440 | 538 | 4978 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |


AI Units: computed
Total Token Units: 4
Total AI Units: 20

| Node | Input | Output | Token Units | AI Units | Model Type | Action Type |
| --- | --- | --- | --- | --- | --- | --- |
| approve-exact-assignment:XDX_EXTRACT_SEARCH | 4624 | 529 | 1 | 5 | premium | general |
| create-approved-assignment:XDX_EXTRACT_SEARCH | 4791 | 529 | 1 | 5 | premium | general |
| prepare-required-assignment:XDX_EXTRACT_SEARCH | 4281 | 529 | 1 | 5 | premium | general |
| review-assignment-references:XDX_EXTRACT_SEARCH | 4440 | 538 | 1 | 5 | premium | general |

| Node | Node Time (ms) | LLM Call Time (ms) | Details |
| --- | --- | --- | --- |
| prepare-required-assignment:XDX_EXTRACT_SEARCH | 2498 | 2412 | 1 runtime detail; see JSON report |
| review-assignment-references:XDX_EXTRACT_SEARCH | 2801 | 2722 | 1 runtime detail; see JSON report |
| review-assignment-references:XDX_RESOLVE_ASSIGNMENT_PARENT | 47 |  | 0 runtime details; see JSON report |
| review-assignment-references:XDX_RESOLVE_ASSIGNMENT_SITE | 45 |  | 0 runtime details; see JSON report |
| review-assignment-references:XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | 18 |  | 0 runtime details; see JSON report |
| review-assignment-references:XDX_RESOLVE_ASSIGNMENT_BILL_BU | 46 |  | 0 runtime details; see JSON report |
| approve-exact-assignment:XDX_EXTRACT_SEARCH | 2576 | 2438 | 1 runtime detail; see JSON report |
| create-approved-assignment:XDX_EXTRACT_SEARCH | 3143 | 3053 | 1 runtime detail; see JSON report |
| create-approved-assignment:XDX_RESOLVE_ASSIGNMENT_PARENT | 45 |  | 0 runtime details; see JSON report |
| create-approved-assignment:XDX_RESOLVE_ASSIGNMENT_SITE | 46 |  | 0 runtime details; see JSON report |
| create-approved-assignment:XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | 45 |  | 0 runtime details; see JSON report |
| create-approved-assignment:XDX_RESOLVE_ASSIGNMENT_BILL_BU | 45 |  | 0 runtime details; see JSON report |
| create-approved-assignment:XDX_CHECK_ASSIGNMENT_DUPLICATE | 46 |  | 0 runtime details; see JSON report |
| create-approved-assignment:XDX_CREATE_ASSIGNMENT | 49 |  | 0 runtime details; see JSON report |
| create-approved-assignment:XDX_VERIFY_ASSIGNMENT | 45 |  | 0 runtime details; see JSON report |

| Observed Field | Values |
| --- | --- |
| modelName | "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14" |
| inputTokens | 4281; 4440; 4624; 4791 |
| outputTokens | 529; 538; 529; 529 |

## Test Data

| Step | Data Source | Evaluation |
| --- | --- | --- |
| prepare-required-assignment | File replay | Deterministic |
| review-assignment-references | File replay | Deterministic |
| approve-exact-assignment | File replay | Deterministic |
| create-approved-assignment | File replay | Deterministic |

## Workflow Run

### Execution Timeline

| Step | Phase Sequence | Node | Event |
| --- | --- | --- | --- |
| prepare-required-assignment | 1 | START | NODE_EXECUTED |
| prepare-required-assignment | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| prepare-required-assignment | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| prepare-required-assignment | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| prepare-required-assignment | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| prepare-required-assignment | 6 | XDX_REDUCE_ASSIGNMENT_DRAFT | NODE_EXECUTED |
| prepare-required-assignment | 7 | XDX_SAVE_ASSIGNMENT_DRAFT | NODE_EXECUTED |
| prepare-required-assignment | 8 | XDX_ASSIGNMENT_NEEDS_REFERENCES | NODE_EXECUTED |
| prepare-required-assignment | 9 | XDX_ASSIGNMENT_DRAFT_RESPONSE | NODE_EXECUTED |
| review-assignment-references | 1 | START | NODE_EXECUTED |
| review-assignment-references | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| review-assignment-references | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| review-assignment-references | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| review-assignment-references | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| review-assignment-references | 6 | XDX_REDUCE_ASSIGNMENT_DRAFT | NODE_EXECUTED |
| review-assignment-references | 7 | XDX_SAVE_ASSIGNMENT_DRAFT | NODE_EXECUTED |
| review-assignment-references | 8 | XDX_ASSIGNMENT_NEEDS_REFERENCES | NODE_EXECUTED |
| review-assignment-references | 9 | XDX_RESOLVE_ASSIGNMENT_PARENT | NODE_START |
| review-assignment-references | 10 | XDX_BIND_ASSIGNMENT_PARENT | NODE_EXECUTED |
| review-assignment-references | 11 | XDX_VALID_ASSIGNMENT_PARENT | NODE_EXECUTED |
| review-assignment-references | 12 | XDX_RESOLVE_ASSIGNMENT_SITE | NODE_START |
| review-assignment-references | 13 | XDX_BIND_ASSIGNMENT_SITE | NODE_EXECUTED |
| review-assignment-references | 14 | XDX_VALID_ASSIGNMENT_SITE | NODE_EXECUTED |
| review-assignment-references | 15 | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | NODE_START |
| review-assignment-references | 16 | XDX_BIND_ASSIGNMENT_CLIENT_BU | NODE_EXECUTED |
| review-assignment-references | 17 | XDX_VALID_ASSIGNMENT_CLIENT_BU | NODE_EXECUTED |
| review-assignment-references | 18 | XDX_RESOLVE_ASSIGNMENT_BILL_BU | NODE_START |
| review-assignment-references | 19 | XDX_BIND_ASSIGNMENT_REFERENCES | NODE_EXECUTED |
| review-assignment-references | 20 | XDX_VALID_ASSIGNMENT_REFERENCES | NODE_EXECUTED |
| review-assignment-references | 21 | XDX_ASSIGNMENT_IS_REVIEW | NODE_EXECUTED |
| review-assignment-references | 22 | XDX_SAVE_ASSIGNMENT_REVIEW | NODE_EXECUTED |
| review-assignment-references | 23 | XDX_ASSIGNMENT_REVIEW_RESPONSE | NODE_EXECUTED |
| approve-exact-assignment | 1 | START | NODE_EXECUTED |
| approve-exact-assignment | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| approve-exact-assignment | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| approve-exact-assignment | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| approve-exact-assignment | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| approve-exact-assignment | 6 | XDX_REDUCE_ASSIGNMENT_DRAFT | NODE_EXECUTED |
| approve-exact-assignment | 7 | XDX_SAVE_ASSIGNMENT_DRAFT | NODE_EXECUTED |
| approve-exact-assignment | 8 | XDX_ASSIGNMENT_NEEDS_REFERENCES | NODE_EXECUTED |
| approve-exact-assignment | 9 | XDX_ASSIGNMENT_DRAFT_RESPONSE | NODE_EXECUTED |
| create-approved-assignment | 1 | START | NODE_EXECUTED |
| create-approved-assignment | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| create-approved-assignment | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| create-approved-assignment | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| create-approved-assignment | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| create-approved-assignment | 6 | XDX_REDUCE_ASSIGNMENT_DRAFT | NODE_EXECUTED |
| create-approved-assignment | 7 | XDX_SAVE_ASSIGNMENT_DRAFT | NODE_EXECUTED |
| create-approved-assignment | 8 | XDX_ASSIGNMENT_NEEDS_REFERENCES | NODE_EXECUTED |
| create-approved-assignment | 9 | XDX_RESOLVE_ASSIGNMENT_PARENT | NODE_START |
| create-approved-assignment | 10 | XDX_BIND_ASSIGNMENT_PARENT | NODE_EXECUTED |
| create-approved-assignment | 11 | XDX_VALID_ASSIGNMENT_PARENT | NODE_EXECUTED |
| create-approved-assignment | 12 | XDX_RESOLVE_ASSIGNMENT_SITE | NODE_START |
| create-approved-assignment | 13 | XDX_BIND_ASSIGNMENT_SITE | NODE_EXECUTED |
| create-approved-assignment | 14 | XDX_VALID_ASSIGNMENT_SITE | NODE_EXECUTED |
| create-approved-assignment | 15 | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | NODE_START |
| create-approved-assignment | 16 | XDX_BIND_ASSIGNMENT_CLIENT_BU | NODE_EXECUTED |
| create-approved-assignment | 17 | XDX_VALID_ASSIGNMENT_CLIENT_BU | NODE_EXECUTED |
| create-approved-assignment | 18 | XDX_RESOLVE_ASSIGNMENT_BILL_BU | NODE_START |
| create-approved-assignment | 19 | XDX_BIND_ASSIGNMENT_REFERENCES | NODE_EXECUTED |
| create-approved-assignment | 20 | XDX_VALID_ASSIGNMENT_REFERENCES | NODE_EXECUTED |
| create-approved-assignment | 21 | XDX_ASSIGNMENT_IS_REVIEW | NODE_EXECUTED |
| create-approved-assignment | 22 | XDX_CHECK_ASSIGNMENT_DUPLICATE | NODE_START |
| create-approved-assignment | 23 | XDX_DECIDE_ASSIGNMENT_CREATE | NODE_EXECUTED |
| create-approved-assignment | 24 | XDX_CAN_POST_ASSIGNMENT | NODE_EXECUTED |
| create-approved-assignment | 25 | XDX_SAVE_ASSIGNMENT_ATTEMPT | NODE_EXECUTED |
| create-approved-assignment | 26 | XDX_CREATE_ASSIGNMENT | NODE_START |
| create-approved-assignment | 27 | XDX_VERIFY_ASSIGNMENT | NODE_START |
| create-approved-assignment | 28 | XDX_CONFIRM_ASSIGNMENT_CREATE | NODE_EXECUTED |
| create-approved-assignment | 29 | XDX_SAVE_ASSIGNMENT_CONFIRMATION | NODE_EXECUTED |
| create-approved-assignment | 30 | XDX_ASSIGNMENT_CREATE_RESULT | NODE_EXECUTED |

### Other Observed Nodes

| Node | Observed |
| --- | --- |
| START | 4 |
| XDX_ASSIGNMENT_CREATE_RESULT | 1 |
| XDX_ASSIGNMENT_DRAFT_RESPONSE | 2 |
| XDX_ASSIGNMENT_IS_REVIEW | 2 |
| XDX_ASSIGNMENT_NEEDS_REFERENCES | 4 |
| XDX_ASSIGNMENT_REVIEW_RESPONSE | 1 |
| XDX_BIND_ASSIGNMENT_CLIENT_BU | 2 |
| XDX_BIND_ASSIGNMENT_PARENT | 2 |
| XDX_BIND_ASSIGNMENT_REFERENCES | 2 |
| XDX_BIND_ASSIGNMENT_SITE | 2 |
| XDX_CAN_POST_ASSIGNMENT | 1 |
| XDX_CHECK_ASSIGNMENT_DUPLICATE | 1 |
| XDX_CONFIRM_ASSIGNMENT_CREATE | 1 |
| XDX_DECIDE_ASSIGNMENT_CREATE | 1 |
| XDX_EXTRACT_SEARCH | 4 |
| XDX_NORMALIZE_REQUEST | 4 |
| XDX_REDUCE_ASSIGNMENT_DRAFT | 4 |
| XDX_RESOLVE_ASSIGNMENT_BILL_BU | 2 |
| XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | 2 |
| XDX_RESOLVE_ASSIGNMENT_PARENT | 2 |
| XDX_RESOLVE_ASSIGNMENT_SITE | 2 |
| XDX_ROUTE_APP_STAGE | 4 |
| XDX_ROUTE_REQUEST_INTENT | 4 |
| XDX_SAVE_ASSIGNMENT_ATTEMPT | 1 |
| XDX_SAVE_ASSIGNMENT_CONFIRMATION | 1 |
| XDX_SAVE_ASSIGNMENT_DRAFT | 4 |
| XDX_SAVE_ASSIGNMENT_REVIEW | 1 |
| XDX_VALID_ASSIGNMENT_CLIENT_BU | 2 |
| XDX_VALID_ASSIGNMENT_PARENT | 2 |
| XDX_VALID_ASSIGNMENT_REFERENCES | 2 |
| XDX_VALID_ASSIGNMENT_SITE | 2 |
| XDX_VERIFY_ASSIGNMENT | 1 |

## Report Files

- JSON report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-site-assignment-create\result.json`
- Markdown report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-site-assignment-create\result.md`
- Test file: `test/workflows/xdx_supplier_lifecycle_agent/xdx-site-assignment-create.json`
