# Workflow Conversation Test Result: xdx-site-create

**Status:** PASSED
**Workflow:** XDX_SUPPLIER_LIFECYCLE_AGENT (DRAFT v86153667)
**Goal:** Review and approve the exact four-field purchasing site and stable parent/address/BU references before creating once.
**Data Source:** File replay
**Evaluation:** Deterministic
**Steps:** 4

## Conversation Journey

| # | Step | Type | Intent | Interaction | Outcome | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | prepare-required-site | chat | Prepare a new site draft named XDX SITE Retry 20260923 A for supplier XDX Lifecycle Retry 20260923 A. Use procurement business unit US1 Business Unit and supplier address XDX HQ Retry 20260923 A. Set purchasing purpose true. | Prepare a new site draft named XDX SITE Retry 20260923 A for supplier XDX Lifecycle Retry 20260923 A. Use procurement business unit US1 Business Unit and supplier address XDX HQ Retry 20260923 A. Set purchasing purpose true. | <oraInfoDisplay key="site-review">{"patternId":"multiRecordWidget","title":"Site draft revision 1","description":"Site draft saved. No site has been created.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Site name","XDX SITE Retry 20260923 A"]},{"cells":["Procurement business unit","US1 Business Unit"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]},{"cells":["Purchasing purpose","Yes"]}]}}</oraInfoDisplay> | passed |
| 2 | review-site-references | chat | Review the exact site draft. | Review the exact site draft. | <oraInfoDisplay key="site-review">{"patternId":"multiRecordWidget","title":"Site draft revision 1","description":"Review the resolved supplier, address and business unit with this exact four-field site payload. To approve without writing, enter: Approve site revision 1.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Site name","XDX SITE Retry 20260923 A"]},{"cells":["Procurement business unit","US1 Business Unit"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]},{"cells":["Purchasing purpose","Yes"]}]}}</oraInfoDisplay> | passed |
| 3 | approve-exact-site | chat | Approve site revision 1 | Approve site revision 1 | <oraInfoDisplay key="site-review">{"patternId":"multiRecordWidget","title":"Site draft revision 1","description":"Site revision 1 approved without writing. To create exactly this reviewed site, enter: Create site revision 1.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Site name","XDX SITE Retry 20260923 A"]},{"cells":["Procurement business unit","US1 Business Unit"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]},{"cells":["Purchasing purpose","Yes"]}]}}</oraInfoDisplay> | passed |
| 4 | create-approved-site | chat | Create site revision 1 | Create site revision 1 | <oraInfoDisplay key="site-review">{"patternId":"multiRecordWidget","title":"Site draft revision 1","description":"Site created and independently verified with the approved supplier, address and business unit.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Site name","XDX SITE Retry 20260923 A"]},{"cells":["Procurement business unit","US1 Business Unit"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]},{"cells":["Purchasing purpose","Yes"]}]}}</oraInfoDisplay> | passed |

## Step 1: prepare-required-site

**Status:** passed
**Type:** chat
**Intent:** Prepare a new site draft named XDX SITE Retry 20260923 A for supplier XDX Lifecycle Retry 20260923 A. Use procurement business unit US1 Business Unit and supplier address XDX HQ Retry 20260923 A. Set purchasing purpose true.
**Context Step IDs:** None (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Prepare a new site draft named XDX SITE Retry 20260923 A for supplier XDX Lifecycle Retry 20260923 A. Use procurement business unit US1 Business Unit and supplier address XDX HQ Retry 20260923 A. Set purchasing purpose true.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="site-review">{"patternId":"multiRecordWidget","title":"Site draft revision 1","description":"Site draft saved. No site has been created.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Site name","XDX SITE Retry 20260923 A"]},{"cells":["Procurement business unit","US1 Business Unit"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]},{"cells":["Purchasing purpose","Yes"]}]}}</oraInfoDisplay>
~~~

## Step 2: review-site-references

**Status:** passed
**Type:** chat
**Intent:** Review the exact site draft.
**Context Step IDs:** prepare-required-site (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Review the exact site draft.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="site-review">{"patternId":"multiRecordWidget","title":"Site draft revision 1","description":"Review the resolved supplier, address and business unit with this exact four-field site payload. To approve without writing, enter: Approve site revision 1.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Site name","XDX SITE Retry 20260923 A"]},{"cells":["Procurement business unit","US1 Business Unit"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]},{"cells":["Purchasing purpose","Yes"]}]}}</oraInfoDisplay>
~~~

## Step 3: approve-exact-site

**Status:** passed
**Type:** chat
**Intent:** Approve site revision 1
**Context Step IDs:** prepare-required-site, review-site-references (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Approve site revision 1",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="site-review">{"patternId":"multiRecordWidget","title":"Site draft revision 1","description":"Site revision 1 approved without writing. To create exactly this reviewed site, enter: Create site revision 1.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Site name","XDX SITE Retry 20260923 A"]},{"cells":["Procurement business unit","US1 Business Unit"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]},{"cells":["Purchasing purpose","Yes"]}]}}</oraInfoDisplay>
~~~

## Step 4: create-approved-site

**Status:** passed
**Type:** chat
**Intent:** Create site revision 1
**Context Step IDs:** prepare-required-site, review-site-references, approve-exact-site (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Create site revision 1",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraAppContext": "",
    "OraUserContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="site-review">{"patternId":"multiRecordWidget","title":"Site draft revision 1","description":"Site created and independently verified with the approved supplier, address and business unit.","properties":{"cols":["Field","Value"],"selectMode":"none","rows":[{"cells":["Supplier","XDX Lifecycle Retry 20260923 A"]},{"cells":["Site name","XDX SITE Retry 20260923 A"]},{"cells":["Procurement business unit","US1 Business Unit"]},{"cells":["Supplier address","XDX HQ Retry 20260923 A"]},{"cells":["Purchasing purpose","Yes"]}]}}</oraInfoDisplay>
~~~

## Verification Summary

| Verification | Status | Result |
| --- | --- | --- |
| Node order and counts | PASSED | 5/5 passed |
| Path assertions | PASSED | 996/996 passed |
| Node assertions | PASSED | 5/5 passed |
| Workflow run checks | PASSED | 6/6 passed |
| Output checks | PASSED | 12/12 passed |

## Node Order and Count

### Required Relative Order

Other nodes may execute between the listed nodes.

| Step | Status | Assertion | Required Relative Order | Observed or Failure |
| --- | --- | --- | --- | --- |
| prepare-required-site | PASS | Review before write and verification | XDX_REDUCE_SITE_DRAFT -> XDX_SITE_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SITE_DRAFT -> XDX_SAVE_SITE_DRAFT -> XDX_SITE_NEEDS_REFERENCES -> XDX_SITE_DRAFT_RESPONSE |
| review-site-references | PASS | Review before write and verification | XDX_REDUCE_SITE_DRAFT -> XDX_BIND_SITE_REFERENCES -> XDX_SAVE_SITE_REVIEW -> XDX_SITE_REVIEW_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SITE_DRAFT -> XDX_SAVE_SITE_DRAFT -> XDX_SITE_NEEDS_REFERENCES -> XDX_RESOLVE_SITE_PARENT -> XDX_BIND_SITE_PARENT -> XDX_VALID_SITE_PARENT -> XDX_RESOLVE_SITE_ADDRESS -> XDX_BIND_SITE_ADDRESS -> XDX_VALID_SITE_ADDRESS -> XDX_RESOLVE_SITE_BU -> XDX_BIND_SITE_REFERENCES -> XDX_VALID_SITE_REFERENCES -> XDX_SITE_IS_REVIEW -> XDX_SAVE_SITE_REVIEW -> XDX_SITE_REVIEW_RESPONSE |
| approve-exact-site | PASS | Review before write and verification | XDX_REDUCE_SITE_DRAFT -> XDX_SITE_DRAFT_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SITE_DRAFT -> XDX_SAVE_SITE_DRAFT -> XDX_SITE_NEEDS_REFERENCES -> XDX_SITE_DRAFT_RESPONSE |
| create-approved-site | PASS | Review before write and verification | XDX_REDUCE_SITE_DRAFT -> XDX_BIND_SITE_REFERENCES -> XDX_SAVE_SITE_ATTEMPT -> XDX_CREATE_SITE -> XDX_VERIFY_SITE -> XDX_CONFIRM_SITE_CREATE -> XDX_SITE_CREATE_RESULT | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_REDUCE_SITE_DRAFT -> XDX_SAVE_SITE_DRAFT -> XDX_SITE_NEEDS_REFERENCES -> XDX_RESOLVE_SITE_PARENT -> XDX_BIND_SITE_PARENT -> XDX_VALID_SITE_PARENT -> XDX_RESOLVE_SITE_ADDRESS -> XDX_BIND_SITE_ADDRESS -> XDX_VALID_SITE_ADDRESS -> XDX_RESOLVE_SITE_BU -> XDX_BIND_SITE_REFERENCES -> XDX_VALID_SITE_REFERENCES -> XDX_SITE_IS_REVIEW -> XDX_CHECK_SITE_DUPLICATE -> XDX_DECIDE_SITE_CREATE -> XDX_CAN_POST_SITE -> XDX_SAVE_SITE_ATTEMPT -> XDX_CREATE_SITE -> XDX_VERIFY_SITE -> XDX_CONFIRM_SITE_CREATE -> XDX_SAVE_SITE_CONFIRMATION -> XDX_SITE_CREATE_RESULT |

### Node Count Checks

| Step | Assertion | Node Code | Expected | Observed | Status |
| --- | --- | --- | --- | --- | --- |
| create-approved-site | One site POST node | XDX_CREATE_SITE | exactly 1 | 1 | PASS |

## Path Assertions

| Step | Status | Assertion | Requirement | Node Code | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-site | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| prepare-required-site | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| prepare-required-site | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| prepare-required-site | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| prepare-required-site | PASS | Execute XDX_REDUCE_SITE_DRAFT | Must execute | XDX_REDUCE_SITE_DRAFT | Executed |
| prepare-required-site | PASS | Execute XDX_SAVE_SITE_DRAFT | Must execute | XDX_SAVE_SITE_DRAFT | Executed |
| prepare-required-site | PASS | Execute XDX_SITE_NEEDS_REFERENCES | Must execute | XDX_SITE_NEEDS_REFERENCES | Executed |
| prepare-required-site | PASS | Execute XDX_SITE_DRAFT_RESPONSE | Must execute | XDX_SITE_DRAFT_RESPONSE | Executed |
| prepare-required-site | PASS | Skip XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| prepare-required-site | PASS | Skip XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| prepare-required-site | PASS | Skip XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| prepare-required-site | PASS | Skip XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| prepare-required-site | PASS | Skip XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| prepare-required-site | PASS | Skip XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| prepare-required-site | PASS | Skip XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| prepare-required-site | PASS | Skip XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| prepare-required-site | PASS | Skip XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| prepare-required-site | PASS | Skip XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| prepare-required-site | PASS | Skip XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| prepare-required-site | PASS | Skip XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| prepare-required-site | PASS | Skip XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| prepare-required-site | PASS | Skip XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| prepare-required-site | PASS | Skip XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| prepare-required-site | PASS | Skip XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| prepare-required-site | PASS | Skip XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| prepare-required-site | PASS | Skip XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| prepare-required-site | PASS | Skip XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| prepare-required-site | PASS | Skip XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| prepare-required-site | PASS | Skip XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| prepare-required-site | PASS | Skip XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| prepare-required-site | PASS | Skip XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| prepare-required-site | PASS | Skip XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| prepare-required-site | PASS | Skip XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| prepare-required-site | PASS | Skip XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| prepare-required-site | PASS | Skip XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| prepare-required-site | PASS | Skip XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| prepare-required-site | PASS | Skip XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| prepare-required-site | PASS | Skip XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| prepare-required-site | PASS | Skip XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| prepare-required-site | PASS | Skip XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| prepare-required-site | PASS | Skip XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| prepare-required-site | PASS | Skip XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| prepare-required-site | PASS | Skip XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| prepare-required-site | PASS | Skip XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| prepare-required-site | PASS | Skip XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| prepare-required-site | PASS | Skip XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| prepare-required-site | PASS | Skip XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| prepare-required-site | PASS | Skip XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| prepare-required-site | PASS | Skip XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| prepare-required-site | PASS | Skip XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| prepare-required-site | PASS | Skip XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| prepare-required-site | PASS | Skip XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| prepare-required-site | PASS | Skip XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| prepare-required-site | PASS | Skip XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| prepare-required-site | PASS | Skip XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| prepare-required-site | PASS | Skip XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| prepare-required-site | PASS | Skip XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| prepare-required-site | PASS | Skip XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| prepare-required-site | PASS | Skip XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| prepare-required-site | PASS | Skip XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| prepare-required-site | PASS | Skip XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| prepare-required-site | PASS | Skip XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| prepare-required-site | PASS | Skip XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| prepare-required-site | PASS | Skip XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| prepare-required-site | PASS | Skip XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| prepare-required-site | PASS | Skip XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| prepare-required-site | PASS | Skip XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| prepare-required-site | PASS | Skip XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| prepare-required-site | PASS | Skip XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| prepare-required-site | PASS | Skip XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| prepare-required-site | PASS | Skip XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| prepare-required-site | PASS | Skip XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| prepare-required-site | PASS | Skip XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| prepare-required-site | PASS | Skip XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| prepare-required-site | PASS | Skip XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| prepare-required-site | PASS | Skip XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| prepare-required-site | PASS | Skip XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| prepare-required-site | PASS | Skip XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| prepare-required-site | PASS | Skip XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| prepare-required-site | PASS | Skip XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| prepare-required-site | PASS | Skip XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| prepare-required-site | PASS | Skip XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| prepare-required-site | PASS | Skip XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| prepare-required-site | PASS | Skip XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| prepare-required-site | PASS | Skip XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| prepare-required-site | PASS | Skip XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| prepare-required-site | PASS | Skip XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| prepare-required-site | PASS | Skip XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| prepare-required-site | PASS | Skip XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| prepare-required-site | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| prepare-required-site | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| prepare-required-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| prepare-required-site | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| prepare-required-site | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| prepare-required-site | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| prepare-required-site | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| prepare-required-site | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| prepare-required-site | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| prepare-required-site | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| prepare-required-site | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| prepare-required-site | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| prepare-required-site | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| prepare-required-site | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| prepare-required-site | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| prepare-required-site | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| prepare-required-site | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| prepare-required-site | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| prepare-required-site | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| prepare-required-site | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-site | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-site | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| prepare-required-site | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| prepare-required-site | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| prepare-required-site | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| prepare-required-site | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| review-site-references | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| review-site-references | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| review-site-references | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| review-site-references | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| review-site-references | PASS | Execute XDX_REDUCE_SITE_DRAFT | Must execute | XDX_REDUCE_SITE_DRAFT | Executed |
| review-site-references | PASS | Execute XDX_SAVE_SITE_DRAFT | Must execute | XDX_SAVE_SITE_DRAFT | Executed |
| review-site-references | PASS | Execute XDX_SITE_NEEDS_REFERENCES | Must execute | XDX_SITE_NEEDS_REFERENCES | Executed |
| review-site-references | PASS | Execute XDX_BIND_SITE_PARENT | Must execute | XDX_BIND_SITE_PARENT | Executed |
| review-site-references | PASS | Execute XDX_VALID_SITE_PARENT | Must execute | XDX_VALID_SITE_PARENT | Executed |
| review-site-references | PASS | Execute XDX_BIND_SITE_ADDRESS | Must execute | XDX_BIND_SITE_ADDRESS | Executed |
| review-site-references | PASS | Execute XDX_VALID_SITE_ADDRESS | Must execute | XDX_VALID_SITE_ADDRESS | Executed |
| review-site-references | PASS | Execute XDX_BIND_SITE_REFERENCES | Must execute | XDX_BIND_SITE_REFERENCES | Executed |
| review-site-references | PASS | Execute XDX_VALID_SITE_REFERENCES | Must execute | XDX_VALID_SITE_REFERENCES | Executed |
| review-site-references | PASS | Execute XDX_SITE_IS_REVIEW | Must execute | XDX_SITE_IS_REVIEW | Executed |
| review-site-references | PASS | Execute XDX_SAVE_SITE_REVIEW | Must execute | XDX_SAVE_SITE_REVIEW | Executed |
| review-site-references | PASS | Execute XDX_RESOLVE_SITE_PARENT | Must execute | XDX_RESOLVE_SITE_PARENT | Executed |
| review-site-references | PASS | Execute XDX_RESOLVE_SITE_ADDRESS | Must execute | XDX_RESOLVE_SITE_ADDRESS | Executed |
| review-site-references | PASS | Execute XDX_RESOLVE_SITE_BU | Must execute | XDX_RESOLVE_SITE_BU | Executed |
| review-site-references | PASS | Execute XDX_SITE_REVIEW_RESPONSE | Must execute | XDX_SITE_REVIEW_RESPONSE | Executed |
| review-site-references | PASS | Skip XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| review-site-references | PASS | Skip XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| review-site-references | PASS | Skip XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| review-site-references | PASS | Skip XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| review-site-references | PASS | Skip XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| review-site-references | PASS | Skip XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| review-site-references | PASS | Skip XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| review-site-references | PASS | Skip XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| review-site-references | PASS | Skip XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| review-site-references | PASS | Skip XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| review-site-references | PASS | Skip XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| review-site-references | PASS | Skip XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| review-site-references | PASS | Skip XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| review-site-references | PASS | Skip XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| review-site-references | PASS | Skip XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| review-site-references | PASS | Skip XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| review-site-references | PASS | Skip XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| review-site-references | PASS | Skip XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| review-site-references | PASS | Skip XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| review-site-references | PASS | Skip XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| review-site-references | PASS | Skip XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| review-site-references | PASS | Skip XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| review-site-references | PASS | Skip XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| review-site-references | PASS | Skip XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| review-site-references | PASS | Skip XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| review-site-references | PASS | Skip XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| review-site-references | PASS | Skip XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| review-site-references | PASS | Skip XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| review-site-references | PASS | Skip XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| review-site-references | PASS | Skip XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| review-site-references | PASS | Skip XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| review-site-references | PASS | Skip XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| review-site-references | PASS | Skip XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| review-site-references | PASS | Skip XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| review-site-references | PASS | Skip XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| review-site-references | PASS | Skip XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| review-site-references | PASS | Skip XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| review-site-references | PASS | Skip XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| review-site-references | PASS | Skip XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| review-site-references | PASS | Skip XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| review-site-references | PASS | Skip XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| review-site-references | PASS | Skip XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| review-site-references | PASS | Skip XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| review-site-references | PASS | Skip XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| review-site-references | PASS | Skip XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| review-site-references | PASS | Skip XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| review-site-references | PASS | Skip XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| review-site-references | PASS | Skip XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| review-site-references | PASS | Skip XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| review-site-references | PASS | Skip XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| review-site-references | PASS | Skip XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| review-site-references | PASS | Skip XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| review-site-references | PASS | Skip XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| review-site-references | PASS | Skip XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| review-site-references | PASS | Skip XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| review-site-references | PASS | Skip XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| review-site-references | PASS | Skip XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| review-site-references | PASS | Skip XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| review-site-references | PASS | Skip XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| review-site-references | PASS | Skip XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| review-site-references | PASS | Skip XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| review-site-references | PASS | Skip XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| review-site-references | PASS | Skip XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| review-site-references | PASS | Skip XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| review-site-references | PASS | Skip XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| review-site-references | PASS | Skip XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| review-site-references | PASS | Skip XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| review-site-references | PASS | Skip XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| review-site-references | PASS | Skip XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| review-site-references | PASS | Skip XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| review-site-references | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| review-site-references | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| review-site-references | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| review-site-references | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| review-site-references | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| review-site-references | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| review-site-references | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| review-site-references | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| review-site-references | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| review-site-references | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| review-site-references | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| review-site-references | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| review-site-references | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| review-site-references | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| review-site-references | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| review-site-references | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| review-site-references | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| review-site-references | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| review-site-references | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| review-site-references | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| review-site-references | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| review-site-references | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| review-site-references | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| review-site-references | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| review-site-references | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| review-site-references | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| approve-exact-site | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| approve-exact-site | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| approve-exact-site | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| approve-exact-site | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| approve-exact-site | PASS | Execute XDX_REDUCE_SITE_DRAFT | Must execute | XDX_REDUCE_SITE_DRAFT | Executed |
| approve-exact-site | PASS | Execute XDX_SAVE_SITE_DRAFT | Must execute | XDX_SAVE_SITE_DRAFT | Executed |
| approve-exact-site | PASS | Execute XDX_SITE_NEEDS_REFERENCES | Must execute | XDX_SITE_NEEDS_REFERENCES | Executed |
| approve-exact-site | PASS | Execute XDX_SITE_DRAFT_RESPONSE | Must execute | XDX_SITE_DRAFT_RESPONSE | Executed |
| approve-exact-site | PASS | Skip XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| approve-exact-site | PASS | Skip XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| approve-exact-site | PASS | Skip XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| approve-exact-site | PASS | Skip XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| approve-exact-site | PASS | Skip XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| approve-exact-site | PASS | Skip XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| approve-exact-site | PASS | Skip XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| approve-exact-site | PASS | Skip XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| approve-exact-site | PASS | Skip XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| approve-exact-site | PASS | Skip XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| approve-exact-site | PASS | Skip XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| approve-exact-site | PASS | Skip XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| approve-exact-site | PASS | Skip XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| approve-exact-site | PASS | Skip XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| approve-exact-site | PASS | Skip XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| approve-exact-site | PASS | Skip XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| approve-exact-site | PASS | Skip XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| approve-exact-site | PASS | Skip XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| approve-exact-site | PASS | Skip XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| approve-exact-site | PASS | Skip XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| approve-exact-site | PASS | Skip XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| approve-exact-site | PASS | Skip XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| approve-exact-site | PASS | Skip XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| approve-exact-site | PASS | Skip XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| approve-exact-site | PASS | Skip XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| approve-exact-site | PASS | Skip XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| approve-exact-site | PASS | Skip XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| approve-exact-site | PASS | Skip XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| approve-exact-site | PASS | Skip XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| approve-exact-site | PASS | Skip XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| approve-exact-site | PASS | Skip XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| approve-exact-site | PASS | Skip XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| approve-exact-site | PASS | Skip XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| approve-exact-site | PASS | Skip XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| approve-exact-site | PASS | Skip XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| approve-exact-site | PASS | Skip XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| approve-exact-site | PASS | Skip XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| approve-exact-site | PASS | Skip XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| approve-exact-site | PASS | Skip XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| approve-exact-site | PASS | Skip XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| approve-exact-site | PASS | Skip XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| approve-exact-site | PASS | Skip XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| approve-exact-site | PASS | Skip XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| approve-exact-site | PASS | Skip XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| approve-exact-site | PASS | Skip XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| approve-exact-site | PASS | Skip XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| approve-exact-site | PASS | Skip XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| approve-exact-site | PASS | Skip XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| approve-exact-site | PASS | Skip XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| approve-exact-site | PASS | Skip XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| approve-exact-site | PASS | Skip XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| approve-exact-site | PASS | Skip XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| approve-exact-site | PASS | Skip XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| approve-exact-site | PASS | Skip XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| approve-exact-site | PASS | Skip XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| approve-exact-site | PASS | Skip XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| approve-exact-site | PASS | Skip XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| approve-exact-site | PASS | Skip XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| approve-exact-site | PASS | Skip XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| approve-exact-site | PASS | Skip XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| approve-exact-site | PASS | Skip XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| approve-exact-site | PASS | Skip XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| approve-exact-site | PASS | Skip XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| approve-exact-site | PASS | Skip XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| approve-exact-site | PASS | Skip XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| approve-exact-site | PASS | Skip XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| approve-exact-site | PASS | Skip XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| approve-exact-site | PASS | Skip XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| approve-exact-site | PASS | Skip XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| approve-exact-site | PASS | Skip XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| approve-exact-site | PASS | Skip XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| approve-exact-site | PASS | Skip XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| approve-exact-site | PASS | Skip XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| approve-exact-site | PASS | Skip XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| approve-exact-site | PASS | Skip XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| approve-exact-site | PASS | Skip XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| approve-exact-site | PASS | Skip XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| approve-exact-site | PASS | Skip XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| approve-exact-site | PASS | Skip XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| approve-exact-site | PASS | Skip XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| approve-exact-site | PASS | Skip XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| approve-exact-site | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| approve-exact-site | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| approve-exact-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| approve-exact-site | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| approve-exact-site | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| approve-exact-site | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| approve-exact-site | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| approve-exact-site | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| approve-exact-site | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| approve-exact-site | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| approve-exact-site | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| approve-exact-site | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| approve-exact-site | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| approve-exact-site | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| approve-exact-site | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| approve-exact-site | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| approve-exact-site | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| approve-exact-site | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| approve-exact-site | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| approve-exact-site | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| approve-exact-site | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| approve-exact-site | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| approve-exact-site | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| approve-exact-site | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| approve-exact-site | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| approve-exact-site | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| create-approved-site | PASS | Execute XDX_ROUTE_APP_STAGE | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| create-approved-site | PASS | Execute XDX_EXTRACT_SEARCH | Must execute | XDX_EXTRACT_SEARCH | Executed |
| create-approved-site | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| create-approved-site | PASS | Execute XDX_ROUTE_REQUEST_INTENT | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| create-approved-site | PASS | Execute XDX_REDUCE_SITE_DRAFT | Must execute | XDX_REDUCE_SITE_DRAFT | Executed |
| create-approved-site | PASS | Execute XDX_SAVE_SITE_DRAFT | Must execute | XDX_SAVE_SITE_DRAFT | Executed |
| create-approved-site | PASS | Execute XDX_SITE_NEEDS_REFERENCES | Must execute | XDX_SITE_NEEDS_REFERENCES | Executed |
| create-approved-site | PASS | Execute XDX_BIND_SITE_PARENT | Must execute | XDX_BIND_SITE_PARENT | Executed |
| create-approved-site | PASS | Execute XDX_VALID_SITE_PARENT | Must execute | XDX_VALID_SITE_PARENT | Executed |
| create-approved-site | PASS | Execute XDX_BIND_SITE_ADDRESS | Must execute | XDX_BIND_SITE_ADDRESS | Executed |
| create-approved-site | PASS | Execute XDX_VALID_SITE_ADDRESS | Must execute | XDX_VALID_SITE_ADDRESS | Executed |
| create-approved-site | PASS | Execute XDX_BIND_SITE_REFERENCES | Must execute | XDX_BIND_SITE_REFERENCES | Executed |
| create-approved-site | PASS | Execute XDX_VALID_SITE_REFERENCES | Must execute | XDX_VALID_SITE_REFERENCES | Executed |
| create-approved-site | PASS | Execute XDX_SITE_IS_REVIEW | Must execute | XDX_SITE_IS_REVIEW | Executed |
| create-approved-site | PASS | Execute XDX_DECIDE_SITE_CREATE | Must execute | XDX_DECIDE_SITE_CREATE | Executed |
| create-approved-site | PASS | Execute XDX_CAN_POST_SITE | Must execute | XDX_CAN_POST_SITE | Executed |
| create-approved-site | PASS | Execute XDX_SAVE_SITE_ATTEMPT | Must execute | XDX_SAVE_SITE_ATTEMPT | Executed |
| create-approved-site | PASS | Execute XDX_CONFIRM_SITE_CREATE | Must execute | XDX_CONFIRM_SITE_CREATE | Executed |
| create-approved-site | PASS | Execute XDX_SAVE_SITE_CONFIRMATION | Must execute | XDX_SAVE_SITE_CONFIRMATION | Executed |
| create-approved-site | PASS | Execute XDX_RESOLVE_SITE_PARENT | Must execute | XDX_RESOLVE_SITE_PARENT | Executed |
| create-approved-site | PASS | Execute XDX_RESOLVE_SITE_ADDRESS | Must execute | XDX_RESOLVE_SITE_ADDRESS | Executed |
| create-approved-site | PASS | Execute XDX_RESOLVE_SITE_BU | Must execute | XDX_RESOLVE_SITE_BU | Executed |
| create-approved-site | PASS | Execute XDX_CHECK_SITE_DUPLICATE | Must execute | XDX_CHECK_SITE_DUPLICATE | Executed |
| create-approved-site | PASS | Execute XDX_CREATE_SITE | Must execute | XDX_CREATE_SITE | Executed |
| create-approved-site | PASS | Execute XDX_VERIFY_SITE | Must execute | XDX_VERIFY_SITE | Executed |
| create-approved-site | PASS | Execute XDX_SITE_CREATE_RESULT | Must execute | XDX_SITE_CREATE_RESULT | Executed |
| create-approved-site | PASS | Skip XDX_INITIAL_DISPLAY | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| create-approved-site | PASS | Skip XDX_PREPARE_SEARCH | Must not execute | XDX_PREPARE_SEARCH | Not executed |
| create-approved-site | PASS | Skip XDX_VALID_SEARCH | Must not execute | XDX_VALID_SEARCH | Not executed |
| create-approved-site | PASS | Skip XDX_REQUEST_SEARCH_NAME | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| create-approved-site | PASS | Skip XDX_FETCH_SUPPLIERS | Must not execute | XDX_FETCH_SUPPLIERS | Not executed |
| create-approved-site | PASS | Skip XDX_QUERY_RESPONSE | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| create-approved-site | PASS | Skip XDX_ROUTE_READ_RESOURCE | Must not execute | XDX_ROUTE_READ_RESOURCE | Not executed |
| create-approved-site | PASS | Skip XDX_RESOLVE_SUPPLIER | Must not execute | XDX_RESOLVE_SUPPLIER | Not executed |
| create-approved-site | PASS | Skip XDX_VALID_PARENT | Must not execute | XDX_VALID_PARENT | Not executed |
| create-approved-site | PASS | Skip XDX_REQUEST_EXACT_PARENT | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| create-approved-site | PASS | Skip XDX_FETCH_ADDRESSES | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| create-approved-site | PASS | Skip XDX_ADDRESS_RESPONSE | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| create-approved-site | PASS | Skip XDX_ROUTE_CHILD_READ | Must not execute | XDX_ROUTE_CHILD_READ | Not executed |
| create-approved-site | PASS | Skip XDX_FETCH_SITES | Must not execute | XDX_FETCH_SITES | Not executed |
| create-approved-site | PASS | Skip XDX_SITE_RESPONSE | Must not execute | XDX_SITE_RESPONSE | Not executed |
| create-approved-site | PASS | Skip XDX_FETCH_CONTACTS | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| create-approved-site | PASS | Skip XDX_CONTACT_RESPONSE | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| create-approved-site | PASS | Skip XDX_REDUCE_SUPPLIER_DRAFT | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| create-approved-site | PASS | Skip XDX_SAVE_SUPPLIER_DRAFT | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| create-approved-site | PASS | Skip XDX_SUPPLIER_DRAFT_RESPONSE | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| create-approved-site | PASS | Skip XDX_PREPARE_SUPPLIER_CREATE | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| create-approved-site | PASS | Skip XDX_VALID_SUPPLIER_CREATE | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| create-approved-site | PASS | Skip XDX_CHECK_SUPPLIER_DUPLICATE | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| create-approved-site | PASS | Skip XDX_DECIDE_SUPPLIER_CREATE | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| create-approved-site | PASS | Skip XDX_CAN_POST_SUPPLIER | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| create-approved-site | PASS | Skip XDX_SAVE_SUPPLIER_ATTEMPT | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| create-approved-site | PASS | Skip XDX_SAVE_SUPPLIER_RECONCILIATION | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| create-approved-site | PASS | Skip XDX_CREATE_SUPPLIER | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| create-approved-site | PASS | Skip XDX_VERIFY_SUPPLIER | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| create-approved-site | PASS | Skip XDX_CONFIRM_SUPPLIER_CREATE | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| create-approved-site | PASS | Skip XDX_SAVE_SUPPLIER_CONFIRMATION | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| create-approved-site | PASS | Skip XDX_SUPPLIER_CREATE_BLOCKED | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| create-approved-site | PASS | Skip XDX_SUPPLIER_CREATE_DECISION | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| create-approved-site | PASS | Skip XDX_SUPPLIER_CREATE_RESULT | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| create-approved-site | PASS | Skip XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| create-approved-site | PASS | Skip XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| create-approved-site | PASS | Skip XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| create-approved-site | PASS | Skip XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| create-approved-site | PASS | Skip XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| create-approved-site | PASS | Skip XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| create-approved-site | PASS | Skip XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| create-approved-site | PASS | Skip XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| create-approved-site | PASS | Skip XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| create-approved-site | PASS | Skip XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| create-approved-site | PASS | Skip XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| create-approved-site | PASS | Skip XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| create-approved-site | PASS | Skip XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| create-approved-site | PASS | Skip XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| create-approved-site | PASS | Skip XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| create-approved-site | PASS | Skip XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| create-approved-site | PASS | Skip XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| create-approved-site | PASS | Skip XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| create-approved-site | PASS | Skip XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| create-approved-site | PASS | Skip XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| create-approved-site | PASS | Skip XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| create-approved-site | PASS | Skip XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| create-approved-site | PASS | Skip XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| create-approved-site | PASS | Skip XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| create-approved-site | PASS | Skip XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| create-approved-site | PASS | Skip XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| create-approved-site | PASS | Skip XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| create-approved-site | PASS | Skip XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| create-approved-site | PASS | Skip XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| create-approved-site | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| create-approved-site | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| create-approved-site | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| create-approved-site | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| create-approved-site | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| create-approved-site | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| create-approved-site | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| create-approved-site | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| create-approved-site | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| create-approved-site | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| create-approved-site | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| create-approved-site | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| create-approved-site | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| create-approved-site | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| create-approved-site | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| create-approved-site | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| create-approved-site | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| create-approved-site | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| create-approved-site | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| create-approved-site | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-site | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-site | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| create-approved-site | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| create-approved-site | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| create-approved-site | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| create-approved-site | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |

## Node Assertions

| Step | Status | Assertion | Node Code | Occurrence | Asserted Value | Operator | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| prepare-required-site | PASS | Site draft revision retained | XDX_REDUCE_SITE_DRAFT | last | output/result/state/revision | equals | 1 | number |
| review-site-references | PASS | Exact BU resolved | XDX_BIND_SITE_REFERENCES | last | output/result/snapshot/payload/ProcurementBUId | equals | 300000046987012 | number |
| review-site-references | PASS | Exact address resolved | XDX_BIND_SITE_REFERENCES | last | output/result/snapshot/addressId | equals | "300000333814336" | string (15 characters) |
| approve-exact-site | PASS | Current site revision approved | XDX_REDUCE_SITE_DRAFT | last | output/result/state/approvedRevision | equals | 1 | number |
| create-approved-site | PASS | Site persisted values confirmed | XDX_CONFIRM_SITE_CREATE | last | output/result/confirmed | equals | true | boolean |

## Workflow Run Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-site | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| review-site-references | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| approve-exact-site | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| create-approved-site | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| Conversation | PASS | conversationStepOrder | conversationStepOrder | prepare-required-site -> review-site-references -> approve-exact-site -> create-approved-site | Verified |
| Conversation | PASS | conversationIdReuse | conversationIdReuse | Every executed step uses one conversation ID. | Verified |

## Output Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| prepare-required-site | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| prepare-required-site | PASS | Site business outcome 1 | contains | XDX SITE Retry 20260923 A | Found "XDX SITE Retry 20260923 A" |
| prepare-required-site | PASS | Site business outcome 2 | contains | XDX Lifecycle Retry 20260923 A | Found "XDX Lifecycle Retry 20260923 A" |
| review-site-references | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| review-site-references | PASS | Site business outcome 1 | contains | Approve site revision 1 | Found "Approve site revision 1" |
| review-site-references | PASS | Site business outcome 2 | contains | XDX HQ Retry 20260923 A | Found "XDX HQ Retry 20260923 A" |
| review-site-references | PASS | Site business outcome 3 | contains | US1 Business Unit | Found "US1 Business Unit" |
| approve-exact-site | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| approve-exact-site | PASS | Site business outcome 1 | contains | Create site revision 1 | Found "Create site revision 1" |
| create-approved-site | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| create-approved-site | PASS | Site business outcome 1 | contains | Site created and independently verified | Found "Site created and independently verified" |
| create-approved-site | PASS | Site business outcome 2 | contains | XDX SITE Retry 20260923 A | Found "XDX SITE Retry 20260923 A" |

## Runtime Metrics

Workflow time: 10186 ms (sum of node times)
Test run time: 17518 ms (includes CLI overhead)
Token usage: observed from runtime events

Aggregate Token Usage

| Input Tokens | Output Tokens | Total Tokens | Model |
| --- | --- | --- | --- |
| 18205 | 2133 | 20338 | oci-agent/openai.gpt-4.1-mini-2025-04-14 |

| Node | Input Tokens | Output Tokens | Total Tokens | Model | Source |
| --- | --- | --- | --- | --- | --- |
| approve-exact-site:XDX_EXTRACT_SEARCH | 4643 | 501 | 5144 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| create-approved-site:XDX_EXTRACT_SEARCH | 4822 | 532 | 5354 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| prepare-required-site:XDX_EXTRACT_SEARCH | 4286 | 559 | 4845 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| review-site-references:XDX_EXTRACT_SEARCH | 4454 | 541 | 4995 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |


AI Units: computed
Total Token Units: 4
Total AI Units: 20

| Node | Input | Output | Token Units | AI Units | Model Type | Action Type |
| --- | --- | --- | --- | --- | --- | --- |
| approve-exact-site:XDX_EXTRACT_SEARCH | 4643 | 501 | 1 | 5 | premium | general |
| create-approved-site:XDX_EXTRACT_SEARCH | 4822 | 532 | 1 | 5 | premium | general |
| prepare-required-site:XDX_EXTRACT_SEARCH | 4286 | 559 | 1 | 5 | premium | general |
| review-site-references:XDX_EXTRACT_SEARCH | 4454 | 541 | 1 | 5 | premium | general |

| Node | Node Time (ms) | LLM Call Time (ms) | Details |
| --- | --- | --- | --- |
| prepare-required-site:XDX_EXTRACT_SEARCH | 2560 | 2460 | 1 runtime detail; see JSON report |
| review-site-references:XDX_EXTRACT_SEARCH | 2496 | 2392 | 1 runtime detail; see JSON report |
| review-site-references:XDX_RESOLVE_SITE_PARENT | 46 |  | 0 runtime details; see JSON report |
| review-site-references:XDX_RESOLVE_SITE_ADDRESS | 45 |  | 0 runtime details; see JSON report |
| review-site-references:XDX_RESOLVE_SITE_BU | 16 |  | 0 runtime details; see JSON report |
| approve-exact-site:XDX_EXTRACT_SEARCH | 2335 | 2229 | 1 runtime detail; see JSON report |
| create-approved-site:XDX_EXTRACT_SEARCH | 2418 | 2273 | 1 runtime detail; see JSON report |
| create-approved-site:XDX_RESOLVE_SITE_PARENT | 45 |  | 0 runtime details; see JSON report |
| create-approved-site:XDX_RESOLVE_SITE_ADDRESS | 45 |  | 0 runtime details; see JSON report |
| create-approved-site:XDX_RESOLVE_SITE_BU | 45 |  | 0 runtime details; see JSON report |
| create-approved-site:XDX_CHECK_SITE_DUPLICATE | 45 |  | 0 runtime details; see JSON report |
| create-approved-site:XDX_CREATE_SITE | 45 |  | 0 runtime details; see JSON report |
| create-approved-site:XDX_VERIFY_SITE | 45 |  | 0 runtime details; see JSON report |

| Observed Field | Values |
| --- | --- |
| modelName | "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14" |
| inputTokens | 4286; 4454; 4643; 4822 |
| outputTokens | 559; 541; 501; 532 |

## Test Data

| Step | Data Source | Evaluation |
| --- | --- | --- |
| prepare-required-site | File replay | Deterministic |
| review-site-references | File replay | Deterministic |
| approve-exact-site | File replay | Deterministic |
| create-approved-site | File replay | Deterministic |

## Workflow Run

### Execution Timeline

| Step | Phase Sequence | Node | Event |
| --- | --- | --- | --- |
| prepare-required-site | 1 | START | NODE_EXECUTED |
| prepare-required-site | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| prepare-required-site | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| prepare-required-site | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| prepare-required-site | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| prepare-required-site | 6 | XDX_REDUCE_SITE_DRAFT | NODE_EXECUTED |
| prepare-required-site | 7 | XDX_SAVE_SITE_DRAFT | NODE_EXECUTED |
| prepare-required-site | 8 | XDX_SITE_NEEDS_REFERENCES | NODE_EXECUTED |
| prepare-required-site | 9 | XDX_SITE_DRAFT_RESPONSE | NODE_EXECUTED |
| review-site-references | 1 | START | NODE_EXECUTED |
| review-site-references | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| review-site-references | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| review-site-references | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| review-site-references | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| review-site-references | 6 | XDX_REDUCE_SITE_DRAFT | NODE_EXECUTED |
| review-site-references | 7 | XDX_SAVE_SITE_DRAFT | NODE_EXECUTED |
| review-site-references | 8 | XDX_SITE_NEEDS_REFERENCES | NODE_EXECUTED |
| review-site-references | 9 | XDX_RESOLVE_SITE_PARENT | NODE_START |
| review-site-references | 10 | XDX_BIND_SITE_PARENT | NODE_EXECUTED |
| review-site-references | 11 | XDX_VALID_SITE_PARENT | NODE_EXECUTED |
| review-site-references | 12 | XDX_RESOLVE_SITE_ADDRESS | NODE_START |
| review-site-references | 13 | XDX_BIND_SITE_ADDRESS | NODE_EXECUTED |
| review-site-references | 14 | XDX_VALID_SITE_ADDRESS | NODE_EXECUTED |
| review-site-references | 15 | XDX_RESOLVE_SITE_BU | NODE_START |
| review-site-references | 16 | XDX_BIND_SITE_REFERENCES | NODE_EXECUTED |
| review-site-references | 17 | XDX_VALID_SITE_REFERENCES | NODE_EXECUTED |
| review-site-references | 18 | XDX_SITE_IS_REVIEW | NODE_EXECUTED |
| review-site-references | 19 | XDX_SAVE_SITE_REVIEW | NODE_EXECUTED |
| review-site-references | 20 | XDX_SITE_REVIEW_RESPONSE | NODE_EXECUTED |
| approve-exact-site | 1 | START | NODE_EXECUTED |
| approve-exact-site | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| approve-exact-site | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| approve-exact-site | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| approve-exact-site | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| approve-exact-site | 6 | XDX_REDUCE_SITE_DRAFT | NODE_EXECUTED |
| approve-exact-site | 7 | XDX_SAVE_SITE_DRAFT | NODE_EXECUTED |
| approve-exact-site | 8 | XDX_SITE_NEEDS_REFERENCES | NODE_EXECUTED |
| approve-exact-site | 9 | XDX_SITE_DRAFT_RESPONSE | NODE_EXECUTED |
| create-approved-site | 1 | START | NODE_EXECUTED |
| create-approved-site | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| create-approved-site | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| create-approved-site | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| create-approved-site | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| create-approved-site | 6 | XDX_REDUCE_SITE_DRAFT | NODE_EXECUTED |
| create-approved-site | 7 | XDX_SAVE_SITE_DRAFT | NODE_EXECUTED |
| create-approved-site | 8 | XDX_SITE_NEEDS_REFERENCES | NODE_EXECUTED |
| create-approved-site | 9 | XDX_RESOLVE_SITE_PARENT | NODE_START |
| create-approved-site | 10 | XDX_BIND_SITE_PARENT | NODE_EXECUTED |
| create-approved-site | 11 | XDX_VALID_SITE_PARENT | NODE_EXECUTED |
| create-approved-site | 12 | XDX_RESOLVE_SITE_ADDRESS | NODE_START |
| create-approved-site | 13 | XDX_BIND_SITE_ADDRESS | NODE_EXECUTED |
| create-approved-site | 14 | XDX_VALID_SITE_ADDRESS | NODE_EXECUTED |
| create-approved-site | 15 | XDX_RESOLVE_SITE_BU | NODE_START |
| create-approved-site | 16 | XDX_BIND_SITE_REFERENCES | NODE_EXECUTED |
| create-approved-site | 17 | XDX_VALID_SITE_REFERENCES | NODE_EXECUTED |
| create-approved-site | 18 | XDX_SITE_IS_REVIEW | NODE_EXECUTED |
| create-approved-site | 19 | XDX_CHECK_SITE_DUPLICATE | NODE_START |
| create-approved-site | 20 | XDX_DECIDE_SITE_CREATE | NODE_EXECUTED |
| create-approved-site | 21 | XDX_CAN_POST_SITE | NODE_EXECUTED |
| create-approved-site | 22 | XDX_SAVE_SITE_ATTEMPT | NODE_EXECUTED |
| create-approved-site | 23 | XDX_CREATE_SITE | NODE_START |
| create-approved-site | 24 | XDX_VERIFY_SITE | NODE_START |
| create-approved-site | 25 | XDX_CONFIRM_SITE_CREATE | NODE_EXECUTED |
| create-approved-site | 26 | XDX_SAVE_SITE_CONFIRMATION | NODE_EXECUTED |
| create-approved-site | 27 | XDX_SITE_CREATE_RESULT | NODE_EXECUTED |

### Other Observed Nodes

| Node | Observed |
| --- | --- |
| START | 4 |
| XDX_BIND_SITE_ADDRESS | 2 |
| XDX_BIND_SITE_PARENT | 2 |
| XDX_BIND_SITE_REFERENCES | 2 |
| XDX_CAN_POST_SITE | 1 |
| XDX_CHECK_SITE_DUPLICATE | 1 |
| XDX_CONFIRM_SITE_CREATE | 1 |
| XDX_DECIDE_SITE_CREATE | 1 |
| XDX_EXTRACT_SEARCH | 4 |
| XDX_NORMALIZE_REQUEST | 4 |
| XDX_REDUCE_SITE_DRAFT | 4 |
| XDX_RESOLVE_SITE_ADDRESS | 2 |
| XDX_RESOLVE_SITE_BU | 2 |
| XDX_RESOLVE_SITE_PARENT | 2 |
| XDX_ROUTE_APP_STAGE | 4 |
| XDX_ROUTE_REQUEST_INTENT | 4 |
| XDX_SAVE_SITE_ATTEMPT | 1 |
| XDX_SAVE_SITE_CONFIRMATION | 1 |
| XDX_SAVE_SITE_DRAFT | 4 |
| XDX_SAVE_SITE_REVIEW | 1 |
| XDX_SITE_CREATE_RESULT | 1 |
| XDX_SITE_DRAFT_RESPONSE | 2 |
| XDX_SITE_IS_REVIEW | 2 |
| XDX_SITE_NEEDS_REFERENCES | 4 |
| XDX_SITE_REVIEW_RESPONSE | 1 |
| XDX_VALID_SITE_ADDRESS | 2 |
| XDX_VALID_SITE_PARENT | 2 |
| XDX_VALID_SITE_REFERENCES | 2 |
| XDX_VERIFY_SITE | 1 |

## Report Files

- JSON report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-site-create\result.json`
- Markdown report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-site-create\result.md`
- Test file: `test/workflows/xdx_supplier_lifecycle_agent/xdx-site-create.json`
