# Workflow Conversation Test Result: xdx-site-continuity

**Status:** PASSED
**Workflow:** XDX_SUPPLIER_LIFECYCLE_AGENT (DRAFT v86153667)
**Goal:** Resolve the supplier from the first user message and preserve that selection in a follow-up site query without repeating its name.
**Data Source:** File replay
**Evaluation:** Hybrid
**Steps:** 2

## Conversation Journey

| # | Step | Type | Intent | Interaction | Outcome | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | request-supplier-sites | chat | Use Lee Supplies as my selected supplier. Show its sites. | Use Lee Supplies as my selected supplier. Show up to 2 of its sites. | <oraInfoDisplay key="list"><br>{<br>  "title": "Supplier sites",<br>  "patternId": "multiRecordWidget",<br>  "description": "Sites for supplier Lee Supplies with paging information",<br>  "properties": {<br>    "subtitle": "Supplier: Lee Supplies; Next offset: 2",<br>    "selectMode": "none",<br>    "cols": ["Site", "Procurement business unit", "Address", "Status"],<br>    "rows": [<br>      {<br>        "cells": ["Lee US1", "US1 Business Unit", "Lee US1", "ACTIVE"]<br>      },<br>      {<br>        "cells": ["Lee Progress US", "Progress US Business Unit", "Lee Progress US", "ACTIVE"]<br>      }<br>    ]<br>  }<br>}<br></oraInfoDisplay> | passed |
| 2 | repeat-selected-sites | chat | Show sites for the selected supplier again. | Show up to 2 sites for the selected supplier again. | <oraInfoDisplay key="list"><br>{<br>  "title": "Supplier sites",<br>  "patternId": "multiRecordWidget",<br>  "description": "Sites for supplier Lee Supplies with paging information",<br>  "properties": {<br>    "subtitle": "Supplier: Lee Supplies; Next offset: 2",<br>    "selectMode": "none",<br>    "cols": ["Site", "Procurement business unit", "Address", "Status"],<br>    "rows": [<br>      {<br>        "cells": ["Lee US1", "US1 Business Unit", "Lee US1", "ACTIVE"]<br>      },<br>      {<br>        "cells": ["Lee Progress US", "Progress US Business Unit", "Lee Progress US", "ACTIVE"]<br>      }<br>    ]<br>  }<br>}<br></oraInfoDisplay> | passed |

## Step 1: request-supplier-sites

**Status:** passed
**Type:** chat
**Intent:** Use Lee Supplies as my selected supplier. Show its sites.
**Context Step IDs:** None (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Use Lee Supplies as my selected supplier. Show up to 2 of its sites.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraUserContext": "",
    "OraAppContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="list">
{
  "title": "Supplier sites",
  "patternId": "multiRecordWidget",
  "description": "Sites for supplier Lee Supplies with paging information",
  "properties": {
    "subtitle": "Supplier: Lee Supplies; Next offset: 2",
    "selectMode": "none",
    "cols": ["Site", "Procurement business unit", "Address", "Status"],
    "rows": [
      {
        "cells": ["Lee US1", "US1 Business Unit", "Lee US1", "ACTIVE"]
      },
      {
        "cells": ["Lee Progress US", "Progress US Business Unit", "Lee Progress US", "ACTIVE"]
      }
    ]
  }
}
</oraInfoDisplay>
~~~

## Step 2: repeat-selected-sites

**Status:** passed
**Type:** chat
**Intent:** Show sites for the selected supplier again.
**Context Step IDs:** request-supplier-sites (prior steps supplied to semantic judging)
**Conversation State:** established

### Interaction

```json
{
  "message": "Show up to 2 sites for the selected supplier again.",
  "triggerType": "app",
  "parameters": {
    "appHint": "Query",
    "OraUserContext": "",
    "OraAppContext": ""
  }
}
```

### Workflow Output

~~~text
<oraInfoDisplay key="list">
{
  "title": "Supplier sites",
  "patternId": "multiRecordWidget",
  "description": "Sites for supplier Lee Supplies with paging information",
  "properties": {
    "subtitle": "Supplier: Lee Supplies; Next offset: 2",
    "selectMode": "none",
    "cols": ["Site", "Procurement business unit", "Address", "Status"],
    "rows": [
      {
        "cells": ["Lee US1", "US1 Business Unit", "Lee US1", "ACTIVE"]
      },
      {
        "cells": ["Lee Progress US", "Progress US Business Unit", "Lee Progress US", "ACTIVE"]
      }
    ]
  }
}
</oraInfoDisplay>
~~~

## Verification Summary

| Verification | Status | Result |
| --- | --- | --- |
| Node order and counts | PASSED | 4/4 passed |
| Path assertions | PASSED | 498/498 passed |
| Semantic evaluation | PASSED | 5/5 passed |
| Workflow run checks | PASSED | 4/4 passed |
| Output checks | PASSED | 2/2 passed |

## Node Order and Count

### Required Relative Order

Other nodes may execute between the listed nodes.

| Step | Status | Assertion | Required Relative Order | Observed or Failure |
| --- | --- | --- | --- | --- |
| request-supplier-sites | PASS | Resolve supplier before fetching sites | XDX_FETCH_SUPPLIERS -> XDX_RESOLVE_SUPPLIER -> XDX_FETCH_SITES -> XDX_SITE_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_PREPARE_SEARCH -> XDX_VALID_SEARCH -> XDX_FETCH_SUPPLIERS -> XDX_ROUTE_READ_RESOURCE -> XDX_RESOLVE_SUPPLIER -> XDX_VALID_PARENT -> XDX_ROUTE_CHILD_READ -> XDX_FETCH_SITES -> XDX_SITE_RESPONSE |
| repeat-selected-sites | PASS | Resolve supplier before fetching sites | XDX_FETCH_SUPPLIERS -> XDX_RESOLVE_SUPPLIER -> XDX_FETCH_SITES -> XDX_SITE_RESPONSE | START -> XDX_ROUTE_APP_STAGE -> XDX_EXTRACT_SEARCH -> XDX_NORMALIZE_REQUEST -> XDX_ROUTE_REQUEST_INTENT -> XDX_PREPARE_SEARCH -> XDX_VALID_SEARCH -> XDX_FETCH_SUPPLIERS -> XDX_ROUTE_READ_RESOURCE -> XDX_RESOLVE_SUPPLIER -> XDX_VALID_PARENT -> XDX_ROUTE_CHILD_READ -> XDX_FETCH_SITES -> XDX_SITE_RESPONSE |

### Node Count Checks

| Step | Assertion | Node Code | Expected | Observed | Status |
| --- | --- | --- | --- | --- | --- |
| request-supplier-sites | Sites fetched once | XDX_FETCH_SITES | exactly 1 | 1 | PASS |
| repeat-selected-sites | Sites fetched once | XDX_FETCH_SITES | exactly 1 | 1 | PASS |

## Path Assertions

| Step | Status | Assertion | Requirement | Node Code | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| request-supplier-sites | PASS | XDX Route App Stage route check | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| request-supplier-sites | PASS | XDX Extract Search route check | Must execute | XDX_EXTRACT_SEARCH | Executed |
| request-supplier-sites | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| request-supplier-sites | PASS | Intent routes to read | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| request-supplier-sites | PASS | XDX Prepare Search route check | Must execute | XDX_PREPARE_SEARCH | Executed |
| request-supplier-sites | PASS | XDX Valid Search route check | Must execute | XDX_VALID_SEARCH | Executed |
| request-supplier-sites | PASS | XDX Fetch Suppliers route check | Must execute | XDX_FETCH_SUPPLIERS | Executed |
| request-supplier-sites | PASS | XDX Route Read Resource route check | Must execute | XDX_ROUTE_READ_RESOURCE | Executed |
| request-supplier-sites | PASS | XDX Resolve Supplier route check | Must execute | XDX_RESOLVE_SUPPLIER | Executed |
| request-supplier-sites | PASS | XDX Valid Parent route check | Must execute | XDX_VALID_PARENT | Executed |
| request-supplier-sites | PASS | XDX_ROUTE_CHILD_READ path check | Must execute | XDX_ROUTE_CHILD_READ | Executed |
| request-supplier-sites | PASS | XDX Fetch Sites route check | Must execute | XDX_FETCH_SITES | Executed |
| request-supplier-sites | PASS | XDX Address Response route check | Must execute | XDX_SITE_RESPONSE | Executed |
| request-supplier-sites | PASS | XDX Initial Display route check | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| request-supplier-sites | PASS | XDX Request Search Name route check | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| request-supplier-sites | PASS | XDX Query Response route check | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| request-supplier-sites | PASS | XDX Request Exact Parent route check | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| request-supplier-sites | PASS | XDX_FETCH_ADDRESSES path check | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| request-supplier-sites | PASS | XDX_ADDRESS_RESPONSE path check | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| request-supplier-sites | PASS | XDX_FETCH_CONTACTS remains inactive | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| request-supplier-sites | PASS | XDX_CONTACT_RESPONSE remains inactive | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| request-supplier-sites | PASS | XDX_REDUCE_SUPPLIER_DRAFT remains inactive | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| request-supplier-sites | PASS | XDX_SAVE_SUPPLIER_DRAFT remains inactive | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| request-supplier-sites | PASS | XDX_SUPPLIER_DRAFT_RESPONSE remains inactive | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| request-supplier-sites | PASS | XDX_PREPARE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| request-supplier-sites | PASS | XDX_VALID_SUPPLIER_CREATE remains inactive | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| request-supplier-sites | PASS | XDX_CHECK_SUPPLIER_DUPLICATE remains inactive | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| request-supplier-sites | PASS | XDX_DECIDE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| request-supplier-sites | PASS | XDX_CAN_POST_SUPPLIER remains inactive | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| request-supplier-sites | PASS | XDX_SAVE_SUPPLIER_ATTEMPT remains inactive | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| request-supplier-sites | PASS | XDX_SAVE_SUPPLIER_RECONCILIATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| request-supplier-sites | PASS | XDX_CREATE_SUPPLIER remains inactive | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| request-supplier-sites | PASS | XDX_VERIFY_SUPPLIER remains inactive | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| request-supplier-sites | PASS | XDX_CONFIRM_SUPPLIER_CREATE remains inactive | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| request-supplier-sites | PASS | XDX_SAVE_SUPPLIER_CONFIRMATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| request-supplier-sites | PASS | XDX_SUPPLIER_CREATE_BLOCKED remains inactive | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| request-supplier-sites | PASS | XDX_SUPPLIER_CREATE_DECISION remains inactive | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| request-supplier-sites | PASS | XDX_SUPPLIER_CREATE_RESULT remains inactive | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| request-supplier-sites | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| request-supplier-sites | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| request-supplier-sites | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| request-supplier-sites | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| request-supplier-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| request-supplier-sites | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| request-supplier-sites | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| request-supplier-sites | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| request-supplier-sites | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| request-supplier-sites | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| request-supplier-sites | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| request-supplier-sites | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| request-supplier-sites | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| request-supplier-sites | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| request-supplier-sites | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| request-supplier-sites | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| request-supplier-sites | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| request-supplier-sites | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| request-supplier-sites | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| request-supplier-sites | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| request-supplier-sites | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| request-supplier-sites | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| request-supplier-sites | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| request-supplier-sites | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| request-supplier-sites | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| request-supplier-sites | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| request-supplier-sites | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| request-supplier-sites | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |
| repeat-selected-sites | PASS | XDX Route App Stage route check | Must execute | XDX_ROUTE_APP_STAGE | Executed |
| repeat-selected-sites | PASS | XDX Extract Search route check | Must execute | XDX_EXTRACT_SEARCH | Executed |
| repeat-selected-sites | PASS | Normalized request executes | Must execute | XDX_NORMALIZE_REQUEST | Executed |
| repeat-selected-sites | PASS | Intent routes to read | Must execute | XDX_ROUTE_REQUEST_INTENT | Executed |
| repeat-selected-sites | PASS | XDX Prepare Search route check | Must execute | XDX_PREPARE_SEARCH | Executed |
| repeat-selected-sites | PASS | XDX Valid Search route check | Must execute | XDX_VALID_SEARCH | Executed |
| repeat-selected-sites | PASS | XDX Fetch Suppliers route check | Must execute | XDX_FETCH_SUPPLIERS | Executed |
| repeat-selected-sites | PASS | XDX Route Read Resource route check | Must execute | XDX_ROUTE_READ_RESOURCE | Executed |
| repeat-selected-sites | PASS | XDX Resolve Supplier route check | Must execute | XDX_RESOLVE_SUPPLIER | Executed |
| repeat-selected-sites | PASS | XDX Valid Parent route check | Must execute | XDX_VALID_PARENT | Executed |
| repeat-selected-sites | PASS | XDX_ROUTE_CHILD_READ path check | Must execute | XDX_ROUTE_CHILD_READ | Executed |
| repeat-selected-sites | PASS | XDX Fetch Sites route check | Must execute | XDX_FETCH_SITES | Executed |
| repeat-selected-sites | PASS | XDX Address Response route check | Must execute | XDX_SITE_RESPONSE | Executed |
| repeat-selected-sites | PASS | XDX Initial Display route check | Must not execute | XDX_INITIAL_DISPLAY | Not executed |
| repeat-selected-sites | PASS | XDX Request Search Name route check | Must not execute | XDX_REQUEST_SEARCH_NAME | Not executed |
| repeat-selected-sites | PASS | XDX Query Response route check | Must not execute | XDX_QUERY_RESPONSE | Not executed |
| repeat-selected-sites | PASS | XDX Request Exact Parent route check | Must not execute | XDX_REQUEST_EXACT_PARENT | Not executed |
| repeat-selected-sites | PASS | XDX_FETCH_ADDRESSES path check | Must not execute | XDX_FETCH_ADDRESSES | Not executed |
| repeat-selected-sites | PASS | XDX_ADDRESS_RESPONSE path check | Must not execute | XDX_ADDRESS_RESPONSE | Not executed |
| repeat-selected-sites | PASS | XDX_FETCH_CONTACTS remains inactive | Must not execute | XDX_FETCH_CONTACTS | Not executed |
| repeat-selected-sites | PASS | XDX_CONTACT_RESPONSE remains inactive | Must not execute | XDX_CONTACT_RESPONSE | Not executed |
| repeat-selected-sites | PASS | XDX_REDUCE_SUPPLIER_DRAFT remains inactive | Must not execute | XDX_REDUCE_SUPPLIER_DRAFT | Not executed |
| repeat-selected-sites | PASS | XDX_SAVE_SUPPLIER_DRAFT remains inactive | Must not execute | XDX_SAVE_SUPPLIER_DRAFT | Not executed |
| repeat-selected-sites | PASS | XDX_SUPPLIER_DRAFT_RESPONSE remains inactive | Must not execute | XDX_SUPPLIER_DRAFT_RESPONSE | Not executed |
| repeat-selected-sites | PASS | XDX_PREPARE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_PREPARE_SUPPLIER_CREATE | Not executed |
| repeat-selected-sites | PASS | XDX_VALID_SUPPLIER_CREATE remains inactive | Must not execute | XDX_VALID_SUPPLIER_CREATE | Not executed |
| repeat-selected-sites | PASS | XDX_CHECK_SUPPLIER_DUPLICATE remains inactive | Must not execute | XDX_CHECK_SUPPLIER_DUPLICATE | Not executed |
| repeat-selected-sites | PASS | XDX_DECIDE_SUPPLIER_CREATE remains inactive | Must not execute | XDX_DECIDE_SUPPLIER_CREATE | Not executed |
| repeat-selected-sites | PASS | XDX_CAN_POST_SUPPLIER remains inactive | Must not execute | XDX_CAN_POST_SUPPLIER | Not executed |
| repeat-selected-sites | PASS | XDX_SAVE_SUPPLIER_ATTEMPT remains inactive | Must not execute | XDX_SAVE_SUPPLIER_ATTEMPT | Not executed |
| repeat-selected-sites | PASS | XDX_SAVE_SUPPLIER_RECONCILIATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_RECONCILIATION | Not executed |
| repeat-selected-sites | PASS | XDX_CREATE_SUPPLIER remains inactive | Must not execute | XDX_CREATE_SUPPLIER | Not executed |
| repeat-selected-sites | PASS | XDX_VERIFY_SUPPLIER remains inactive | Must not execute | XDX_VERIFY_SUPPLIER | Not executed |
| repeat-selected-sites | PASS | XDX_CONFIRM_SUPPLIER_CREATE remains inactive | Must not execute | XDX_CONFIRM_SUPPLIER_CREATE | Not executed |
| repeat-selected-sites | PASS | XDX_SAVE_SUPPLIER_CONFIRMATION remains inactive | Must not execute | XDX_SAVE_SUPPLIER_CONFIRMATION | Not executed |
| repeat-selected-sites | PASS | XDX_SUPPLIER_CREATE_BLOCKED remains inactive | Must not execute | XDX_SUPPLIER_CREATE_BLOCKED | Not executed |
| repeat-selected-sites | PASS | XDX_SUPPLIER_CREATE_DECISION remains inactive | Must not execute | XDX_SUPPLIER_CREATE_DECISION | Not executed |
| repeat-selected-sites | PASS | XDX_SUPPLIER_CREATE_RESULT remains inactive | Must not execute | XDX_SUPPLIER_CREATE_RESULT | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_REDUCE_ADDRESS_DRAFT | Must not execute | XDX_REDUCE_ADDRESS_DRAFT | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_DRAFT | Must not execute | XDX_SAVE_ADDRESS_DRAFT | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_ADDRESS_DRAFT_RESPONSE | Must not execute | XDX_ADDRESS_DRAFT_RESPONSE | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_PREPARE_ADDRESS_CREATE | Must not execute | XDX_PREPARE_ADDRESS_CREATE | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_VALID_ADDRESS_CREATE | Must not execute | XDX_VALID_ADDRESS_CREATE | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_RESOLVE_ADDRESS_PARENT | Must not execute | XDX_RESOLVE_ADDRESS_PARENT | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_BIND_ADDRESS_PARENT | Must not execute | XDX_BIND_ADDRESS_PARENT | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_VALID_ADDRESS_PARENT | Must not execute | XDX_VALID_ADDRESS_PARENT | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_CHECK_ADDRESS_DUPLICATE | Must not execute | XDX_CHECK_ADDRESS_DUPLICATE | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_DECIDE_ADDRESS_CREATE | Must not execute | XDX_DECIDE_ADDRESS_CREATE | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_CAN_POST_ADDRESS | Must not execute | XDX_CAN_POST_ADDRESS | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_ATTEMPT | Must not execute | XDX_SAVE_ADDRESS_ATTEMPT | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_RECONCILIATION | Must not execute | XDX_SAVE_ADDRESS_RECONCILIATION | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_CREATE_ADDRESS | Must not execute | XDX_CREATE_ADDRESS | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_VERIFY_ADDRESS | Must not execute | XDX_VERIFY_ADDRESS | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_CONFIRM_ADDRESS_CREATE | Must not execute | XDX_CONFIRM_ADDRESS_CREATE | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_SAVE_ADDRESS_CONFIRMATION | Must not execute | XDX_SAVE_ADDRESS_CONFIRMATION | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_BLOCKED | Must not execute | XDX_ADDRESS_CREATE_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_ADDRESS_PARENT_BLOCKED | Must not execute | XDX_ADDRESS_PARENT_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_DECISION | Must not execute | XDX_ADDRESS_CREATE_DECISION | Not executed |
| repeat-selected-sites | PASS | Address route remains inactive: XDX_ADDRESS_CREATE_RESULT | Must not execute | XDX_ADDRESS_CREATE_RESULT | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_REDUCE_SITE_DRAFT | Must not execute | XDX_REDUCE_SITE_DRAFT | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_SAVE_SITE_DRAFT | Must not execute | XDX_SAVE_SITE_DRAFT | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_SITE_NEEDS_REFERENCES | Must not execute | XDX_SITE_NEEDS_REFERENCES | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_SITE_DRAFT_RESPONSE | Must not execute | XDX_SITE_DRAFT_RESPONSE | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_BIND_SITE_PARENT | Must not execute | XDX_BIND_SITE_PARENT | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_VALID_SITE_PARENT | Must not execute | XDX_VALID_SITE_PARENT | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_SITE_PARENT_BLOCKED | Must not execute | XDX_SITE_PARENT_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_BIND_SITE_ADDRESS | Must not execute | XDX_BIND_SITE_ADDRESS | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_VALID_SITE_ADDRESS | Must not execute | XDX_VALID_SITE_ADDRESS | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_SITE_ADDRESS_BLOCKED | Must not execute | XDX_SITE_ADDRESS_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_BIND_SITE_REFERENCES | Must not execute | XDX_BIND_SITE_REFERENCES | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_VALID_SITE_REFERENCES | Must not execute | XDX_VALID_SITE_REFERENCES | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_SITE_REFERENCES_BLOCKED | Must not execute | XDX_SITE_REFERENCES_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_SITE_IS_REVIEW | Must not execute | XDX_SITE_IS_REVIEW | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_SAVE_SITE_REVIEW | Must not execute | XDX_SAVE_SITE_REVIEW | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_SITE_REVIEW_RESPONSE | Must not execute | XDX_SITE_REVIEW_RESPONSE | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_DECIDE_SITE_CREATE | Must not execute | XDX_DECIDE_SITE_CREATE | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_CAN_POST_SITE | Must not execute | XDX_CAN_POST_SITE | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_SAVE_SITE_ATTEMPT | Must not execute | XDX_SAVE_SITE_ATTEMPT | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_SAVE_SITE_RECONCILIATION | Must not execute | XDX_SAVE_SITE_RECONCILIATION | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_SITE_CREATE_DECISION | Must not execute | XDX_SITE_CREATE_DECISION | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_CONFIRM_SITE_CREATE | Must not execute | XDX_CONFIRM_SITE_CREATE | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_SAVE_SITE_CONFIRMATION | Must not execute | XDX_SAVE_SITE_CONFIRMATION | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_SITE_CREATE_RESULT | Must not execute | XDX_SITE_CREATE_RESULT | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_PARENT | Must not execute | XDX_RESOLVE_SITE_PARENT | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_ADDRESS | Must not execute | XDX_RESOLVE_SITE_ADDRESS | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_RESOLVE_SITE_BU | Must not execute | XDX_RESOLVE_SITE_BU | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_CHECK_SITE_DUPLICATE | Must not execute | XDX_CHECK_SITE_DUPLICATE | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_CREATE_SITE | Must not execute | XDX_CREATE_SITE | Not executed |
| repeat-selected-sites | PASS | Site branch stays inactive: XDX_VERIFY_SITE | Must not execute | XDX_VERIFY_SITE | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_REDUCE_CONTACT_DRAFT | Must not execute | XDX_REDUCE_CONTACT_DRAFT | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_DRAFT | Must not execute | XDX_SAVE_CONTACT_DRAFT | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_CONTACT_NEEDS_PARENT | Must not execute | XDX_CONTACT_NEEDS_PARENT | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_CONTACT_DRAFT_RESPONSE | Must not execute | XDX_CONTACT_DRAFT_RESPONSE | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_BIND_CONTACT_PARENT | Must not execute | XDX_BIND_CONTACT_PARENT | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_VALID_CONTACT_PARENT | Must not execute | XDX_VALID_CONTACT_PARENT | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_CONTACT_PARENT_BLOCKED | Must not execute | XDX_CONTACT_PARENT_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_CONTACT_IS_REVIEW | Must not execute | XDX_CONTACT_IS_REVIEW | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_REVIEW | Must not execute | XDX_SAVE_CONTACT_REVIEW | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_CONTACT_REVIEW_RESPONSE | Must not execute | XDX_CONTACT_REVIEW_RESPONSE | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_DECIDE_CONTACT_CREATE | Must not execute | XDX_DECIDE_CONTACT_CREATE | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_CAN_POST_CONTACT | Must not execute | XDX_CAN_POST_CONTACT | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_ATTEMPT | Must not execute | XDX_SAVE_CONTACT_ATTEMPT | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_RECONCILIATION | Must not execute | XDX_SAVE_CONTACT_RECONCILIATION | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_DECISION | Must not execute | XDX_CONTACT_CREATE_DECISION | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_CONFIRM_CONTACT_CREATE | Must not execute | XDX_CONFIRM_CONTACT_CREATE | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_SAVE_CONTACT_CONFIRMATION | Must not execute | XDX_SAVE_CONTACT_CONFIRMATION | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_CONTACT_CREATE_RESULT | Must not execute | XDX_CONTACT_CREATE_RESULT | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_RESOLVE_CONTACT_PARENT | Must not execute | XDX_RESOLVE_CONTACT_PARENT | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_CHECK_CONTACT_DUPLICATE | Must not execute | XDX_CHECK_CONTACT_DUPLICATE | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_CREATE_CONTACT | Must not execute | XDX_CREATE_CONTACT | Not executed |
| repeat-selected-sites | PASS | Contact branch stays inactive: XDX_VERIFY_CONTACT | Must not execute | XDX_VERIFY_CONTACT | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_REDUCE_CLASSIFICATION_DRAFT | Must not execute | XDX_REDUCE_CLASSIFICATION_DRAFT | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_DRAFT | Must not execute | XDX_SAVE_CLASSIFICATION_DRAFT | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_NEEDS_PARENT | Must not execute | XDX_CLASSIFICATION_NEEDS_PARENT | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_DRAFT_RESPONSE | Must not execute | XDX_CLASSIFICATION_DRAFT_RESPONSE | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_BIND_CLASSIFICATION_PARENT | Must not execute | XDX_BIND_CLASSIFICATION_PARENT | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_VALID_CLASSIFICATION_PARENT | Must not execute | XDX_VALID_CLASSIFICATION_PARENT | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_PARENT_BLOCKED | Must not execute | XDX_CLASSIFICATION_PARENT_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_IS_REVIEW | Must not execute | XDX_CLASSIFICATION_IS_REVIEW | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_REVIEW | Must not execute | XDX_SAVE_CLASSIFICATION_REVIEW | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_REVIEW_RESPONSE | Must not execute | XDX_CLASSIFICATION_REVIEW_RESPONSE | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_DECIDE_CLASSIFICATION_CREATE | Must not execute | XDX_DECIDE_CLASSIFICATION_CREATE | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_CAN_POST_CLASSIFICATION | Must not execute | XDX_CAN_POST_CLASSIFICATION | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_ATTEMPT | Must not execute | XDX_SAVE_CLASSIFICATION_ATTEMPT | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_RECONCILIATION | Must not execute | XDX_SAVE_CLASSIFICATION_RECONCILIATION | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_DECISION | Must not execute | XDX_CLASSIFICATION_CREATE_DECISION | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_CONFIRM_CLASSIFICATION_CREATE | Must not execute | XDX_CONFIRM_CLASSIFICATION_CREATE | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_SAVE_CLASSIFICATION_CONFIRMATION | Must not execute | XDX_SAVE_CLASSIFICATION_CONFIRMATION | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_CREATE_RESULT | Must not execute | XDX_CLASSIFICATION_CREATE_RESULT | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_FORMAT_CLASSIFICATIONS | Must not execute | XDX_FORMAT_CLASSIFICATIONS | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_CLASSIFICATION_RESPONSE | Must not execute | XDX_CLASSIFICATION_RESPONSE | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_RESOLVE_CLASSIFICATION_PARENT | Must not execute | XDX_RESOLVE_CLASSIFICATION_PARENT | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_CHECK_CLASSIFICATION_DUPLICATE | Must not execute | XDX_CHECK_CLASSIFICATION_DUPLICATE | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_CREATE_CLASSIFICATION | Must not execute | XDX_CREATE_CLASSIFICATION | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_VERIFY_CLASSIFICATION | Must not execute | XDX_VERIFY_CLASSIFICATION | Not executed |
| repeat-selected-sites | PASS | Classification branch stays inactive: XDX_FETCH_CLASSIFICATIONS | Must not execute | XDX_FETCH_CLASSIFICATIONS | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_REDUCE_LINK_DRAFT | Must not execute | XDX_REDUCE_LINK_DRAFT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_LINK_DRAFT | Must not execute | XDX_SAVE_LINK_DRAFT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_LINK_NEEDS_REFERENCES | Must not execute | XDX_LINK_NEEDS_REFERENCES | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_LINK_DRAFT_RESPONSE | Must not execute | XDX_LINK_DRAFT_RESPONSE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_PARENT | Must not execute | XDX_RESOLVE_LINK_PARENT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_BIND_LINK_PARENT | Must not execute | XDX_BIND_LINK_PARENT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_VALID_LINK_PARENT | Must not execute | XDX_VALID_LINK_PARENT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_LINK_PARENT_BLOCKED | Must not execute | XDX_LINK_PARENT_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_ADDRESS | Must not execute | XDX_RESOLVE_LINK_ADDRESS | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_BIND_LINK_ADDRESS | Must not execute | XDX_BIND_LINK_ADDRESS | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_VALID_LINK_ADDRESS | Must not execute | XDX_VALID_LINK_ADDRESS | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_LINK_ADDRESS_BLOCKED | Must not execute | XDX_LINK_ADDRESS_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_RESOLVE_LINK_CONTACT | Must not execute | XDX_RESOLVE_LINK_CONTACT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_BIND_LINK_REFERENCES | Must not execute | XDX_BIND_LINK_REFERENCES | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_VALID_LINK_REFERENCES | Must not execute | XDX_VALID_LINK_REFERENCES | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_LINK_REFERENCES_BLOCKED | Must not execute | XDX_LINK_REFERENCES_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_LINK_IS_REVIEW | Must not execute | XDX_LINK_IS_REVIEW | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_LINK_REVIEW | Must not execute | XDX_SAVE_LINK_REVIEW | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_LINK_REVIEW_RESPONSE | Must not execute | XDX_LINK_REVIEW_RESPONSE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_CHECK_LINK_DUPLICATE | Must not execute | XDX_CHECK_LINK_DUPLICATE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_DECIDE_LINK_CREATE | Must not execute | XDX_DECIDE_LINK_CREATE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_CAN_POST_LINK | Must not execute | XDX_CAN_POST_LINK | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_LINK_ATTEMPT | Must not execute | XDX_SAVE_LINK_ATTEMPT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_LINK_RECONCILIATION | Must not execute | XDX_SAVE_LINK_RECONCILIATION | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_LINK_CREATE_DECISION | Must not execute | XDX_LINK_CREATE_DECISION | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_CREATE_LINK | Must not execute | XDX_CREATE_LINK | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_VERIFY_LINK | Must not execute | XDX_VERIFY_LINK | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_CONFIRM_LINK_CREATE | Must not execute | XDX_CONFIRM_LINK_CREATE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_LINK_CONFIRMATION | Must not execute | XDX_SAVE_LINK_CONFIRMATION | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_LINK_CREATE_RESULT | Must not execute | XDX_LINK_CREATE_RESULT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_REDUCE_PRODUCT_DRAFT | Must not execute | XDX_REDUCE_PRODUCT_DRAFT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_DRAFT | Must not execute | XDX_SAVE_PRODUCT_DRAFT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_PRODUCT_NEEDS_REFERENCES | Must not execute | XDX_PRODUCT_NEEDS_REFERENCES | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_PRODUCT_DRAFT_RESPONSE | Must not execute | XDX_PRODUCT_DRAFT_RESPONSE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_PARENT | Must not execute | XDX_RESOLVE_PRODUCT_PARENT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_PARENT | Must not execute | XDX_BIND_PRODUCT_PARENT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_PARENT | Must not execute | XDX_VALID_PRODUCT_PARENT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_PRODUCT_PARENT_BLOCKED | Must not execute | XDX_PRODUCT_PARENT_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_RESOLVE_PRODUCT_CATEGORY | Must not execute | XDX_RESOLVE_PRODUCT_CATEGORY | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_BIND_PRODUCT_REFERENCES | Must not execute | XDX_BIND_PRODUCT_REFERENCES | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_VALID_PRODUCT_REFERENCES | Must not execute | XDX_VALID_PRODUCT_REFERENCES | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_PRODUCT_REFERENCES_BLOCKED | Must not execute | XDX_PRODUCT_REFERENCES_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_PRODUCT_IS_REVIEW | Must not execute | XDX_PRODUCT_IS_REVIEW | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_REVIEW | Must not execute | XDX_SAVE_PRODUCT_REVIEW | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_PRODUCT_REVIEW_RESPONSE | Must not execute | XDX_PRODUCT_REVIEW_RESPONSE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_CHECK_PRODUCT_DUPLICATE | Must not execute | XDX_CHECK_PRODUCT_DUPLICATE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_DECIDE_PRODUCT_CREATE | Must not execute | XDX_DECIDE_PRODUCT_CREATE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_CAN_POST_PRODUCT | Must not execute | XDX_CAN_POST_PRODUCT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_ATTEMPT | Must not execute | XDX_SAVE_PRODUCT_ATTEMPT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_RECONCILIATION | Must not execute | XDX_SAVE_PRODUCT_RECONCILIATION | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_DECISION | Must not execute | XDX_PRODUCT_CREATE_DECISION | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_CREATE_PRODUCT | Must not execute | XDX_CREATE_PRODUCT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_VERIFY_PRODUCT | Must not execute | XDX_VERIFY_PRODUCT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_CONFIRM_PRODUCT_CREATE | Must not execute | XDX_CONFIRM_PRODUCT_CREATE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_PRODUCT_CONFIRMATION | Must not execute | XDX_SAVE_PRODUCT_CONFIRMATION | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_PRODUCT_CREATE_RESULT | Must not execute | XDX_PRODUCT_CREATE_RESULT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_REDUCE_ASSIGNMENT_DRAFT | Must not execute | XDX_REDUCE_ASSIGNMENT_DRAFT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_DRAFT | Must not execute | XDX_SAVE_ASSIGNMENT_DRAFT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_NEEDS_REFERENCES | Must not execute | XDX_ASSIGNMENT_NEEDS_REFERENCES | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_DRAFT_RESPONSE | Must not execute | XDX_ASSIGNMENT_DRAFT_RESPONSE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_PARENT | Must not execute | XDX_RESOLVE_ASSIGNMENT_PARENT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_PARENT | Must not execute | XDX_BIND_ASSIGNMENT_PARENT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_PARENT | Must not execute | XDX_VALID_ASSIGNMENT_PARENT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_PARENT_BLOCKED | Must not execute | XDX_ASSIGNMENT_PARENT_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_SITE | Must not execute | XDX_RESOLVE_ASSIGNMENT_SITE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_SITE | Must not execute | XDX_BIND_ASSIGNMENT_SITE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_SITE | Must not execute | XDX_VALID_ASSIGNMENT_SITE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_SITE_BLOCKED | Must not execute | XDX_ASSIGNMENT_SITE_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_BILL_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_BILL_BU | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_REFERENCES | Must not execute | XDX_BIND_ASSIGNMENT_REFERENCES | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_REFERENCES | Must not execute | XDX_VALID_ASSIGNMENT_REFERENCES | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REFERENCES_BLOCKED | Must not execute | XDX_ASSIGNMENT_REFERENCES_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_IS_REVIEW | Must not execute | XDX_ASSIGNMENT_IS_REVIEW | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_REVIEW | Must not execute | XDX_SAVE_ASSIGNMENT_REVIEW | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_REVIEW_RESPONSE | Must not execute | XDX_ASSIGNMENT_REVIEW_RESPONSE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_CHECK_ASSIGNMENT_DUPLICATE | Must not execute | XDX_CHECK_ASSIGNMENT_DUPLICATE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_DECIDE_ASSIGNMENT_CREATE | Must not execute | XDX_DECIDE_ASSIGNMENT_CREATE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_CAN_POST_ASSIGNMENT | Must not execute | XDX_CAN_POST_ASSIGNMENT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_ATTEMPT | Must not execute | XDX_SAVE_ASSIGNMENT_ATTEMPT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_RECONCILIATION | Must not execute | XDX_SAVE_ASSIGNMENT_RECONCILIATION | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_DECISION | Must not execute | XDX_ASSIGNMENT_CREATE_DECISION | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_CREATE_ASSIGNMENT | Must not execute | XDX_CREATE_ASSIGNMENT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_VERIFY_ASSIGNMENT | Must not execute | XDX_VERIFY_ASSIGNMENT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_CONFIRM_ASSIGNMENT_CREATE | Must not execute | XDX_CONFIRM_ASSIGNMENT_CREATE | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_SAVE_ASSIGNMENT_CONFIRMATION | Must not execute | XDX_SAVE_ASSIGNMENT_CONFIRMATION | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CREATE_RESULT | Must not execute | XDX_ASSIGNMENT_CREATE_RESULT | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_RESOLVE_ASSIGNMENT_CLIENT_BU | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_BIND_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_BIND_ASSIGNMENT_CLIENT_BU | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_VALID_ASSIGNMENT_CLIENT_BU | Must not execute | XDX_VALID_ASSIGNMENT_CLIENT_BU | Not executed |
| repeat-selected-sites | PASS | Association branch stays inactive: XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Must not execute | XDX_ASSIGNMENT_CLIENT_BU_BLOCKED | Not executed |
| repeat-selected-sites | PASS | Read branch stays inactive: XDX_FETCH_PRODUCTS_READ | Must not execute | XDX_FETCH_PRODUCTS_READ | Not executed |
| repeat-selected-sites | PASS | Read branch stays inactive: XDX_FORMAT_PRODUCTS_READ | Must not execute | XDX_FORMAT_PRODUCTS_READ | Not executed |
| repeat-selected-sites | PASS | Read branch stays inactive: XDX_PRODUCTS_READ_RESPONSE | Must not execute | XDX_PRODUCTS_READ_RESPONSE | Not executed |
| repeat-selected-sites | PASS | No XDX_PREPARE_LINK_READ on this route | Must not execute | XDX_PREPARE_LINK_READ | Not executed |
| repeat-selected-sites | PASS | No XDX_VALID_LINK_READ_SELECTOR on this route | Must not execute | XDX_VALID_LINK_READ_SELECTOR | Not executed |
| repeat-selected-sites | PASS | No XDX_LINK_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_LINK_READ_SELECTOR_REQUIRED | Not executed |
| repeat-selected-sites | PASS | No XDX_RESOLVE_LINK_READ_CONTACT on this route | Must not execute | XDX_RESOLVE_LINK_READ_CONTACT | Not executed |
| repeat-selected-sites | PASS | No XDX_BIND_LINK_READ_CONTACT on this route | Must not execute | XDX_BIND_LINK_READ_CONTACT | Not executed |
| repeat-selected-sites | PASS | No XDX_VALID_LINK_READ_CONTACT on this route | Must not execute | XDX_VALID_LINK_READ_CONTACT | Not executed |
| repeat-selected-sites | PASS | No XDX_LINK_READ_CONTACT_REQUIRED on this route | Must not execute | XDX_LINK_READ_CONTACT_REQUIRED | Not executed |
| repeat-selected-sites | PASS | No XDX_FETCH_LINK_READ on this route | Must not execute | XDX_FETCH_LINK_READ | Not executed |
| repeat-selected-sites | PASS | No XDX_FORMAT_LINK_READ on this route | Must not execute | XDX_FORMAT_LINK_READ | Not executed |
| repeat-selected-sites | PASS | No XDX_LINK_READ_RESPONSE on this route | Must not execute | XDX_LINK_READ_RESPONSE | Not executed |
| repeat-selected-sites | PASS | No XDX_PREPARE_ASSIGNMENT_READ on this route | Must not execute | XDX_PREPARE_ASSIGNMENT_READ | Not executed |
| repeat-selected-sites | PASS | No XDX_VALID_ASSIGNMENT_READ_SELECTOR on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SELECTOR | Not executed |
| repeat-selected-sites | PASS | No XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SELECTOR_REQUIRED | Not executed |
| repeat-selected-sites | PASS | No XDX_RESOLVE_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_RESOLVE_ASSIGNMENT_READ_SITE | Not executed |
| repeat-selected-sites | PASS | No XDX_BIND_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_BIND_ASSIGNMENT_READ_SITE | Not executed |
| repeat-selected-sites | PASS | No XDX_VALID_ASSIGNMENT_READ_SITE on this route | Must not execute | XDX_VALID_ASSIGNMENT_READ_SITE | Not executed |
| repeat-selected-sites | PASS | No XDX_ASSIGNMENT_READ_SITE_REQUIRED on this route | Must not execute | XDX_ASSIGNMENT_READ_SITE_REQUIRED | Not executed |
| repeat-selected-sites | PASS | No XDX_FETCH_ASSIGNMENT_READ on this route | Must not execute | XDX_FETCH_ASSIGNMENT_READ | Not executed |
| repeat-selected-sites | PASS | No XDX_FORMAT_ASSIGNMENT_READ on this route | Must not execute | XDX_FORMAT_ASSIGNMENT_READ | Not executed |
| repeat-selected-sites | PASS | No XDX_ASSIGNMENT_READ_RESPONSE on this route | Must not execute | XDX_ASSIGNMENT_READ_RESPONSE | Not executed |

## Semantic Evaluation

| Scope | Status | Score | Summary |
| --- | --- | --- | --- |
| request-supplier-sites | passed | 5/5 | Both turns preserve Lee Supplies and the same resolved parent300000047414503. Lee US1/US1 Business Unit/Lee US1/ACTIVE and Lee Progress US/Progress US Business Unit/Lee Progress US/ACTIVE match retained rows. Four business columns, no visible keys, explicit next offset2, nameless follow-up retained. |
| repeat-selected-sites | passed | 5/5 | Both turns preserve Lee Supplies and the same resolved parent300000047414503. Lee US1/US1 Business Unit/Lee US1/ACTIVE and Lee Progress US/Progress US Business Unit/Lee Progress US/ACTIVE match retained rows. Four business columns, no visible keys, explicit next offset2, nameless follow-up retained. |
| Conversation | passed | 5/5 | Both turns preserve Lee Supplies and the same resolved parent300000047414503. Lee US1/US1 Business Unit/Lee US1/ACTIVE and Lee Progress US/Progress US Business Unit/Lee Progress US/ACTIVE match retained rows. Four business columns, no visible keys, explicit next offset2, nameless follow-up retained. |

### Criterion Results

| Scope | Status | Assertion | Criterion | Notes |
| --- | --- | --- | --- | --- |
| request-supplier-sites | PASS | Correct supplier and site data | Output identifies Lee Supplies and displays exactly the returned site rows; site request parent key must agree with the freshly resolved supplier record. | Both turns preserve Lee Supplies and the same resolved parent300000047414503. Lee US1/US1 Business Unit/Lee US1/ACTIVE and Lee Progress US/Progress US Business Unit/Lee Progress US/ACTIVE match retained rows. Four business columns, no visible keys, explicit next offset2, nameless follow-up retained. |
| request-supplier-sites | PASS | Business site table | Nonempty response uses a valid oraInfoDisplay multiRecordWidget with Site, Procurement business unit, Address, Status columns and values from SupplierSite, ProcurementBU, SupplierAddressName, Status. No displayed technical IDs; paging agrees with captured envelope. When hasMore=true the displayed subtitle explicitly includes Next offset: and the correct numeric offset+count, not only a general more-pages notice. | Both turns preserve Lee Supplies and the same resolved parent300000047414503. Lee US1/US1 Business Unit/Lee US1/ACTIVE and Lee Progress US/Progress US Business Unit/Lee Progress US/ACTIVE match retained rows. Four business columns, no visible keys, explicit next offset2, nameless follow-up retained. |
| repeat-selected-sites | PASS | Correct supplier and site data | Output identifies Lee Supplies and displays exactly the returned site rows; site request parent key must agree with the freshly resolved supplier record. | Both turns preserve Lee Supplies and the same resolved parent300000047414503. Lee US1/US1 Business Unit/Lee US1/ACTIVE and Lee Progress US/Progress US Business Unit/Lee Progress US/ACTIVE match retained rows. Four business columns, no visible keys, explicit next offset2, nameless follow-up retained. |
| repeat-selected-sites | PASS | Business site table | Nonempty response uses a valid oraInfoDisplay multiRecordWidget with Site, Procurement business unit, Address, Status columns and values from SupplierSite, ProcurementBU, SupplierAddressName, Status. No displayed technical IDs; paging agrees with captured envelope. When hasMore=true the displayed subtitle explicitly includes Next offset: and the correct numeric offset+count, not only a general more-pages notice. | Both turns preserve Lee Supplies and the same resolved parent300000047414503. Lee US1/US1 Business Unit/Lee US1/ACTIVE and Lee Progress US/Progress US Business Unit/Lee Progress US/ACTIVE match retained rows. Four business columns, no visible keys, explicit next offset2, nameless follow-up retained. |
| Conversation | PASS | Selected supplier persists across messages | The second message does not repeat a name; its BO parent key and site output must remain tied to Lee Supplies named only in the first message. No first-row default or fabricated key. | Both turns preserve Lee Supplies and the same resolved parent300000047414503. Lee US1/US1 Business Unit/Lee US1/ACTIVE and Lee Progress US/Progress US Business Unit/Lee Progress US/ACTIVE match retained rows. Four business columns, no visible keys, explicit next offset2, nameless follow-up retained. |

## Workflow Run Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| request-supplier-sites | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| repeat-selected-sites | PASS | Workflow completed without error | Workflow completed without error | Workflow execution must not finish with error. | Verified |
| Conversation | PASS | conversationStepOrder | conversationStepOrder | request-supplier-sites -> repeat-selected-sites | Verified |
| Conversation | PASS | conversationIdReuse | conversationIdReuse | Every executed step uses one conversation ID. | Verified |

## Output Checks

| Step | Status | Assertion | Check | Expected | Observed or Failure |
| --- | --- | --- | --- | --- | --- |
| request-supplier-sites | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |
| repeat-selected-sites | PASS | Final output produced | Final output produced | Workflow execution must produce a final answer. | Verified |

## Runtime Metrics

Workflow time: 8303 ms (sum of node times)
Test run time: 11671 ms (includes CLI overhead)
Token usage: observed from runtime events

Aggregate Token Usage

| Input Tokens | Output Tokens | Total Tokens | Model |
| --- | --- | --- | --- |
| 20670 | 1436 | 22106 | oci-agent/openai.gpt-4.1-mini-2025-04-14 |

| Node | Input Tokens | Output Tokens | Total Tokens | Model | Source |
| --- | --- | --- | --- | --- | --- |
| repeat-selected-sites:XDX_EXTRACT_SEARCH | 4462 | 503 | 4965 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| repeat-selected-sites:XDX_SITE_RESPONSE | 5979 | 215 | 6194 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| request-supplier-sites:XDX_EXTRACT_SEARCH | 4250 | 503 | 4753 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |
| request-supplier-sites:XDX_SITE_RESPONSE | 5979 | 215 | 6194 | oci-agent/openai.gpt-4.1-mini-2025-04-14 | computed:inputTokens+outputTokens, nodeProgressMessage.nodeStepInfo.details[0].inputTokens, nodeProgressMessage.nodeStepInfo.details[0].modelName, nodeProgressMessage.nodeStepInfo.details[0].outputTokens |


AI Units: computed
Total Token Units: 4
Total AI Units: 20

| Node | Input | Output | Token Units | AI Units | Model Type | Action Type |
| --- | --- | --- | --- | --- | --- | --- |
| repeat-selected-sites:XDX_EXTRACT_SEARCH | 4462 | 503 | 1 | 5 | premium | general |
| repeat-selected-sites:XDX_SITE_RESPONSE | 5979 | 215 | 1 | 5 | premium | general |
| request-supplier-sites:XDX_EXTRACT_SEARCH | 4250 | 503 | 1 | 5 | premium | general |
| request-supplier-sites:XDX_SITE_RESPONSE | 5979 | 215 | 1 | 5 | premium | general |

| Node | Node Time (ms) | LLM Call Time (ms) | Details |
| --- | --- | --- | --- |
| request-supplier-sites:XDX_EXTRACT_SEARCH | 2960 | 2852 | 1 runtime detail; see JSON report |
| request-supplier-sites:XDX_FETCH_SUPPLIERS | 46 |  | 0 runtime details; see JSON report |
| request-supplier-sites:XDX_FETCH_SITES | 46 |  | 0 runtime details; see JSON report |
| request-supplier-sites:XDX_SITE_RESPONSE | 1489 | 1410 | 1 runtime detail; see JSON report |
| repeat-selected-sites:XDX_EXTRACT_SEARCH | 2270 | 2187 | 1 runtime detail; see JSON report |
| repeat-selected-sites:XDX_FETCH_SUPPLIERS | 45 |  | 0 runtime details; see JSON report |
| repeat-selected-sites:XDX_FETCH_SITES | 45 |  | 0 runtime details; see JSON report |
| repeat-selected-sites:XDX_SITE_RESPONSE | 1402 | 1333 | 1 runtime detail; see JSON report |

| Observed Field | Values |
| --- | --- |
| modelName | "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14"; "oci-agent/openai.gpt-4.1-mini-2025-04-14" |
| inputTokens | 4250; 5979; 4462; 5979 |
| outputTokens | 503; 215; 503; 215 |

## Test Data

| Step | Data Source | Evaluation |
| --- | --- | --- |
| request-supplier-sites | File replay | Hybrid |
| repeat-selected-sites | File replay | Hybrid |

## Workflow Run

### Execution Timeline

| Step | Phase Sequence | Node | Event |
| --- | --- | --- | --- |
| request-supplier-sites | 1 | START | NODE_EXECUTED |
| request-supplier-sites | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| request-supplier-sites | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| request-supplier-sites | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| request-supplier-sites | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| request-supplier-sites | 6 | XDX_PREPARE_SEARCH | NODE_EXECUTED |
| request-supplier-sites | 7 | XDX_VALID_SEARCH | NODE_EXECUTED |
| request-supplier-sites | 8 | XDX_FETCH_SUPPLIERS | NODE_START |
| request-supplier-sites | 9 | XDX_ROUTE_READ_RESOURCE | NODE_START |
| request-supplier-sites | 10 | XDX_RESOLVE_SUPPLIER | NODE_EXECUTED |
| request-supplier-sites | 11 | XDX_VALID_PARENT | NODE_EXECUTED |
| request-supplier-sites | 12 | XDX_ROUTE_CHILD_READ | NODE_START |
| request-supplier-sites | 13 | XDX_FETCH_SITES | NODE_START |
| request-supplier-sites | 14 | XDX_SITE_RESPONSE | NODE_START |
| repeat-selected-sites | 1 | START | NODE_EXECUTED |
| repeat-selected-sites | 2 | XDX_ROUTE_APP_STAGE | NODE_START |
| repeat-selected-sites | 3 | XDX_EXTRACT_SEARCH | NODE_START |
| repeat-selected-sites | 4 | XDX_NORMALIZE_REQUEST | NODE_EXECUTED |
| repeat-selected-sites | 5 | XDX_ROUTE_REQUEST_INTENT | NODE_START |
| repeat-selected-sites | 6 | XDX_PREPARE_SEARCH | NODE_EXECUTED |
| repeat-selected-sites | 7 | XDX_VALID_SEARCH | NODE_EXECUTED |
| repeat-selected-sites | 8 | XDX_FETCH_SUPPLIERS | NODE_START |
| repeat-selected-sites | 9 | XDX_ROUTE_READ_RESOURCE | NODE_START |
| repeat-selected-sites | 10 | XDX_RESOLVE_SUPPLIER | NODE_EXECUTED |
| repeat-selected-sites | 11 | XDX_VALID_PARENT | NODE_EXECUTED |
| repeat-selected-sites | 12 | XDX_ROUTE_CHILD_READ | NODE_START |
| repeat-selected-sites | 13 | XDX_FETCH_SITES | NODE_START |
| repeat-selected-sites | 14 | XDX_SITE_RESPONSE | NODE_START |

### Other Observed Nodes

| Node | Observed |
| --- | --- |
| START | 2 |
| XDX_EXTRACT_SEARCH | 2 |
| XDX_FETCH_SUPPLIERS | 2 |
| XDX_NORMALIZE_REQUEST | 2 |
| XDX_PREPARE_SEARCH | 2 |
| XDX_RESOLVE_SUPPLIER | 2 |
| XDX_ROUTE_APP_STAGE | 2 |
| XDX_ROUTE_CHILD_READ | 2 |
| XDX_ROUTE_READ_RESOURCE | 2 |
| XDX_ROUTE_REQUEST_INTENT | 2 |
| XDX_SITE_RESPONSE | 2 |
| XDX_VALID_PARENT | 2 |
| XDX_VALID_SEARCH | 2 |

## Report Files

- JSON report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-site-continuity\result.json`
- Markdown report: `C:\Users\dasu\Documents\GitHub\fusion-ai-studio-1\.worktrees\xdx-supplier-lifecycle-agent-retry-20260923-a\test-reports\workflows\xdx_supplier_lifecycle_agent\xdx-site-continuity\result.md`
- Test file: `test/workflows/xdx_supplier_lifecycle_agent/xdx-site-continuity.json`
